package com.neusoft.My12306.service.impl.basedata;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.pojo.Dydjl;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.IDydjlService;

public class DydjlServiceTest {

	private IDydjlService dydjlService;

	@Before
	public void setUp() throws Exception {
		dydjlService = ServiceFactory.getDydjlService();
	}

	@Test
	public void testUpdate() {
		Dydjl dydjl = dydjlService.findById(1, 1);
		dydjl.setMileageSectionFrom("1");
		dydjlService.update(dydjl, 1);
	}

	@Test
	public void testFindById() {
		Dydjl dydjl = dydjlService.findById(1, 1);
		System.out.println(dydjl);
	}

	@Test
	public void testFindAll() {
		List<Dydjl> dydjlList = dydjlService.findAll(1);
		for (Dydjl d : dydjlList) {
			System.out.println(d);
		}
	}

}
