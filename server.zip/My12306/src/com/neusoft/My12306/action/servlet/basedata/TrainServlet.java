package com.neusoft.My12306.action.servlet.basedata;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.My12306.action.dispatch.basedata.DealWithTrain;
import com.neusoft.My12306.dao.pojo.Station;
import com.neusoft.My12306.dao.pojo.Train;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.IStationService;
import com.neusoft.My12306.service.iservice.basedata.ITrainService;

@WebServlet("/TrainServlet")
public class TrainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ITrainService trainService;
	private IStationService stationService;

	public TrainServlet() {
		super();
		trainService = ServiceFactory.getTrainService();
		stationService = ServiceFactory.getStationService();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String operation = request.getParameter("operation");
		// 获取当前管理员的权限
		int permission = 1;
		// 返回列车管理主页
		if (operation == null || request.getAttribute("DeleteError") != null) {
			List<Train> trainList = trainService.findAll(permission);
			request.setAttribute("trainList", trainList);
			request.getRequestDispatcher("WEB-INF/view/basedata/trainManager.jsp").forward(request, response);
			// 处理建立新列车
		} else if ("create".equalsIgnoreCase(operation)) {
			if (request.getParameter("submit") != null) {
				String result = DealWithTrain.createTrain(request, trainService, permission);
				if ("success".equals(result)) {
					response.sendRedirect("TrainServlet");
				} else {
					request.setAttribute("message", result);
					request.getRequestDispatcher("WEB-INF/view/basedata/newTrain.jsp").forward(request, response);
				}
			} else {
				List<Station> stationList = stationService.findAll(permission);
				request.getSession().setAttribute("stationList", stationList);
				request.getRequestDispatcher("WEB-INF/view/basedata/newTrain.jsp").forward(request, response);
			}
			// 处理列车信息更新
		} else if ("update".equalsIgnoreCase(operation)) {
			if (request.getParameter("submit") != null) {
				String result = DealWithTrain.updateTrain(request, trainService, permission);
				if ("success".equals(result)) {
					response.sendRedirect("TrainServlet");
				} else {
					request.setAttribute("message", result);
					request.getRequestDispatcher("WEB-INF/view/basedata/reviseTrain.jsp").forward(request, response);
				}
			} else {
				Train train = null;
				String id = request.getParameter("trainid");
				train = trainService.findById(id, permission);
				request.getSession().setAttribute("train", train);
				request.getRequestDispatcher("WEB-INF/view/basedata/reviseTrain.jsp").forward(request, response);
			}
			// 处理列车信息删除
		} else if ("delete".equalsIgnoreCase(operation)) {
			String result = DealWithTrain.deleteTrain(request, trainService, permission);
			if ("success".equals(result)) {
				response.sendRedirect("TrainServlet");
			} else {
				request.setAttribute("message", result);
				// 标记这是删除出错的转发
				request.setAttribute("DeleteError", true);
				request.getRequestDispatcher("TrainServlet").forward(request, response);
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
