package com.neusoft.My12306.action.servlet.basedata;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.My12306.action.dispatch.basedata.DealWithRoute;
import com.neusoft.My12306.dao.pojo.Route;
import com.neusoft.My12306.dao.pojo.Station;
import com.neusoft.My12306.dao.pojo.Train;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.IRouteService;
import com.neusoft.My12306.service.iservice.basedata.IStationService;
import com.neusoft.My12306.service.iservice.basedata.ITrainService;

@WebServlet("/RouteServlet")
public class RouteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private IRouteService routeService;
	private IStationService stationService;
	private ITrainService trainService;

	public RouteServlet() {
		super();
		routeService = ServiceFactory.getRouteService();
		stationService = ServiceFactory.getStationService();
		trainService = ServiceFactory.getTrainService();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String operation = request.getParameter("operation");
		// 获取当前管理员的权限
		int permission = 1;
		List<Station> stationList = stationService.findAll(permission);
		request.getSession().setAttribute("stationList", stationList);
		List<Train> trainList = trainService.findAll(permission);
		request.getSession().setAttribute("trainList", trainList);
		// 返回车站管理主页
		if (operation == null || request.getAttribute("DeleteError") != null) {
			List<Route> routeList = routeService.findAll(permission);
			request.setAttribute("routeList", routeList);
			request.getRequestDispatcher("WEB-INF/view/basedata/routeManager.jsp").forward(request, response);

			// 处理建立新车站
		} else if ("create".equalsIgnoreCase(operation)) {
			if (request.getParameter("submit") != null) {
				String result = DealWithRoute.createRoute(request, routeService, permission);
				if ("success".equals(result)) {
					response.sendRedirect("RouteServlet");
				} else {
					request.setAttribute("message", result);
					request.getRequestDispatcher("WEB-INF/view/basedata/newRoute.jsp").forward(request, response);
				}
			} else {
				request.getRequestDispatcher("WEB-INF/view/basedata/newRoute.jsp").forward(request, response);
			}
			// 处理车站信息更新
		} else if ("update".equalsIgnoreCase(operation)) {
			if (request.getParameter("submit") != null) {
				String result = DealWithRoute.updateRoute(request, routeService, permission);
				if ("success".equals(result)) {
					response.sendRedirect("RouteServlet");
				} else {
					request.setAttribute("message", result);
					request.getRequestDispatcher("WEB-INF/view/basedata/reviseRoute.jsp").forward(request, response);
				}
			} else {
				Route route = null;
				int id = Integer.parseInt(request.getParameter("routeid"));
				if (id != 0) {
					route = routeService.findById(id, permission);
				}
				request.setAttribute("route", route);
				request.getRequestDispatcher("WEB-INF/view/basedata/reviseRoute.jsp").forward(request, response);
			}
			// 处理车站信息删除
		} else if ("delete".equalsIgnoreCase(operation)) {
			String result = DealWithRoute.deleteRoute(request, routeService, permission);
			if ("success".equals(result)) {
				response.sendRedirect("RouteServlet");
			} else {
				request.setAttribute("message", result);
				// 标记这是删除出错的转发
				request.setAttribute("DeleteError", true);
				request.getRequestDispatcher("RouteServlet").forward(request, response);
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
