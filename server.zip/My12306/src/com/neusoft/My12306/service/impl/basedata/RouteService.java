package com.neusoft.My12306.service.impl.basedata;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IRouteDao;
import com.neusoft.My12306.dao.pojo.Route;
import com.neusoft.My12306.service.iservice.basedata.IRouteService;
import com.neusoft.My12306.util.AdminPermission;

public class RouteService implements IRouteService {

	private static Logger logger = Logger.getLogger(RouteService.class);

	private IRouteDao routeDao;

	public RouteService() {
		routeDao = DaoFactory.getRouteDao();
	}

	@Override
	public String save(Route route, int permission) {
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				route.setRouteid(routeDao.getNewId());
				logger.info("正在保存: " + route);
				routeDao.save(route);
				logger.info("成功保存: " + route);
				return "success";
			} catch (Exception e) {
				logger.info("失败保存: " + route);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public String delete(Route route, int permission) {
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在删除: " + route);
				routeDao.delete(route);
				logger.info("成功删除: " + route);
				return "success";
			} catch (Exception e) {
				logger.info("失败删除: " + route);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public String update(Route route, int permission) {
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在更新: " + route);
				routeDao.update(route);
				logger.info("成功更新: " + route);
				return "success";
			} catch (Exception e) {
				logger.info("失败更新: " + route);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public Route findById(int id, int permission) {
		Route route = null;
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询线路信息: id " + id);
				route = routeDao.findById(id);
				logger.info("成功查询线路信息: id " + id);
			} catch (Exception e) {
				logger.info("失败查询线路信息: id " + id);
				logger.error(e);
				e.printStackTrace();
			}
		}
		return route;
	}

	@Override
	public List<Route> findAll(int permission) {
		List<Route> routeList = new ArrayList<Route>();
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询所有线路信息");
				routeList.addAll(routeDao.findAll());
				logger.info("成功查询所有线路信息");
			} catch (Exception e) {
				logger.info("失败查询所有线路信息");
				logger.error(e);
				e.printStackTrace();
			}
		}
		return routeList;
	}

	@Override
	public long getLength(String trainid, String startStation, String endStation) {
		try {
			return routeDao.getLength(trainid, startStation, endStation);
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

}
