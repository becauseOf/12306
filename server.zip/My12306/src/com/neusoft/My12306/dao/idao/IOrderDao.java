package com.neusoft.My12306.dao.idao;

import com.hehujun.framework.dbhelper.idao.IBaseDao;
import com.neusoft.My12306.dao.pojo.Order;

import java.util.List;

public interface IOrderDao extends IBaseDao<Order, Integer> {
	/**
	 * 获得新id
	 * 
	 * @return id
	 */
	int getNewId()throws Exception;

	/**
	 *
	 * @param userId
	 * @return
     */
	List<Order> findByUserId(String userId) throws Exception;

	void updateOrderStatus(long  orderId,String status) throws Exception;
}
