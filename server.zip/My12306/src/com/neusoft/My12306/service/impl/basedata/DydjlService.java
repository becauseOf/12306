package com.neusoft.My12306.service.impl.basedata;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IDydjlDao;
import com.neusoft.My12306.dao.pojo.Dydjl;
import com.neusoft.My12306.service.iservice.basedata.IDydjlService;
import com.neusoft.My12306.util.AdminPermission;

public class DydjlService implements IDydjlService {

	private static Logger logger = Logger.getLogger(DydjlService.class);

	private IDydjlDao dydjlDao;

	public DydjlService() {
		dydjlDao = DaoFactory.getDydjlDao();
	}

	@Override
	public String update(Dydjl dydjl, int permission) {
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在更新: " + dydjl);
				dydjlDao.update(dydjl);
				logger.info("成功更新: " + dydjl);
				return "success";
			} catch (Exception e) {
				logger.info("失败更新: " + dydjl);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public Dydjl findById(int id, int permission) {
		Dydjl dydjl = null;
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询递远递减率信息: id " + id);
				dydjl = dydjlDao.findById(id);
				logger.info("成功查询递远递减率信息: id " + id);
			} catch (Exception e) {
				logger.info("失败查询递远递减率信息: id " + id);
				logger.error(e);
				e.printStackTrace();
			}
		}
		return dydjl;
	}

	@Override
	public List<Dydjl> findAll(int permission) {
		List<Dydjl> dydjlList = new ArrayList<Dydjl>();
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询所有递远递减率信息");
				dydjlList.addAll(dydjlDao.findAll());
				logger.info("成功查询所有递远递减率信息");
			} catch (Exception e) {
				logger.info("失败查询所有递远递减率信息");
				logger.error(e);
				e.printStackTrace();
			}
		}
		return dydjlList;
	}

}
