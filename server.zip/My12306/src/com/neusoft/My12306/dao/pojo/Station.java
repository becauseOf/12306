package com.neusoft.My12306.dao.pojo;

/**
 * 车站基本信息
 * 
 * @author hezhujun
 *
 */
public class Station {
	private int stationid;
	private String stationname;
	private String pingyin;
	private String administrativeArea;
	private String railwayStation;
	private String stationLevel;
	private String address;

	public int getStationid() {
		return stationid;
	}

	public void setStationid(int stationid) {
		this.stationid = stationid;
	}

	public String getStationname() {
		return stationname;
	}

	public void setStationname(String stationname) {
		this.stationname = stationname;
	}

	public String getPingyin() {
		return pingyin;
	}

	public void setPingyin(String pingyin) {
		this.pingyin = pingyin;
	}

	public String getAdministrativeArea() {
		return administrativeArea;
	}

	public void setAdministrativeArea(String administrativeArea) {
		this.administrativeArea = administrativeArea;
	}

	public String getRailwayStation() {
		return railwayStation;
	}

	public void setRailwayStation(String railwayStation) {
		this.railwayStation = railwayStation;
	}

	public String getStationLevel() {
		return stationLevel;
	}

	public void setStationLevel(String stationLevel) {
		this.stationLevel = stationLevel;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Station() {
		// TODO Auto-generated constructor stub
	}

	public Station(int stationid, String stationname, String pingyin, String administrativeArea, String railwayStation,
			String stationLevel, String address) {
		super();
		this.stationid = stationid;
		this.stationname = stationname;
		this.pingyin = pingyin;
		this.administrativeArea = administrativeArea;
		this.railwayStation = railwayStation;
		this.stationLevel = stationLevel;
		this.address = address;
	}

	@Override
	public String toString() {
		return "Station [stationid=" + stationid + ", stationname=" + stationname + ", pingyin=" + pingyin
				+ ", administrativeArea=" + administrativeArea + ", railwayStation=" + railwayStation
				+ ", stationLevel=" + stationLevel + ", address=" + address + "]";
	}

}
