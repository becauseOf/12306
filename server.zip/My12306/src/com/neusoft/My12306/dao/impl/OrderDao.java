package com.neusoft.My12306.dao.impl;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hehujun.framework.dbhelper.util.IDealWithResultSet;
import com.hehujun.framework.dbhelper.util.ISetStatementParam;
import com.hehujun.framework.dbhelper.util.SQLUtil;
import com.neusoft.My12306.dao.idao.IOrderDao;
import com.neusoft.My12306.dao.pojo.Order;
import com.neusoft.My12306.dao.pojo.User;

public class OrderDao implements IOrderDao {

	@Override
	public void delete(Order arg0) throws Exception {
		// TODO Auto-generated method stub
		String sql = "delete from T_ORDER where ORDERID=?";
		SQLUtil.delete(sql, new ISetStatementParam() {
			@Override
			public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setInt(1, (int) arg0.getOrderid());
			}
		});
	}

	@Override
	public List<Order> findAll() throws Exception {
		String sql  = "SELECT ORDERID,USERID,ORDERSTATE,ORDERTIME FROM T_ORDER";
		List<Object> objectList = SQLUtil.find(sql, new IDealWithResultSet<Object>() {

			@Override
			public Object dealWithResultSet(ResultSet resultSet) throws SQLException {
				Order order = new Order();
				order.setOrderid(resultSet.getInt(1));
				order.setUserid(resultSet.getInt(2));
				order.setOrderState(resultSet.getString(3));
				order.setOrderTime(resultSet.getString(4));

				return order;
			}
		});

		List<Order> orderList = new ArrayList<>();
		for(Object obj:objectList){
			orderList.add((Order) obj);
		}

		return orderList;
	}

	//见findByUserId
	@Override
	public Order findById(Integer arg0) throws Exception {
		String sql = "SELECT ORDERID,USERID,ORDERSTATE,ORDERTIME FROM T_ORDER WHERE ORDERID=?";
		List<Object> objList = SQLUtil.find(sql, new ISetStatementParam() {
			@Override
			public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setInt(1,arg0);
			}
		}, new IDealWithResultSet<Object>() {

			@Override
			public Object dealWithResultSet(ResultSet resultSet) throws SQLException {
				Order order = new Order();
				order.setOrderid(resultSet.getInt(1));
				order.setUserid(resultSet.getInt(2));
				order.setOrderState(resultSet.getString(3));
				order.setOrderTime(resultSet.getString(4));
				return order;
			}
		});

		Order order = null;
		if (!objList.isEmpty()) {
			order = (Order) objList.get(0);
		}
		return order;

	}

	@Override
	public void save(Order arg0) throws Exception {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO T_ORDER(ORDERID,USERID,ORDERSTATE,ORDERTIME) VALUES (?,?,?,to_date(?,'yyyy-mm-dd'))";
		SQLUtil.save(sql, new ISetStatementParam() {
			@Override
			public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setLong(1,arg0.getOrderid());
				preparedStatement.setInt(2,arg0.getUserid());
				preparedStatement.setString(3,arg0.getOrderState());
				//转换为日期
				preparedStatement.setString(4,arg0.getOrderTime());

			}
		});

	}

	//见updateOrderStatus
	@Override
	public void update(Order arg0) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public int getNewId() throws Exception{
//		String sql = "SELECT max(USERID) FROM T_ORDER";
		String sql = "SELECT max(ORDERID) FROM T_ORDER";
		List<Object> i = SQLUtil.executeAndGetResult(sql, new IDealWithResultSet<Object>() {
			@Override
			public Object dealWithResultSet(ResultSet resultSet) throws SQLException {
				Integer i = new Integer(resultSet.getInt(1)+1);
				return i;
			}
		});
		return (i.size() == 0 ? 0 : (int) i.get(0));
	}

	@Override
	public List<Order> findByUserId(String userId) throws Exception{
		String sql = "SELECT ORDERID,USERID,ORDERSTATE,ORDERTIME FROM T_ORDER WHERE USERID=?";
		List<Object> objList = SQLUtil.find(sql, new ISetStatementParam() {
			@Override
			public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setString(1,userId);
			}
		}, new IDealWithResultSet<Object>() {

			@Override
			public Object dealWithResultSet(ResultSet resultSet) throws SQLException {
				Order order = new Order();
				order.setOrderid(resultSet.getInt(1));
				order.setUserid(resultSet.getInt(2));
				order.setOrderState(resultSet.getString(3));
				order.setOrderTime(resultSet.getString(4));
				return order;
			}
		});

		List<Order> orders = new ArrayList<>();
		for(Object o:objList){
			orders.add((Order) o);
		}
		return orders;
	}

	@Override
	public void updateOrderStatus(long orderId, String status) throws Exception {
		String sql = "UPDATE T_ORDER set ORDERSTATE=? WHERE ORDERID=?";
		SQLUtil.update(sql, new ISetStatementParam() {
			@Override
			public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setString(1,status);
				preparedStatement.setLong(2,orderId);
			}
		});
	}

}
