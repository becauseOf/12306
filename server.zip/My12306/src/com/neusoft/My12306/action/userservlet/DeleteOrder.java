package com.neusoft.My12306.action.userservlet;

import com.google.gson.JsonObject;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.user.IUserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 用户取消订单
 * Created by xiangsong on 2016/9/17.
 */
@WebServlet("/DeleteOrder")
public class DeleteOrder extends HttpServlet{

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int orderid = Integer.parseInt(request.getParameter("orderid"));
        IUserService userService = ServiceFactory.getUserServiceInstance();
        boolean isSuccess =  userService.deleteOrder(orderid);

        JsonObject result = new JsonObject();

        result.addProperty("content",isSuccess);

        response.getWriter().println(result.toString());
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        doPost(request, response);
    }

}
