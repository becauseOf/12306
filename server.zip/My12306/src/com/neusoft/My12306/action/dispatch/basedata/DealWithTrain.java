package com.neusoft.My12306.action.dispatch.basedata;

import javax.servlet.http.HttpServletRequest;

import com.neusoft.My12306.dao.pojo.Train;
import com.neusoft.My12306.service.iservice.basedata.ITrainService;
import com.neusoft.My12306.util.CreateBean;

public class DealWithTrain {

	public static String createTrain(HttpServletRequest request, ITrainService trainService, int permission) {
		Train train = CreateBean.getBean(Train.class, request);
		String result = "error";
		if (train != null) {
			result = trainService.save(train, permission);
		}
		return result;
	}

	public static String updateTrain(HttpServletRequest request, ITrainService trainService, int permission) {
		Train train = CreateBean.getBean(Train.class, request);
		String result = "error";
		if (train != null) {
			result = trainService.update(train, permission);
		}
		return result;
	}

	public static String deleteTrain(HttpServletRequest request, ITrainService trainService, int permission) {
		Train train = new Train();
		train.setTrainid(request.getParameter("trainid"));
		String result = "error";
		if (train.getTrainid() != null) {
			result = trainService.delete(train, permission);
		}
		return result;
	}

}
