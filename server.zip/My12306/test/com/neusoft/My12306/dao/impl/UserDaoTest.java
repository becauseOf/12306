package com.neusoft.My12306.dao.impl;

import static org.junit.Assert.fail;

import java.util.List;

import com.google.gson.JsonObject;
import com.neusoft.My12306.bean.TicketBean;
import com.neusoft.My12306.dao.idao.IOrderDao;
import com.neusoft.My12306.dao.idao.ITicketDao;
import com.neusoft.My12306.dao.pojo.Order;
import com.neusoft.My12306.dao.pojo.Ticket;
import com.neusoft.My12306.dao.pojo.User;
import com.neusoft.My12306.dao.pojo.UserLogin;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.order.ITicketService;
import com.neusoft.My12306.service.iservice.user.IUserService;
import com.neusoft.My12306.util.GsonUtil;
import org.junit.Test;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IUserDao;


/**
 * @author wangzhihao
 *
 * 下午9:49:33 2016年9月13日
 */
public class UserDaoTest {

	@Test
	public void testDelete() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindAll() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindById() {
		fail("Not yet implemented");
	}

	@Test
	public void testSave() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdate() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetNewId() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testQueryTicket(){
		/*IUserDao userDao = DaoFactory.getUserDaoInstance();
		try {
			List oList = userDao.queryTicket("长沙", "北京", "2016-09-21", false, false);
			for (Object o : oList){
				System.out.println(o);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}*/

		ITicketService ticketService = ServiceFactory.getTicketService();
		List<TicketBean> resultData = ticketService.getTicketBean("长沙","北京","2016-09-21");
		
	}
	@Test
	public void testQueryOrder(){
		IUserService userService = ServiceFactory.getUserServiceInstance();

		JsonObject result = new JsonObject();

		List resultData = userService.queryOrder("155332635263","1");
	}
//////////////////////////////////////////////////////////////////
	@Test
	public void testSaveOrder()throws Exception{
		IOrderDao orderDao = DaoFactory.getOrderDaoInstance();
		orderDao.save(new Order(orderDao.getNewId(),1,"已支付","2016-9-18"));
	}
	@Test
	public void testUpdateOrder()throws Exception{
		IOrderDao orderDao = DaoFactory.getOrderDaoInstance();
		orderDao.updateOrderStatus(2,"未支付");
	}

	@Test
	public void testSaveTicket()throws Exception{
		ITicketDao ticketDao = DaoFactory.getTicketDaoInstance();
		ticketDao.save(new Ticket(ticketDao.getNewId(),"Z202","2016-9-18",1,"12","长沙","武汉","向松","学生","155332635263",",","","","未取票","","",""));

	}
	@Test
	public void testUpdateTicketStatus()throws Exception{
		ITicketDao ticketDao = DaoFactory.getTicketDaoInstance();
		List<Ticket> list = ticketDao.findByPhoneId("155332635263");
		ticketDao.updateTicketStatus("155332635263","已取票");
	}
	@Test
	public void testUpdateTicket()throws Exception{
		/*ITicketDao ticketDao = DaoFactory.getTicketDaoInstance();
		ticketDao.update(new Ticket(ticketDao.getNewId(),"Z202","2016-10-28",1,"12","长沙","北京","向松","学生","155332635263",",","","","未取票","","",""));*/
		IUserService userService = ServiceFactory.getUserServiceInstance();
		List resultData = userService.queryOrder("155332635263","1");
	}

	@Test
	public void queryUser(){
		IUserService userService = ServiceFactory.getUserServiceInstance();
		User user = userService.queryUser(1);
	}

	@Test
	public void editUser(){
		IUserService userService = ServiceFactory.getUserServiceInstance();
		userService.editUser(new User(1,"12323@qq.com","我问问","女","12673427134","123213213","",""));
	}

	@Test
	public void generateOrder() throws Exception {
		/*ITicketDao ticketDao = DaoFactory.getTicketDaoInstance();
		Ticket ticket = new Ticket();
		ticket.setTrainid("Z202");
		ticket.setDate("2016-09-21");
		ticket.setTicketid(ticketDao.getNewId());
		ticket.setTrainBox(1);
		ticket.setSeatNum("2");
		ticket.setStartStation("广州");
		ticket.setEndStation("北京");
		ticket.setPrice(0);
		ticket.setName("王林");
		ticket.setPasgtype("学生");
		ticket.setIdcard("155332635263");
		ticketDao.save(ticket);*/

		IOrderDao orderDao = DaoFactory.getOrderDaoInstance();
		Order order =new Order();
		order.setOrderid(orderDao.getNewId());
		order.setOrderState("sd");
		order.setOrderTime("2016-09-21");
		order.setUserid(1);
		orderDao.save(order);
	}

	@Test
	public void testGeTicketNewId()throws Exception{
		ITicketDao ticketDao = DaoFactory.getTicketDaoInstance();
		int i = ticketDao.getNewId();
		IOrderDao orderDao = DaoFactory.getOrderDaoInstance();
		int j = orderDao.getNewId();
		System.out.println(i+j);
	}

	@Test
	public void testOperate(){
		int orderid = 2;
		String operation = "已支付";
		IUserService userService = ServiceFactory.getUserServiceInstance();
		boolean isSuccess =  userService.operateOrder(orderid,operation);
		System.out.println(isSuccess);
	}

	@Test
	public void testDeleteOrder(){
		int orderid = 3;
		IUserService userService = ServiceFactory.getUserServiceInstance();
		boolean isSuccess =  userService.deleteOrder(orderid);

		JsonObject result = new JsonObject();
	}

	@Test
	public void testQuery(){
		IUserService userService = ServiceFactory.getUserServiceInstance();

		JsonObject result = new JsonObject();

		boolean isSuccess = userService.validateLogin("123","123");
	}

	@Test
	public void testResgister(){
		User user = new User(1,"12","12","12","12","12","12","12");
		user.setSex("男");
		UserLogin login = new UserLogin(1,"12","12");

		IUserService userService = ServiceFactory.getUserServiceInstance();

		JsonObject result = new JsonObject();
		boolean isSuccess = userService.registerUser(user.getEmail(),user.getName(),user.getSex(),user.getPhone(),user.getIdcard(),login.getPassword());

		result.addProperty("content",isSuccess);
	}

	@Test
	public void testEditUser(){

		IUserService userService = ServiceFactory.getUserServiceInstance();

		User user = new User(2,"1126","xsxs","1","1","1","1","1");

		boolean resultData = userService.editUser(user);

		System.out.println(resultData);
	}

	@Test
	public void testQueryUserByEmail(){
		IUserService userService = ServiceFactory.getUserServiceInstance();

		JsonObject result = new JsonObject();

		User resultData = userService.queryUserByEmail("1126");
		System.out.println(resultData);
	}




}
