package com.neusoft.My12306.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hehujun.framework.dbhelper.util.IDealWithResultSet;
import com.hehujun.framework.dbhelper.util.ISetStatementParam;
import com.hehujun.framework.dbhelper.util.SQLUtil;
import com.neusoft.My12306.dao.idao.IPlainDao;
import com.neusoft.My12306.dao.pojo.Plain;

public class PlainDao implements IPlainDao {

	@Override
	public void delete(Plain plain) throws Exception {
		String sql = "delete from t_plain where plainid=?";
		SQLUtil.delete(sql, new ISetStatementParam() {
			
			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, plain.getPlainid());
			}
		});

	}

	@Override
	public List<Plain> findAll() throws Exception {
		String sql = "SELECT JAVA.T_PLAIN.PLAINID,JAVA.T_PLAIN.TRAINID,"
				+ "JAVA.T_PLAIN.NUM,JAVA.T_PLAIN.COMPARE,"
				+ "JAVA.T_PLAIN.STATION FROM JAVA.T_PLAIN order by plainid";
		List<Object> oList = SQLUtil.find(sql, new IDealWithResultSet<Plain>() {

			@Override
			public Plain dealWithResultSet(ResultSet rs) throws SQLException {
				Plain plain = new Plain();
				plain.setPlainid(rs.getInt(1));
				plain.setTrainid(rs.getString(2));
				plain.setNum(rs.getInt(3));
				plain.setCompare(rs.getString(4));
				plain.setStation(rs.getString(5));
				return plain;
			}
			
		});
		List<Plain> plainList = new ArrayList<Plain>();
		for(Object o : oList){
			plainList.add((Plain) o);
		}
		return plainList;
	}

	@Override
	public Plain findById(Integer id) throws Exception {
		String sql = "SELECT JAVA.T_PLAIN.PLAINID,JAVA.T_PLAIN.TRAINID,"
				+ "JAVA.T_PLAIN.NUM,JAVA.T_PLAIN.COMPARE,JAVA.T_PLAIN.STATION"
				+ " FROM JAVA.T_PLAIN where plainid=? order by plainid";
		List<Object> oList = SQLUtil.find(sql, new ISetStatementParam() {
			
			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, id);
				
			}
		}, new IDealWithResultSet<Plain>() {

			@Override
			public Plain dealWithResultSet(ResultSet rs) throws SQLException {
				Plain plain = new Plain();
				plain.setPlainid(rs.getInt(1));
				plain.setTrainid(rs.getString(2));
				plain.setNum(rs.getInt(3));
				plain.setCompare(rs.getString(4));
				plain.setStation(rs.getString(5));
				return plain;
			}
		});
		Plain plain = null;
		if(!oList.isEmpty()){
			plain = (Plain) oList.get(0);
		}
		return plain;
	}

	@Override
	public void save(Plain plain) throws Exception {
		String sql = "insert into t_plain(plainid,trainid,num,compare,station) values(?,?,?,?,?)";
		SQLUtil.save(sql, new ISetStatementParam() {
			
			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, plain.getPlainid());
				ps.setString(2, plain.getTrainid());
				ps.setInt(3, plain.getNum());
				ps.setString(4, plain.getCompare());
				ps.setString(5, plain.getStation());
			}
		});

	}

	@Override
	public void update(Plain plain) throws Exception {
		String sql = "update t_plain set trainid=?,num=?,compare=?,station=? where plainid=?";
		SQLUtil.save(sql, new ISetStatementParam() {
			
			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, plain.getTrainid());
				ps.setInt(2, plain.getNum());
				ps.setString(3, plain.getCompare());
				ps.setString(4, plain.getStation());
				ps.setInt(5, plain.getPlainid());
				
			}
		});

	}

	@Override
	public int getNewId() throws SQLException {
		String sql = "select max(plainid) from t_plain";
		List<Object> i = SQLUtil.executeAndGetResult(sql, new IDealWithResultSet<Integer>() {

			@Override
			public Integer dealWithResultSet(ResultSet rs)
					throws SQLException {
				Integer i = new Integer(rs.getInt(1) + 1);
				return i;
			}
		});
		return (i.size() == 0 ? 0 : (int) i.get(0));
	}

	@Override
	public List<Plain> findBytrainid(String trainid) throws SQLException {
		String sql = "select plainid,trainid,num,compare,station "
				+ "from t_plain where train like ? order by station asc";
		List<Object> oList = SQLUtil.find(sql, new ISetStatementParam() {
			
			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, "%" + trainid + "%");
				
			}
		}, new IDealWithResultSet<Plain>() {

			@Override
			public Plain dealWithResultSet(ResultSet rs) throws SQLException {
				Plain plain = new Plain();
				plain.setPlainid(rs.getInt(1));
				plain.setTrainid(rs.getString(2));
				plain.setNum(rs.getInt(3));
				plain.setCompare(rs.getString(4));
				plain.setStation(rs.getString(5));
				return plain;
			}
		});
		List<Plain> plainList = new ArrayList<Plain>();
		for(int i=0;i < oList.size();i++){
			plainList.add((Plain)oList.get(i));
		}
		return plainList;
	}

	
}
