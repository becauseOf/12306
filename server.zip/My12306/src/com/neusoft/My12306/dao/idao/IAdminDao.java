package com.neusoft.My12306.dao.idao;

import java.sql.SQLException;

import com.hehujun.framework.dbhelper.idao.IBaseDao;
import com.neusoft.My12306.dao.pojo.Admin;

public interface IAdminDao extends IBaseDao<Admin, Integer> {
	/**
	 * 获得新id
	 * 
	 * @return id
	 * @throws SQLException 
	 */
	int getNewId() throws SQLException;
}
