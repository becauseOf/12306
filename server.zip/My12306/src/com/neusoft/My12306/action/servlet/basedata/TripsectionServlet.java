package com.neusoft.My12306.action.servlet.basedata;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.My12306.action.dispatch.basedata.DealWithTripsection;
import com.neusoft.My12306.dao.pojo.Tripsection;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.ITripsectionService;

@WebServlet("/TripsectionServlet")
public class TripsectionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ITripsectionService tripsectionService;

	public TripsectionServlet() {
		super();
		tripsectionService = ServiceFactory.getTripsectionService();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String operation = request.getParameter("operation");
		// 获取当前管理员的权限
		int permission = 1;
		// 返回票价率管理主页
		if (operation == null) {
			List<Tripsection> tripsectionList = tripsectionService.findAll(permission);
			request.setAttribute("tripsectionList", tripsectionList);
			request.getRequestDispatcher("WEB-INF/view/basedata/regionManager.jsp").forward(request, response);
			// 处理票价率信息更新
		} else if ("update".equalsIgnoreCase(operation)) {
			if (request.getParameter("submit") != null) {
				String result = DealWithTripsection.updateTripsection(request, tripsectionService, permission);
				if ("success".equals(result)) {
					response.sendRedirect("TripsectionServlet");
				} else {
					request.setAttribute("message", result);
					request.getRequestDispatcher("WEB-INF/view/basedata/reviseRegion.jsp").forward(request, response);
				}
			} else {
				int id = Integer.parseInt(request.getParameter("tripsectionid"));
				Tripsection tripsection = tripsectionService.findById(id, permission);
				request.setAttribute("tripsection", tripsection);
				request.getRequestDispatcher("WEB-INF/view/basedata/reviseRegion.jsp").forward(request, response);
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
