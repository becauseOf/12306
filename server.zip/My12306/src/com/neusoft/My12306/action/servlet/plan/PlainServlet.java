package com.neusoft.My12306.action.servlet.plan;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.My12306.action.dispatch.plan.DealWithPlain;
import com.neusoft.My12306.dao.pojo.Plain;
import com.neusoft.My12306.dao.pojo.Station;
import com.neusoft.My12306.dao.pojo.Train;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.IStationService;
import com.neusoft.My12306.service.iservice.basedata.ITrainService;
import com.neusoft.My12306.service.iservice.plan.IPlainService;


@WebServlet("/PlainServlet")
public class PlainServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	private IPlainService plainService;
	private ITrainService trainService;
	private IStationService stationService;
	
	public PlainServlet(){
		super();
		plainService = ServiceFactory.getPlainService();
		trainService = ServiceFactory.getTrainService();
		stationService = ServiceFactory.getStationService();
	}
	
	protected void doGet(HttpServletRequest request,HttpServletResponse response)
		throws ServletException,IOException{
		String operation = request.getParameter("operation");
		//获取当前管理员的权限
		int permission = 2;
		List<Station> stationList = stationService.findAll(permission);
		request.getSession().setAttribute("stationList", stationList);
		List<Train> trainList = trainService.findAll(permission);
		request.getSession().setAttribute("trainList", trainList);
		//返回车站管理主页
		if(operation == null || request.getAttribute("DeleteError") != null){
			List<Plain> plainList = plainService.findAll(permission);
			request.setAttribute("plainList", plainList);
			request.getRequestDispatcher("WEB-INF/view/plan/planManager.jsp").forward(request, response);
		}//处理建立新计划
		else if("create".equalsIgnoreCase(operation)){
			if(request.getParameter("submit") != null){
				String result = DealWithPlain.createPlain(request, plainService, permission);
				if("success".equals(result)){
					response.sendRedirect("PlainServlet");
				}else{
					request.setAttribute("message", result);
					request.getRequestDispatcher("WEB-INF/view/plan/newPlan.jsp").forward(request, response);
				}
			}else{
				request.getRequestDispatcher("WEB-INF/view/plan/newPlan.jsp").forward(request, response);
			}
			//处理计划信息更新
		}else if("update".equalsIgnoreCase(operation)){
			if(request.getParameter("submit") != null){
				String result = DealWithPlain.updatePlain(request, plainService, permission);
				if("success".equals(result)){
					response.sendRedirect("PlainServlet");
				}else{
					Plain plain = null;
					int id = Integer.parseInt(request.getParameter("plainid"));
					if(id != 0){
						plain = plainService.findById(id, permission);
					}
					request.setAttribute("plain", plain);
					request.getRequestDispatcher("WEB-INF/view/plan/revisePlan.jsp").forward(request, response);
				}
				//处理计划信息删除
			}else if("delete".equalsIgnoreCase(operation)){
				String result = DealWithPlain.deletePlain(request, plainService, permission);
				if("success".equals(result)){
					response.sendRedirect("plainServlet");
					//这是标记删除出错的转发
				}else{
					request.setAttribute("message", result);
					request.setAttribute("DeleteError", true);
					request.getRequestDispatcher("PlainServlet").forward(request, response);
				}
			}
		}
	}
	
	protected void doPost(HttpServletRequest request,HttpServletResponse response) 
			throws ServletException,IOException{
		doGet(request,response);
	}
}
