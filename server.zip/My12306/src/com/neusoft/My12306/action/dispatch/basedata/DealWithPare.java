package com.neusoft.My12306.action.dispatch.basedata;

import javax.servlet.http.HttpServletRequest;

import com.neusoft.My12306.dao.pojo.Pare;
import com.neusoft.My12306.service.iservice.basedata.IPareService;
import com.neusoft.My12306.util.CreateBean;

public class DealWithPare {

	public static String updatePare(HttpServletRequest request, IPareService pareService, int permission) {
		Pare pare = CreateBean.getBean(Pare.class, request);
		String result = "error";
		if (pare != null) {
			result = pareService.update(pare, permission);
		}
		return result;
	}

}
