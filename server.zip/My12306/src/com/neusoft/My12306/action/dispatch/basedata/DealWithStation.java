package com.neusoft.My12306.action.dispatch.basedata;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.My12306.dao.pojo.Station;
import com.neusoft.My12306.service.iservice.basedata.IStationService;
import com.neusoft.My12306.util.CreateBean;

/**
 * 处理关于车站信息的请求
 * 
 * @author hezhujun
 *
 */
public class DealWithStation {

	/**
	 * 保存station数据
	 * 
	 * @param request
	 * @param stationService
	 * @param permission
	 * @return
	 */
	public static String createStation(HttpServletRequest request, IStationService stationService, int permission) {
		Station station = CreateBean.getBean(Station.class, request);
		String result = "error";
		if (station != null) {
			result = stationService.save(station, permission);
		}
		return result;
	}

	public static String updateStation(HttpServletRequest request, IStationService stationService, int permission) {
		Station station = CreateBean.getBean(Station.class, request);
		String result = "error";
		if (station != null) {
			result = stationService.update(station, permission);
		}
		return result;
	}

	public static String deleteStation(HttpServletRequest request, IStationService stationService, int permission) {
		String result = "error";
		int id = 0;
		try {
			id = Integer.parseInt(request.getParameter("stationid"));
		} catch (NumberFormatException e) {
			result = "车站id为整型";
		}
		if (id != 0) {
			Station station = new Station();
			station.setStationid(id);
			result = stationService.delete(station, permission);
		}
		return result;
	}

	public static void autocomplete(HttpServletRequest request, HttpServletResponse response,
			IStationService stationService, int permission) throws ServletException, IOException {
		String term = request.getParameter("term");
		// 判断是字母还是中文名
		int length = term.length();
		term = term.toUpperCase();
		String regex = "[A-Z]{" + length + "}";
		List<Station> stationList = new ArrayList<Station>();
		List<String> result = new ArrayList<String>();
		if (term.matches(regex)) {
			stationList.addAll(stationService.findByPinyin(term, permission));
			for (Station station : stationList) {
				result.add("{ \"label\": \"" + station.getPingyin() + "\", \"value\": \"" + station.getStationname()
						+ "\" }");
			}
		} else {
			stationList.addAll(stationService.findByName(term, permission));
			for (Station station : stationList) {
				result.add("\"" + station.getStationname() + "\"");
			}
		}
		response.setContentType("text/javascript");
		PrintWriter out = response.getWriter();
		// 从服务器端输出的JSON的key必须用双引号
		out.print(result.toString());
		out.flush();
		out.close();
	}

}
