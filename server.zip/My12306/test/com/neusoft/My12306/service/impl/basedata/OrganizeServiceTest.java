package com.neusoft.My12306.service.impl.basedata;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.pojo.Organize;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.IOrganizeService;

public class OrganizeServiceTest {

	private IOrganizeService organizeService;

	@Before
	public void setUp() throws Exception {
		organizeService = ServiceFactory.getOrganizeService();
	}

	@Test
	public void testSave() {
		Organize organize = new Organize(0, "G94", 2, "硬座", 50, "硬座车");
		organizeService.save(organize, 1);
	}

	@Test
	public void testFindById() {
		Organize organize = organizeService.findById(2, 1);
		System.out.println(organize);
	}

	@Test
	public void testFindAll() {
		List<Organize> organizeList = organizeService.findAll(1);
		for (Organize o : organizeList) {
			System.out.println(o);
		}
	}

	@Test
	public void testUpdate() {
		Organize organize = organizeService.findById(2, 1);
		organize.setSeatClass("软卧上铺");
		organizeService.update(organize, 1);
	}

	@Test
	public void testDelete() {
		Organize organize = organizeService.findById(2, 1);
		organizeService.delete(organize, 1);
	}

}
