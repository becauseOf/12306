package com.neusoft.My12306.action.servlet.basedata;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.My12306.action.dispatch.basedata.DealWithStation;
import com.neusoft.My12306.dao.pojo.Station;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.IStationService;

@WebServlet("/StationServlet")
public class StationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private IStationService stationService;

	public StationServlet() {
		super();
		stationService = ServiceFactory.getStationService();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String operation = request.getParameter("operation");
		// 获取当前管理员的权限
		int permission = 1;
		// 返回车站管理主页
		if (operation == null || request.getAttribute("DeleteError") != null) {
			List<Station> stationList = stationService.findAll(permission);
			request.setAttribute("stationList", stationList);
			request.getRequestDispatcher("WEB-INF/view/basedata/stationManager.jsp").forward(request, response);

			// 处理建立新车站
		} else if ("create".equalsIgnoreCase(operation)) {
			if (request.getParameter("submit") != null) {
				String result = DealWithStation.createStation(request, stationService, permission);
				if ("success".equals(result)) {
					response.sendRedirect("StationServlet");
				} else {
					request.setAttribute("message", result);
					request.getRequestDispatcher("WEB-INF/view/basedata/newStation.jsp").forward(request, response);
				}
			} else {
				request.getRequestDispatcher("WEB-INF/view/basedata/newStation.jsp").forward(request, response);
			}
			// 处理车站信息更新
		} else if ("update".equalsIgnoreCase(operation)) {
			if (request.getParameter("submit") != null) {
				String result = DealWithStation.updateStation(request, stationService, permission);
				if ("success".equals(result)) {
					response.sendRedirect("StationServlet");
				} else {
					request.setAttribute("message", result);
					request.getRequestDispatcher("WEB-INF/view/basedata/reviseStation.jsp").forward(request, response);
				}
			} else {
				Station station = null;
				int id = Integer.parseInt(request.getParameter("stationid"));
				if (id != 0) {
					station = stationService.findById(id, permission);
				}
				request.setAttribute("station", station);
				request.getRequestDispatcher("WEB-INF/view/basedata/reviseStation.jsp").forward(request, response);
			}
			// 处理车站信息删除
		} else if ("delete".equalsIgnoreCase(operation)) {
			String result = DealWithStation.deleteStation(request, stationService, permission);
			if ("success".equals(result)) {
				response.sendRedirect("StationServlet");
			} else {
				request.setAttribute("message", result);
				// 标记这是删除出错的转发
				request.setAttribute("DeleteError", true);
				request.getRequestDispatcher("StationServlet").forward(request, response);
			}
		} else if ("search".equals(operation)){
			String name = request.getParameter("stationname");
			List<Station> stationList = stationService.findByName(name, permission);
			request.setAttribute("stationList", stationList);
			request.getRequestDispatcher("WEB-INF/view/basedata/stationTemp.jsp").forward(request, response);
		} else if("autocomplete".equals(operation)){
			DealWithStation.autocomplete(request, response,stationService, permission);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
