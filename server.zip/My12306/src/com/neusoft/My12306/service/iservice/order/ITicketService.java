package com.neusoft.My12306.service.iservice.order;

import java.util.List;

import com.neusoft.My12306.bean.TicketBean;
import com.neusoft.My12306.dao.pojo.Seat;
import com.neusoft.My12306.dao.pojo.Ticket;

public interface ITicketService {

	/**
	 * 查询
	 * 
	 * @param from
	 *            起始站
	 * @param to
	 *            终点站
	 * @param day
	 *            日期
	 * @return 余票信息bean
	 */
	List<TicketBean> getTicketBean(String from, String to, String day);

	/**
	 * 选择一张余票
	 * 
	 * @param from
	 *            起始站
	 * @param to
	 *            终点站
	 * @param trainid
	 *            车次
	 * @param seatClass
	 *            席位类型
	 * @param day
	 *            日期
	 * @return 席位信息
	 */
	Seat selectSeat(String from, String to, String trainid, String seatClass, String day);

	/**
	 * 锁定席位，禁止购买
	 * 
	 * @param id
	 * @return
	 */
	/**
	 * 锁定或解锁相应的席位
	 * 
	 * @param id
	 * @param state
	 *            状态
	 * @return
	 */
	String lockToggle(int id, String state);

	/**
	 * 买票，修改席位信息
	 * 
	 * @param id
	 *            席位id
	 * @return
	 */
	String selectedSeat(int id);

	/**
	 * 退票，修改席位信息
	 * 
	 * @param id
	 * @return
	 */
	String cancelSeat(int id);

	/**
	 * 通过身份证查询车票信息
	 * 
	 * @param idcard
	 * @return
	 */
	List<Ticket> getTicketByIdcard(String idcard);

	/**
	 * 通过id查询车票信息
	 * 
	 * @param id
	 * @return
	 */
	Ticket getTicketById(int id);

	/**
	 * 更新车票信息
	 * 
	 * @param ticket
	 * @param permission
	 * @return
	 */
	String update(Ticket ticket, int permission);

}
