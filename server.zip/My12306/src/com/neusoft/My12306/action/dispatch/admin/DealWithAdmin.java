package com.neusoft.My12306.action.dispatch.admin;

import javax.servlet.http.HttpServletRequest;

import com.neusoft.My12306.dao.idao.IAdminDao;
import com.neusoft.My12306.dao.pojo.Admin;
import com.neusoft.My12306.service.iservice.admin.IAdminService;
import com.neusoft.My12306.util.CreateBean;



/**
 * 处理关于管理员操作的请求
 * 
 * @author wangzhihao
 *
 * 下午2:32:12 2016年9月19日
 */
public class DealWithAdmin {
	public static String createAdmin(HttpServletRequest request,IAdminService adminService,int permission){
		Admin admin = CreateBean.getBean(Admin.class, request);
		String result = "error";
		if(admin != null){
			result = adminService.save(admin, permission);
		}
		return result;
	}
	
	public static String updateAdmin(HttpServletRequest request,IAdminService adminService,int permission){
		Admin admin = CreateBean.getBean(Admin.class, request);
		String result = "error";
		if(admin != null){
			result = adminService.update(admin, permission);
		}
		return result;
	}
	
	public static String deleteAdmin(HttpServletRequest request,IAdminService adminService,int permission){
		String result = "error";
		int id = 0;
		id = Integer.parseInt(request.getParameter("adminid"));
		if(id != 0){
			Admin admin = new Admin();
			admin.setAdminid(id);
			result = adminService.delete(admin, permission);
		}
		return result;
	}
}
