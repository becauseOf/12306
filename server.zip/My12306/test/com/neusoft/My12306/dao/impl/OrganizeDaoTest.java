package com.neusoft.My12306.dao.impl;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IOrganizeDao;
import com.neusoft.My12306.dao.pojo.Organize;

/**
 * @author wangzhihao
 *
 *         下午9:49:03 2016年9月13日
 */
public class OrganizeDaoTest {

	private IOrganizeDao organizeDao;

	@Before
	public void setUp() {
		organizeDao = DaoFactory.getOrganizeDao();
	}

	@Test
	public void testGetNewId() throws SQLException {
		System.out.println(organizeDao.getNewId());
	}

	@Test
	public void testSave() throws Exception {
		Organize organize = new Organize(organizeDao.getNewId(), "G94", 2, "硬座", 50, "硬座车");
		organizeDao.save(organize);
	}

	@Test
	public void testFindAll() throws Exception {
		List<Organize> organizeList = organizeDao.findAll();
		for (Organize organize : organizeList) {
			System.out.println(organize);
		}
	}

	@Test
	public void testFindById() throws Exception {
		Organize organize = organizeDao.findById(1);
		assertEquals(1, organize.getOrganizeid());
		assertEquals("G94", organize.getTrainid());
		assertEquals(1, organize.getNum());
		assertEquals("硬座", organize.getSeatClass());
		assertEquals(50, organize.getSeatCount());
		assertEquals("硬座车", organize.getCategory());
	}

	@Test
	public void testUpdate() throws Exception {
		Organize organize = organizeDao.findById(1);
		organize.setCategory("软座车");
		organizeDao.update(organize);
	}

	@Test
	public void testDelete() throws Exception {
		Organize organize = organizeDao.findById(2);
		organizeDao.delete(organize);
	}

}
