package com.neusoft.My12306.util;

import org.junit.Before;
import org.junit.Test;

public class ClassifyPassengerTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testClassifyPassenger() {
		System.out.println(ClassifyPassenger.classifyPassenger("450421201510204511"));
	}

}
