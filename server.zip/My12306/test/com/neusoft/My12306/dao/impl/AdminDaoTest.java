package com.neusoft.My12306.dao.impl;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IAdminDao;
import com.neusoft.My12306.dao.pojo.Admin;


/**
 * @author wangzhihao
 *
 * 下午9:48:40 2016年9月13日
 */
public class AdminDaoTest {
	private IAdminDao adminDao;
	
	@Before
	public void setUp(){
		adminDao = DaoFactory.getAdminDao();
	}

	@Test
	public void testDelete() throws Exception {
		Admin admin = adminDao.findById(3);
		adminDao.delete(admin);
	}

	@Test
	public void testFindAll() throws Exception {
		List<Admin> adminList = adminDao.findAll();
		for(Admin a : adminList){
			System.out.println(a);
		}
	}

	@Test
	public void testFindById() throws Exception {
		Admin admin = adminDao.findById(1);
		assertEquals(1, admin.getAdminid());
		assertEquals("baseadmin", admin.getName());
		assertEquals("123", admin.getPassword());
		assertEquals(1, admin.getPermission());
	}

	@Test
	public void testSave() throws Exception {
		Admin admin = new Admin(adminDao.getNewId(),"baseadmin3","123",1);
		adminDao.save(admin);
	}

	@Test
	public void testUpdate() throws Exception {
		Admin admin = adminDao.findById(3);
		admin.setPassword("ae86");
		adminDao.update(admin);
	}

	@Test
	public void testGetNewId() throws SQLException {
		try {
			System.out.println(adminDao.getNewId());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
