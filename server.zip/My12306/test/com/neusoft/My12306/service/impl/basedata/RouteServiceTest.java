package com.neusoft.My12306.service.impl.basedata;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.pojo.Route;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.IRouteService;

public class RouteServiceTest {

	private IRouteService routeService;

	@Before
	public void setUp() throws Exception {
		routeService = ServiceFactory.getRouteService();
	}

	@Test
	public void testSave() {
		Route route = new Route(0, "G94", "长沙南", "08:00:00", "10:00:00", 2000, "00:05:00", "02:00:00", 1);
		routeService.save(route, 1);
	}

	@Test
	public void testFindById() {
		Route route = routeService.findById(2, 1);
		System.out.println(route);
	}

	@Test
	public void testFindAll() {
		List<Route> routeList = routeService.findAll(1);
		for (Route route : routeList) {
			System.out.println(route);
		}
	}

	@Test
	public void testUpdate() {
		Route route = routeService.findById(2, 1);
		route.setWaitTime("00:10:00");
		routeService.update(route, 1);
	}

	@Test
	public void testDelete() {
		Route route = routeService.findById(2, 1);
		routeService.delete(route, 1);
	}

}
