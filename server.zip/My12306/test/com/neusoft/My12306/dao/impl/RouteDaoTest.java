package com.neusoft.My12306.dao.impl;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IRouteDao;
import com.neusoft.My12306.dao.pojo.Route;


/**
 * @author wangzhihao
 *
 * 下午9:49:13 2016年9月13日
 */
public class RouteDaoTest {
	
	private IRouteDao routeDao;
	
	@Before
	public void setUp(){
		routeDao = DaoFactory.getRouteDao();
	}

	@Test
	public void testGetNewId() throws SQLException {
		System.out.println(routeDao.getNewId());
	}

	@Test
	public void testSave() throws Exception {
		Route route = new Route(routeDao.getNewId(), 
				"G94", "长沙南", "08:00:00", "10:00:00", 2000,"00:05:00", 
				"02:00:00",1);
		routeDao.save(route);
	}

	@Test
	public void testFindAll() throws Exception {
		List<Route> routeList = routeDao.findAll();
		for (Route route : routeList){
			System.out.println(route);
		}
	}

	@Test
	public void testFindById() throws Exception {
		Route route = routeDao.findById(1);
		assertEquals(1, route.getRouteid());
		assertEquals("G94", route.getTrainid());
		assertEquals("长沙南", route.getStationName());
		assertEquals("08:00:00", route.getStartTime());
		assertEquals("10:00:00", route.getEndTime());
		assertEquals(2000, route.getLength());
		assertEquals("00:05:00", route.getWaitTime());
		assertEquals("02:00:00", route.getTime());
		assertEquals(1, route.getStationid());
	}

	@Test
	public void testUpdate() throws Exception {
		Route route = routeDao.findById(1);
		route.setLength(2100);
		routeDao.update(route);
	}

	@Test
	public void testDelete() throws Exception {
		Route route = routeDao.findById(1);
		routeDao.delete(route);
	}

}
