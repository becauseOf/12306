package com.neusoft.My12306.dao.impl;

import static org.junit.Assert.*;

import org.junit.Test;


/**
 * @author wangzhihao
 *
 * 下午9:48:59 2016年9月13日
 */
public class OrderDaoTest {

	@Test
	public void testDelete() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindAll() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindById() {
		fail("Not yet implemented");
	}

	@Test
	public void testSave() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdate() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetNewId() {
		fail("Not yet implemented");
	}

}
