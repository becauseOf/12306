package com.neusoft.My12306.dao.idao;

import java.sql.SQLException;
import java.util.List;

import com.hehujun.framework.dbhelper.idao.IBaseDao;
import com.neusoft.My12306.dao.pojo.Route;

public interface IRouteDao extends IBaseDao<Route, Integer> {
	/**
	 * 获得新id
	 * 
	 * @return id
	 * @throws SQLException
	 */
	int getNewId() throws SQLException;

	/**
	 * 查询线路里程
	 * 
	 * @return
	 * @throws Exception
	 */
	long getLength(String trainid, String startStation, String endStation) throws Exception;

	/**
	 * 获取两个车站之间的所有车站名
	 * 
	 * @param from
	 * @param to
	 * @param trainid
	 * @return
	 * @throws SQLException
	 */
	List<String> getStationNameList(String from, String to, String trainid) throws SQLException;
}
