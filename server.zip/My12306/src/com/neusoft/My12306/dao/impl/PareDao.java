package com.neusoft.My12306.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hehujun.framework.dbhelper.util.IDealWithResultSet;
import com.hehujun.framework.dbhelper.util.ISetStatementParam;
import com.hehujun.framework.dbhelper.util.SQLUtil;
import com.neusoft.My12306.dao.idao.IPareDao;
import com.neusoft.My12306.dao.pojo.Pare;

public class PareDao implements IPareDao {

	@Override
	public void delete(Pare pare) throws Exception {
		String sql = "delete from t_pare where pareid=?";
		SQLUtil.delete(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, pare.getPareid());
			}
		});
	}

	@Override
	public List<Pare> findAll() throws Exception {
		String sql = "SELECT JAVA.T_PARE.PAREID, JAVA.T_PARE.TICKET_TYPE, "
				+ "JAVA.T_PARE.PARE, JAVA.T_PARE.RATIO FROM JAVA.T_PARE order by pareid asc";
		List<Object> oList = SQLUtil.find(sql, new IDealWithResultSet<Pare>() {

			@Override
			public Pare dealWithResultSet(ResultSet rs) throws SQLException {
				Pare pare = new Pare();
				pare.setPareid(rs.getInt(1));
				pare.setTicketType(rs.getString(2));
				pare.setPare(rs.getBigDecimal(3));
				pare.setRatio(rs.getInt(4));
				return pare;
			}
		});
		List<Pare> pareList = new ArrayList<Pare>();
		for (Object o : oList) {
			pareList.add((Pare) o);
		}
		return pareList;
	}

	@Override
	public Pare findById(Integer id) throws Exception {
		String sql = "SELECT JAVA .T_PARE.PAREID, JAVA .T_PARE.TICKET_TYPE, "
				+ "JAVA .T_PARE.PARE, JAVA .T_PARE.RATIO FROM JAVA .T_PARE "
				+ "WHERE pareid=? ORDER BY pareid ASC";
		List<Object> oList = SQLUtil.find(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, id);
			}
		}, new IDealWithResultSet<Pare>() {

			@Override
			public Pare dealWithResultSet(ResultSet rs) throws SQLException {
				Pare pare = new Pare();
				pare.setPareid(rs.getInt(1));
				pare.setTicketType(rs.getString(2));
				pare.setPare(rs.getBigDecimal(3));
				pare.setRatio(rs.getInt(4));
				return pare;
			}
		});
		Pare pare = null;
		if (!oList.isEmpty()) {
			pare = (Pare) oList.get(0);
		}
		return pare;
	}

	@Override
	public void save(Pare pare) throws Exception {
		String sql = "insert into t_pare(pareid, ticket_type, pare, ratio) " + "values(?,?,?,?)";
		SQLUtil.save(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, pare.getPareid());
				ps.setString(2, pare.getTicketType());
				ps.setBigDecimal(3, pare.getPare());
				ps.setInt(4, pare.getRatio());
			}
		});
	}

	@Override
	public void update(Pare pare) throws Exception {
		String sql = "update t_pare set ticket_type=?, pare=?, ratio=? where pareid=?";
		SQLUtil.update(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, pare.getTicketType());
				ps.setBigDecimal(2, pare.getPare());
				ps.setInt(3, pare.getRatio());
				ps.setInt(4, pare.getPareid());
			}
		});
	}

	@Override
	public int getNewId() throws SQLException {
		String sql = "select max(pareid) from t_pare";
		List<Object> i = SQLUtil.executeAndGetResult(sql, new IDealWithResultSet<Integer>() {

			@Override
			public Integer dealWithResultSet(ResultSet rs) throws SQLException {
				Integer i = new Integer(rs.getInt(1) + 1);
				return i;
			}
		});
		return (i.size() == 0 ? 0 : (int) i.get(0));
	}

}
