package com.neusoft.My12306.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hehujun.framework.dbhelper.util.IDealWithResultSet;
import com.hehujun.framework.dbhelper.util.ISetStatementParam;
import com.hehujun.framework.dbhelper.util.SQLUtil;
import com.neusoft.My12306.dao.idao.IDydjlDao;
import com.neusoft.My12306.dao.pojo.Dydjl;

public class DydjlDao implements IDydjlDao {

	@Override
	public void delete(Dydjl dydjl) throws Exception {
		String sql = "delete from t_dydjl where dydjlid=?";
		SQLUtil.delete(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, dydjl.getDydjlid());
			}
		});

	}

	@Override
	public List<Dydjl> findAll() throws Exception {
		String sql = "SELECT JAVA.T_DYDJL.DYDJLID, JAVA.T_DYDJL.MILEAGE_SECTIONFROM,"
				+ " JAVA.T_DYDJL.MILEAGE_SECTIONTO, JAVA.T_DYDJL.LAPSE_RATE,"
				+ " JAVA.T_DYDJL.FARES, JAVA.T_DYDJL.EACH_TOTAL, JAVA.T_DYDJL.TOTAL"
				+ " FROM JAVA.T_DYDJL order by dydjlid";
		List<Object> oList = SQLUtil.find(sql, new IDealWithResultSet<Dydjl>() {

			@Override
			public Dydjl dealWithResultSet(ResultSet rs) throws SQLException {
				Dydjl dydjl = new Dydjl();
				dydjl.setDydjlid(rs.getInt(1));
				dydjl.setMileageSectionFrom(rs.getString(2));
				dydjl.setMileageSectionTo(rs.getString(3));
				dydjl.setLapseRate(rs.getInt(4));
				dydjl.setFares(rs.getBigDecimal(5));
				dydjl.setEachTotal(rs.getBigDecimal(6));
				dydjl.setTotal(rs.getBigDecimal(7));
				return dydjl;
			}
		});
		List<Dydjl> dydjlList = new ArrayList<Dydjl>();
		for (Object o : oList) {
			dydjlList.add((Dydjl) o);
		}
		return dydjlList;
	}

	@Override
	public Dydjl findById(Integer id) throws Exception {
		String sql = "SELECT JAVA.T_DYDJL.DYDJLID, JAVA.T_DYDJL.MILEAGE_SECTIONFROM,"
				+ " JAVA.T_DYDJL.MILEAGE_SECTIONTO, JAVA.T_DYDJL.LAPSE_RATE,"
				+ " JAVA.T_DYDJL.FARES, JAVA.T_DYDJL.EACH_TOTAL, JAVA.T_DYDJL.TOTAL"
				+ " FROM JAVA.T_DYDJL where dydjlid=? order by dydjlid";
		List<Object> oList = SQLUtil.find(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, id);

			}
		}, new IDealWithResultSet<Dydjl>() {

			@Override
			public Dydjl dealWithResultSet(ResultSet rs) throws SQLException {
				Dydjl dydjl = new Dydjl();
				dydjl.setDydjlid(rs.getInt(1));
				dydjl.setMileageSectionFrom(rs.getString(2));
				dydjl.setMileageSectionTo(rs.getString(3));
				dydjl.setLapseRate(rs.getInt(4));
				dydjl.setFares(rs.getBigDecimal(5));
				dydjl.setEachTotal(rs.getBigDecimal(6));
				dydjl.setTotal(rs.getBigDecimal(7));
				return dydjl;
			}
		});
		Dydjl dydjl = null;
		if (!oList.isEmpty()) {
			dydjl = (Dydjl) oList.get(0);
		}
		return dydjl;
	}

	@Override
	public void save(Dydjl dydjl) throws Exception {
		String sql = "insert into t_dydjl(dydjlid, mileage_sectionfrom, "
				+ "mileage_sectionto, lapse_rate, fares, each_total, " + "total) values(?,?,?,?,?,?,?)";
		SQLUtil.save(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, dydjl.getDydjlid());
				ps.setString(2, dydjl.getMileageSectionFrom());
				ps.setString(3, dydjl.getMileageSectionTo());
				ps.setInt(4, dydjl.getLapseRate());
				ps.setBigDecimal(5, dydjl.getFares());
				ps.setBigDecimal(6, dydjl.getEachTotal());
				ps.setBigDecimal(7, dydjl.getTotal());
			}
		});
	}

	@Override
	public void update(Dydjl dydjl) throws Exception {
		String sql = "update t_dydjl set mileage_sectionfrom=?, " + "mileage_sectionto=?, lapse_rate=?, fares=?, "
				+ "each_total=?, total=? where dydjlid=?";
		SQLUtil.save(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, dydjl.getMileageSectionFrom());
				ps.setString(2, dydjl.getMileageSectionTo());
				ps.setInt(3, dydjl.getLapseRate());
				ps.setBigDecimal(4, dydjl.getFares());
				ps.setBigDecimal(5, dydjl.getEachTotal());
				ps.setBigDecimal(6, dydjl.getTotal());
				ps.setInt(7, dydjl.getDydjlid());
			}
		});
	}

	@Override
	public int getNewId() throws SQLException {
		String sql = "select max(dydjlid) from t_dydjl";
		List<Object> i = SQLUtil.executeAndGetResult(sql, new IDealWithResultSet<Integer>() {

			@Override
			public Integer dealWithResultSet(ResultSet rs) throws SQLException {
				Integer i = new Integer(rs.getInt(1) + 1);
				return i;
			}
		});
		return (i.size() == 0 ? 0 : (int) i.get(0));
	}

}
