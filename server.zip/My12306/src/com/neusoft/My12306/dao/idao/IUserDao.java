package com.neusoft.My12306.dao.idao;

import com.hehujun.framework.dbhelper.idao.IBaseDao;
import com.neusoft.My12306.dao.pojo.Order;
import com.neusoft.My12306.dao.pojo.Ticket;
import com.neusoft.My12306.dao.pojo.User;

import java.sql.SQLException;
import java.util.List;

public interface IUserDao extends IBaseDao<User, Integer> {
	/**
	 * 获得新id
	 * 
	 * @return id
	 */
	int getNewId() throws SQLException;

	User findByEmail(String email) throws Exception;

    List queryTicket(String fromCity, String toCity, String date, boolean isOnlyQueryG, boolean isOnlyQueryZ) throws Exception;

    boolean generateOrder(Ticket ticket, Order order) throws Exception;

    boolean operateOrder(int orderid,int operation) throws Exception;

    boolean operateOrder(int orderid,Ticket ticket) throws Exception;

    List queryOrder(String userId) throws Exception;

	void updateByEmail(User user) throws Exception;
}
