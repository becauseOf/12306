package com.neusoft.My12306.service.iservice;

import java.util.List;

import com.neusoft.My12306.dao.pojo.Station;

public interface IBaseService<T, K> {
	String save(T station, int permission);
	String delete(T station, int permission);
	String update(T station, int permission);
	Station findById(K id, int permission);
	List<T> findAll(int permission);
}
