package com.neusoft.My12306.action.servlet.basedata;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.My12306.action.dispatch.basedata.DealWithOrganize;
import com.neusoft.My12306.dao.pojo.Organize;
import com.neusoft.My12306.dao.pojo.Train;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.IOrganizeService;
import com.neusoft.My12306.service.iservice.basedata.ITrainService;

@WebServlet("/OrganizeServlet")
public class OrganizeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private IOrganizeService organizeService;
	private ITrainService trainService;

	public OrganizeServlet() {
		super();
		organizeService = ServiceFactory.getOrganizeService();
		trainService = ServiceFactory.getTrainService();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String operation = request.getParameter("operation");
		// 获取当前管理员的权限
		int permission = 1;
		// 返回列车编组管理主页
		if (operation == null || request.getAttribute("DeleteError") != null) {
			List<Organize> organizeList = organizeService.findAll(permission);
			request.setAttribute("organizeList", organizeList);
			request.getRequestDispatcher("WEB-INF/view/basedata/organizeManager.jsp").forward(request, response);
			// 处理新建列车编组
		} else if ("create".equalsIgnoreCase(operation)) {
			if (request.getParameter("submit") != null) {
				String result = DealWithOrganize.createOrganize(request, organizeService, permission);
				if ("success".equals(result)) {
					response.sendRedirect("OrganizeServlet");
				} else {
					request.setAttribute("message", result);
					request.getRequestDispatcher("WEB-INF/view/basedata/newOrganize.jsp").forward(request, response);
				}
			} else {
				List<Train> trainList = trainService.findAll(permission);
				request.getSession().setAttribute("trainList", trainList);
				request.getRequestDispatcher("WEB-INF/view/basedata/newOrganize.jsp").forward(request, response);
			}
			// 处理列车编组信息更新
		} else if ("update".equalsIgnoreCase(operation)) {
			if (request.getParameter("submit") != null) {
				String result = DealWithOrganize.updateOrganize(request, organizeService, permission);
				if ("success".equals(result)) {
					response.sendRedirect("OrganizeServlet");
				} else {
					request.setAttribute("message", result);
					request.getRequestDispatcher("WEB-INF/view/basedata/reviseOrganize.jsp").forward(request, response);
				}
			} else {
				List<Train> trainList = trainService.findAll(permission);
				request.getSession().setAttribute("trainList", trainList);
				int id = Integer.parseInt(request.getParameter("organizeid"));
				Organize organize = organizeService.findById(id, permission);
				request.setAttribute("organize", organize);
				request.getRequestDispatcher("WEB-INF/view/basedata/reviseOrganize.jsp").forward(request, response);
			}
			// 处理列车编组信息删除
		} else if ("delete".equalsIgnoreCase(operation)) {
			String result = DealWithOrganize.deleteOrganize(request, organizeService, permission);
			if ("success".equals(result)) {
				response.sendRedirect("OrganizeServlet");
			} else {
				request.setAttribute("message", result);
				// 标记这是删除出错的转发
				request.setAttribute("DeleteError", true);
				request.getRequestDispatcher("OrganizeServlet").forward(request, response);
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
