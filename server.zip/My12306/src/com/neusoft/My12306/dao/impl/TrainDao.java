package com.neusoft.My12306.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hehujun.framework.dbhelper.util.IDealWithResultSet;
import com.hehujun.framework.dbhelper.util.ISetStatementParam;
import com.hehujun.framework.dbhelper.util.SQLUtil;
import com.neusoft.My12306.dao.idao.ITrainDao;
import com.neusoft.My12306.dao.pojo.Train;

public class TrainDao implements ITrainDao {

	@Override
	public void delete(Train train) throws Exception {
		String sql = "delete from t_train where trainid=?";
		SQLUtil.delete(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, train.getTrainid());
			}
		});
	}

	@Override
	public List<Train> findAll() throws Exception {
		String sql = "select trainid, START_STATION, END_STATION, to_char(START_TIME, 'hh24:mi:ss'),"
				+ " to_char(END_TIME, 'hh24:mi:ss'), to_char(TIME, 'hh24:mi:ss'), "
				+ "LENGTH, COUNT, BODY_CATEGORY, CATEGORY from T_TRAIN";
		List<Object> oList = SQLUtil.find(sql, new IDealWithResultSet<Train>() {

			@Override
			public Train dealWithResultSet(ResultSet rs) throws SQLException {
				Train train = new Train();
				train.setTrainid(rs.getString(1));
				train.setStartStation(rs.getString(2));
				train.setEndStation(rs.getString(3));
				train.setStartTime(rs.getString(4));
				train.setEndTime(rs.getString(5));
				train.setTime(rs.getString(6));
				train.setLength(rs.getLong(7));
				train.setCount(rs.getInt(8));
				train.setBodyCategory(rs.getString(9));
				train.setCategory(rs.getString(10));
				return train;
			}
		});

		List<Train> trainList = new ArrayList<Train>();
		for (Object o : oList) {
			trainList.add((Train) o);
		}
		return trainList;
	}

	@Override
	public Train findById(String id) throws Exception {
		String sql = "select trainid, START_STATION, END_STATION, to_char(START_TIME, 'hh24:mi:ss'),"
				+ " to_char(END_TIME, 'hh24:mi:ss'), to_char(TIME, 'hh24:mi:ss'), "
				+ "LENGTH, COUNT, BODY_CATEGORY, CATEGORY from t_train where trainid=?";
		List<Object> oList = SQLUtil.find(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, id);

			}
		}, new IDealWithResultSet<Train>() {

			@Override
			public Train dealWithResultSet(ResultSet rs) throws SQLException {
				Train train = new Train();
				train.setTrainid(rs.getString(1));
				train.setStartStation(rs.getString(2));
				train.setEndStation(rs.getString(3));
				train.setStartTime(rs.getString(4));
				train.setEndTime(rs.getString(5));
				train.setTime(rs.getString(6));
				train.setLength(rs.getLong(7));
				train.setCount(rs.getInt(8));
				train.setBodyCategory(rs.getString(9));
				train.setCategory(rs.getString(10));
				return train;
			}
		});
		Train train = null;
		if (!oList.isEmpty()) {
			train = (Train) oList.get(0);
		}
		return train;
	}

	@Override
	public void save(Train train) throws Exception {
		String sql = "insert into t_train(TRAINID, START_STATION, END_STATION, START_TIME, "
				+ "END_TIME, TIME, LENGTH, COUNT, BODY_CATEGORY, CATEGORY) values(?,?,?,"
				+ "to_date(?,'hh24:mi:ss'),to_date(?,'hh24:mi:ss'),to_date(?,'hh24:mi:ss'),?,?,?,?)";
		SQLUtil.save(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, train.getTrainid());
				ps.setString(2, train.getStartStation());
				ps.setString(3, train.getEndStation());
				ps.setString(4, train.getStartTime());
				ps.setString(5, train.getEndTime());
				ps.setString(6, train.getTime());
				ps.setLong(7, train.getLength());
				ps.setInt(8, train.getCount());
				ps.setString(9, train.getBodyCategory());
				ps.setString(10, train.getCategory());
			}
		});
	}

	@Override
	public void update(Train train) throws Exception {
		String sql = "update t_train set START_STATION=?, END_STATION=?, START_TIME=to_date(?,'hh24:mi:ss'), "
				+ "END_TIME=to_date(?,'hh24:mi:ss'), TIME=to_date(?,'hh24:mi:ss'), LENGTH=?, COUNT=?,"
				+ " BODY_CATEGORY=?, CATEGORY=? where trainid=?";
		SQLUtil.update(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, train.getStartStation());
				ps.setString(2, train.getEndStation());
				ps.setString(3, train.getStartTime());
				ps.setString(4, train.getEndTime());
				ps.setString(5, train.getTime());
				ps.setLong(6, train.getLength());
				ps.setInt(7, train.getCount());
				ps.setString(8, train.getBodyCategory());
				ps.setString(9, train.getCategory());
				ps.setString(10, train.getTrainid());
			}
		});
	}

}
