package com.neusoft.My12306.util;

import org.junit.Test;

import com.neusoft.My12306.dao.pojo.Seat;

public class CalculatePriceTest {

	@Test
	public void testGetPrice() {
//		Seat seat = new Seat(1,"Z202",1,"", "广州","北京","","");
//		System.out.println(CalculatePrice.getPrice(seat));
	}

}
