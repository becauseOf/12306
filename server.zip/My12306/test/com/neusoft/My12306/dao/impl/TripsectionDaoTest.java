package com.neusoft.My12306.dao.impl;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.ITripsectionDao;
import com.neusoft.My12306.dao.pojo.Tripsection;

/**
 * @author wangzhihao
 *
 *         下午9:49:30 2016年9月13日
 */
public class TripsectionDaoTest {
	private ITripsectionDao trDao;

	@Before
	public void setUp() {
		trDao = DaoFactory.getTripsectionDao();
	}

	@Test
	public void testGetNewId() throws SQLException {
		System.out.println(trDao.getNewId());
	}

	@Test
	public void testSave() throws Exception {
		Tripsection tr = new Tripsection(trDao.getNewId(), "1", "200", 10, 20);
		trDao.save(tr);
	}

	@Test
	public void testFindAll() throws Exception {
		List<Tripsection> trList = trDao.findAll();
		for (Tripsection tr : trList) {
			System.out.println(tr);
		}
	}

	@Test
	public void testFindById() throws Exception {
		Tripsection tr = trDao.findById(1);
		assertEquals(1, tr.getTripsectionid());
		assertEquals("1", tr.getMileageSectionFrom());
		assertEquals("200", tr.getMileageSectionTo());
		assertEquals(10, tr.getLength());
		assertEquals(20, tr.getCount());
	}

	@Test
	public void testUpdate() throws Exception {
		Tripsection tr = trDao.findById(1);
		tr.setMileageSectionTo("10203");
		trDao.update(tr);
	}

	@Test
	public void testDelete() throws Exception {
		Tripsection tr = trDao.findById(1);
		trDao.delete(tr);
	}

}
