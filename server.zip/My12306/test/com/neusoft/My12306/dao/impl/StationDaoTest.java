package com.neusoft.My12306.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IStationDao;
import com.neusoft.My12306.dao.pojo.Station;

public class StationDaoTest {

	private IStationDao stationDao;

	@Before
	public void setUp() throws Exception {
		stationDao = DaoFactory.getStationDao();
	}

	@Test
	public void testGetNewId() throws SQLException {
		System.out.println(stationDao.getNewId());
	}

	@Test
	public void testSave() {
		try {
			Station station = new Station(stationDao.getNewId(), "上海", "SH", "上海", "上海铁路", "特", "上海");
			stationDao.save(station);
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}

	@Test
	public void testFindAll() throws Exception {
		List<Station> stationList = stationDao.findAll();
		for (Station station : stationList) {
			System.out.println(station);
		}
	}

	@Test
	public void testFindById() throws Exception {
		Station station = stationDao.findById(5);
		System.out.println(station);
	}

	@Test
	public void testFindByName() throws SQLException {
		Station station = (stationDao.findByName("广")).get(0);
		System.out.println(station);
	}

	@Test
	public void testFindByPinyin() throws SQLException {
		Station station = (stationDao.findByPinyin("G")).get(0);
		System.out.println(station);
	}

	@Test
	public void testUpdate() throws Exception {
		Station station = stationDao.findById(5);
		station.setAddress("四川");
		station.setStationname("四川");
		station.setPingyin("SC");
		station.setAdministrativeArea("四川");
		station.setRailwayStation("四川");
		station.setStationLevel("二");
		stationDao.update(station);
	}

	@Test
	public void testDelete() throws Exception {
		Station station = stationDao.findById(5);
		stationDao.delete(station);
	}

}
