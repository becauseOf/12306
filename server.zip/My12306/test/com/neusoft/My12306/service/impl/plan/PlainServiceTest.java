package com.neusoft.My12306.service.impl.plan;

import static org.junit.Assert.fail;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.pojo.Plain;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.plan.IPlainService;

public class PlainServiceTest {
	
	IPlainService plainService;

	@Before
	public void setUp() throws Exception {
		plainService = ServiceFactory.getPlainService();
	}

	@Test
	public void testSave() {
		Plain plain = new Plain(0,"G94",1,"=","广州");
		plainService.save(plain, 2);
	}

	@Test
	public void testDelete() {
		Plain plain = plainService.findById(2, 2);
		plainService.delete(plain, 2);
	}

	@Test
	public void testUpdate() {
		Plain plain = plainService.findById(2, 2);
		plain.setNum(10);
		plainService.update(plain, 2);
	}

	@Test
	public void testFindByTrain() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindById() {
		Plain plain = plainService.findById(2, 2);
		System.out.println(plain);
	}

	@Test
	public void testFindAll() {
		List<Plain> plainList = plainService.findAll(2);
		for(Plain p : plainList){
			System.out.println(p);
		}
	}

	@Test
	public void testDoPlain() {
		fail("Not yet implemented");
	}

}
