package com.neusoft.My12306.util;

public enum AdminPermission {
	//超级管理员
	SUPER_ADMIN, 
	//基础数据管理员
	BASEDATE_ADMIN,
	//计划管理员
	PLAN_ADMIN,
	//调度管理员
	DISPATCH_ADMIN,
	//客服管理员
	STAFF_ADMIN, 
	//财务管理员
	FINANCE_ADMIN
}
