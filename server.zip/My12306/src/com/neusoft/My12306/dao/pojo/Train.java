package com.neusoft.My12306.dao.pojo;

/**
 * 车次信息
 * 
 * @author hezhujun
 *
 */
public class Train {
	private String trainid;
	private String startStation;
	private String endStation;
	private String startTime;
	private String endTime;
	private String time;
	private long length;
	private int count;
	private String bodyCategory;
	private String category;

	public String getTrainid() {
		return trainid;
	}

	public void setTrainid(String trainid) {
		this.trainid = trainid;
	}

	public String getStartStation() {
		return startStation;
	}

	public void setStartStation(String startStation) {
		this.startStation = startStation;
	}

	public String getEndStation() {
		return endStation;
	}

	public void setEndStation(String endStation) {
		this.endStation = endStation;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public long getLength() {
		return length;
	}

	public void setLength(long length) {
		this.length = length;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getBodyCategory() {
		return bodyCategory;
	}

	public void setBodyCategory(String bodyCategory) {
		this.bodyCategory = bodyCategory;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Train() {
		// TODO Auto-generated constructor stub
	}

	public Train(String trainid, String startStation, String endStation, String startTime, String endTime, String time,
			long length, int count, String bodyCategory, String category) {
		super();
		this.trainid = trainid;
		this.startStation = startStation;
		this.endStation = endStation;
		this.startTime = startTime;
		this.endTime = endTime;
		this.time = time;
		this.length = length;
		this.count = count;
		this.bodyCategory = bodyCategory;
		this.category = category;
	}

	@Override
	public String toString() {
		return "Train [trainid=" + trainid + ", startStation=" + startStation + ", endStation=" + endStation
				+ ", startTime=" + startTime + ", endTime=" + endTime + ", time=" + time + ", length=" + length
				+ ", count=" + count + ", bodyCategory=" + bodyCategory + ", category=" + category + "]";
	}

}
