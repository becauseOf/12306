package com.neusoft.My12306.dao.idao;

import java.sql.SQLException;

import com.hehujun.framework.dbhelper.idao.IBaseDao;
import com.neusoft.My12306.dao.pojo.Tripsection;

public interface ITripsectionDao extends IBaseDao<Tripsection, Integer> {
	/**
	 * 获得新id
	 * 
	 * @return id
	 * @throws SQLException 
	 */
	int getNewId() throws SQLException;
}
