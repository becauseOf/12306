package com.neusoft.My12306.dao.idao;

import java.sql.SQLException;
import java.util.List;

import com.hehujun.framework.dbhelper.idao.IBaseDao;
import com.neusoft.My12306.dao.pojo.Plain;

public interface IPlainDao extends IBaseDao<Plain, Integer> {
	/**
	 * 获得新id
	 * 
	 * @return id
	 * @throws SQLException 
	 */
	int getNewId() throws SQLException;
	
	/**
	 * 通过车次名查询
	 * 
	 * @param trainid
	 * @return 
	 * @throws SQLException 
	 */
	List<Plain> findBytrainid(String trainid) throws SQLException;
}
