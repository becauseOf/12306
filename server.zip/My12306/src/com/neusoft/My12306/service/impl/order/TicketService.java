package com.neusoft.My12306.service.impl.order;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.neusoft.My12306.bean.TicketBean;
import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.ISeatDao;
import com.neusoft.My12306.dao.idao.ITicketDao;
import com.neusoft.My12306.dao.pojo.Seat;
import com.neusoft.My12306.dao.pojo.Ticket;
import com.neusoft.My12306.service.iservice.order.ITicketService;
import com.neusoft.My12306.util.AdminPermission;
import com.neusoft.My12306.util.CalculatePrice;

public class TicketService implements ITicketService {

	private static Logger logger = Logger.getLogger(TicketService.class);

	private ISeatDao seatDao;
	private ITicketDao ticketDao;

	public TicketService() {
		seatDao = DaoFactory.getSeatDao();
		ticketDao = DaoFactory.getTicketDaoInstance();
	}

	@Override
	public List<TicketBean> getTicketBean(String from, String to, String day) {
		List<TicketBean> ticketBeanList = null;
		try {
			ticketBeanList = seatDao.getTicketInfo(from, to);
			for (TicketBean ticketBean : ticketBeanList) {
				ticketBean.setDate(day);

				ticketBean.setYingzuo(seatDao.getTicketCount(ticketBean, "硬座"));
				if (ticketBean.getYingzuo() != 0) {
					ticketBean.setYingzuoPrice(CalculatePrice.getPrice(ticketBean.getStartStation(),
							ticketBean.getEndStation(), "硬座", ticketBean.getTrainid()));
				}

				ticketBean.setRuanzuo(seatDao.getTicketCount(ticketBean, "软座"));
				if (ticketBean.getRuanzuo() != 0) {
					ticketBean.setRuanzuoPrice(CalculatePrice.getPrice(ticketBean.getStartStation(),
							ticketBean.getEndStation(), "软座", ticketBean.getTrainid()));
				}

				ticketBean.setYingwo(seatDao.getTicketCount(ticketBean, "硬卧"));
				if (ticketBean.getYingwo() != 0) {
					ticketBean.setYingwoPrice(CalculatePrice.getPrice(ticketBean.getStartStation(),
							ticketBean.getEndStation(), "硬卧", ticketBean.getTrainid()));
				}

				ticketBean.setRuanwo(seatDao.getTicketCount(ticketBean, "软卧"));
				if (ticketBean.getRuanwo() != 0) {
					ticketBean.setRuanwoPrice(CalculatePrice.getPrice(ticketBean.getStartStation(),
							ticketBean.getEndStation(), "软卧", ticketBean.getTrainid()));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ticketBeanList;
	}

	@Override
	public List<Ticket> getTicketByIdcard(String idcard) {
		List<Ticket> list = new ArrayList<Ticket>();
		try {
			list.addAll(ticketDao.findByPhoneId(idcard));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Ticket getTicketById(int id) {
		Ticket ticket = null;
		try {
			ticket = ticketDao.findById(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ticket;
	}

	@Override
	public Seat selectSeat(String from, String to, String trainid, String seatClass, String day) {
		Seat seat = null;
		try {
			seat = seatDao.selectSeat(from, to, trainid, seatClass, day);
			logger.info("获取一张余票: " + seat);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("获取余票失败");
		}
		return seat;
	}

	@Override
	public String selectedSeat(int id) {
		try {
			seatDao.selectedSeat(id);
			logger.info("出售了席位: " + id);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
			return "error";
		}
	}

	@Override
	public String cancelSeat(int id) {
		try {
			seatDao.cancelSeat(id);
			logger.info("重置席位信息: " + id);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
			return "error";
		}
	}

	@Override
	public String lockToggle(int id, String state) {
		try {
			seatDao.lockToggle(id, state);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
			return "error";
		}
	}

	@Override
	public String update(Ticket ticket, int permission) {
		if (permission == AdminPermission.STAFF_ADMIN.ordinal()) {
			try {
				logger.info("正在更新车票信息： " + ticket);
				ticketDao.update(ticket);
				logger.info("成功更新车票信息： " + ticket);
				return "success";
			} catch (Exception e) {
				e.printStackTrace();
				logger.error(e);
				logger.info("失败更新车票信息： " + ticket);
				return "error";
			}
		} else {
			return "权限不够";
		}
	}

}
