package com.neusoft.My12306.service.impl.basedata;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.pojo.Train;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.ITrainService;

public class TrainServiceTest {

	private ITrainService trainService;

	@Before
	public void setUp() throws Exception {
		trainService = ServiceFactory.getTrainService();
	}

	@Test
	public void testSave() {
		Train train = new Train("G946", "广州南", "北京", "08:00:00", "17:30:00", 
				"09:30:00", 2197, 0, "普通", "特快");
		trainService.save(train, 1);
	}

	@Test
	public void testFindAll() {
		List<Train> trainList = trainService.findAll(1);
		for (Train train : trainList) {
			System.out.println(train);
		}
	}

	@Test
	public void testFindById() {
		Train train = trainService.findById("G946", 1);
		System.out.println(train);
	}

	@Test
	public void testUpdate() {
		Train train = trainService.findById("G946", 1);
		train.setCategory("高铁");
		trainService.update(train, 1);
	}

	@Test
	public void testDelete() {
		Train train = trainService.findById("G946", 1);
		trainService.delete(train, 1);
	}

}
