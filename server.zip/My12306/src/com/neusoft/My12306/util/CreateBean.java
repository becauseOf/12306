package com.neusoft.My12306.util;

import java.lang.reflect.Field;
import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;

/**
 * 从request获取需要的bean
 * 
 * @author hezhujun
 *
 */
public class CreateBean {

	/**
	 * 从request获取需要的bean
	 * 
	 * @param <T>
	 * 
	 * @param clazz
	 *            bean的class对象
	 * @param request
	 *            request
	 * @return
	 */
	public static <T> T getBean(Class<T> clazz, HttpServletRequest request) {
		T t = null;
		try {
			t = clazz.newInstance();
			Field[] fields = clazz.getDeclaredFields();
			for (int i = 0; i < fields.length; i++) {
				fields[i].setAccessible(true);
				String name = fields[i].getName();
				Class<?> fieldType = fields[i].getType();
				String valueStr = request.getParameter(name);
				if (valueStr == null) {
					// 获取不到内容就直接下一个循环
					continue;
				}
				Object value = null;
				if (int.class.equals(fieldType) || Integer.class.equals(fieldType)) {
					value = Integer.parseInt(valueStr);
				} else if (long.class.equals(fieldType) || Long.class.equals(fieldType)) {
					value = Long.parseLong(valueStr);
				} else if (double.class.equals(fieldType) || Double.class.equals(fieldType)) {
					value = Double.parseDouble(valueStr);
				} else if (BigDecimal.class.equals(fieldType)) {
					value = new BigDecimal(valueStr);
				} else if (String.class.equals(fieldType)) {
					value = valueStr;
				}
				fields[i].set(t, value);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return t;
	}

}
