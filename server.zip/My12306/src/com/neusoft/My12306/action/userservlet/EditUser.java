package com.neusoft.My12306.action.userservlet;

import com.google.gson.JsonObject;
import com.neusoft.My12306.dao.pojo.User;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.user.IUserService;
import com.neusoft.My12306.util.GsonUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 用户编辑个人信息
 * Created by xiangsong on 2016/9/17.
 */
@WebServlet("/EditUser")
public class EditUser extends HttpServlet{

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String content = request.getParameter("user");
        User user = (User) GsonUtil.fromJson(content,User.class);

        IUserService userService = ServiceFactory.getUserServiceInstance();

        JsonObject result = new JsonObject();

        boolean resultData = userService.editUser(user);

        result.addProperty("content",resultData);

        response.getWriter().println(result.toString());
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        doPost(request, response);
    }

}
