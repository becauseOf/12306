package com.neusoft.My12306.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hehujun.framework.dbhelper.util.IDealWithResultSet;
import com.hehujun.framework.dbhelper.util.ISetStatementParam;
import com.hehujun.framework.dbhelper.util.SQLUtil;
import com.neusoft.My12306.dao.idao.ITicketDao;
import com.neusoft.My12306.dao.pojo.Ticket;

public class TicketDao implements ITicketDao {

	@Override
	public void delete(Ticket arg0) throws Exception {
		// TODO Auto-generated method stub
		String sql = "DELETE FROM T_TICKET WHERE TICKETID=?";
		SQLUtil.delete(sql, new ISetStatementParam() {
			@Override
			public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setInt(1, arg0.getTicketid());
			}
		});
	}

	@Override
	public List<Ticket> findAll() throws Exception {
		String sql = "SELECT TICKETID,TRAINID,TDATE,TRAINBOX,SEATNUM,START_STATION,END_STATION,NAME,TPASGTYPE,TUIDPHONE,PRICE FROM T_TICKET";
		List<Object> objectList = SQLUtil.find(sql, new IDealWithResultSet<Object>() {

			@Override
			public Object dealWithResultSet(ResultSet resultSet) throws SQLException {
				Ticket ticket = new Ticket();
				ticket.setTicketid(resultSet.getInt(1));
				ticket.setTrainid(resultSet.getString(2));
				ticket.setDate(resultSet.getString(3));
				ticket.setTrainBox(resultSet.getInt(4));
				ticket.setSeatNum(resultSet.getString(5));
				ticket.setStartStation(resultSet.getString(6));
				ticket.setEndStation(resultSet.getString(7));
				ticket.setName(resultSet.getString(8));
				ticket.setPasgtype(resultSet.getString(9));
				ticket.setIdcard(resultSet.getString(10));
				ticket.setPrice(resultSet.getDouble(11));

				return ticket;
			}
		});

		List<Ticket> tickets = new ArrayList<>();
		for (Object obj : objectList) {
			tickets.add((Ticket) obj);
		}

		return tickets;
	}

	@Override
	public Ticket findById(Integer id) throws Exception {
		String sql = "SELECT TICKETID, TRAINID, to_char(TDATE, 'yyyy-mm-dd'), TRAINBOX, SEATNUM, START_STATION, "
				+ "END_STATION, PRICE, NAME, TPASGTYPE, TUIDPHONE, TSELLTYPE, TSELLDETAIL, "
				+ "to_char(TSELLTIME, 'yyyy-mm-dd'), TTICKETSTATE, STATECHGEPLE, STATECHGSTATION, to_char(STATECHGTIME, 'yyyy-mm-dd')"
				+ "FROM T_TICKET where TICKETID=?";
		List<Object> objList = SQLUtil.find(sql, new ISetStatementParam() {
			@Override
			public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setInt(1, id);
			}
		}, new IDealWithResultSet<Object>() {

			@Override
			public Object dealWithResultSet(ResultSet resultSet) throws SQLException {
				Ticket ticket = new Ticket();
				ticket.setTicketid(resultSet.getInt(1));
				ticket.setTrainid(resultSet.getString(2));
				ticket.setDate(resultSet.getString(3));
				ticket.setTrainBox(resultSet.getInt(4));
				ticket.setSeatNum(resultSet.getString(5));
				ticket.setStartStation(resultSet.getString(6));
				ticket.setEndStation(resultSet.getString(7));
				ticket.setPrice(resultSet.getDouble(8));
				ticket.setName(resultSet.getString(9));
				ticket.setPasgtype(resultSet.getString(10));
				ticket.setIdcard(resultSet.getString(11));
				ticket.setSellType(resultSet.getString(12));
				ticket.setSellDetail(resultSet.getString(13));
				ticket.setSellTime(resultSet.getString(14));
				ticket.setTicketState(resultSet.getString(15));
				ticket.setStateChgPeople(resultSet.getString(16));
				ticket.setStateChgStation(resultSet.getString(17));
				ticket.setStateChgTime(resultSet.getString(18));
				return ticket;
			}
		});
		Ticket ticket = null;
		if (!objList.isEmpty()) {
			ticket = (Ticket) objList.get(0);
		}
		return ticket;
	}

	@Override
	public void save(Ticket arg0) throws Exception {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO T_TICKET(TICKETID, TRAINID, TDATE, TRAINBOX, SEATNUM, START_STATION, END_STATION, NAME, TPASGTYPE, TUIDPHONE,PRICE, TSELLTYPE, TSELLDETAIL, TTICKETSTATE, STATECHGSTATION, STATECHGTIME) VALUES (?,?,to_date(?,'yyyy-mm-dd'),?,?,?,?,?,?,?,?,?,?,?,?,?)";
		SQLUtil.save(sql, new ISetStatementParam() {
			@Override
			public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setInt(1, arg0.getTicketid());
				preparedStatement.setString(2, arg0.getTrainid());
				preparedStatement.setString(3, arg0.getDate());
				preparedStatement.setInt(4, arg0.getTrainBox());
				preparedStatement.setString(5, arg0.getSeatNum());
				preparedStatement.setString(6, arg0.getStartStation());
				preparedStatement.setString(7, arg0.getEndStation());
				preparedStatement.setString(8, arg0.getName());
				preparedStatement.setString(9, arg0.getPasgtype());
				preparedStatement.setString(10, arg0.getIdcard());
				preparedStatement.setDouble(11, arg0.getPrice());

				preparedStatement.setString(12, arg0.getPasgtype());
				preparedStatement.setString(13, "");
				preparedStatement.setString(14, "");//此为票的状态
				preparedStatement.setString(15, "");
				preparedStatement.setString(16, "");

			}
		});

	}

	/**
	 * 直接进行ticket的更新，主要是改签操作
	 * 
	 * @param arg0
	 * @throws Exception
	 */
	@Override
	public void update(Ticket ticket) throws Exception {
		String sql = "UPDATE T_TICKET set TRAINID=?, TDATE = to_date(?, 'yyyy-mm-dd'), TRAINBOX=?, SEATNUM=?, START_STATION=?, "
				+ "END_STATION=?, PRICE=?, NAME=?, TPASGTYPE=?, TUIDPHONE=?, TSELLTYPE=?, TSELLDETAIL=?, "
				+ "TSELLTIME = to_date(?, 'yyyy-mm-dd'), TTICKETSTATE=?, STATECHGEPLE=?, STATECHGSTATION=?, STATECHGTIME=to_date(?, 'yyyy-mm-dd') "
				+ "where TICKETID=?";
		SQLUtil.update(sql, new ISetStatementParam() {
			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, ticket.getTrainid());
				ps.setString(2, ticket.getDate());
				ps.setInt(3, ticket.getTrainBox());
				ps.setString(4, ticket.getSeatNum());
				ps.setString(5, ticket.getStartStation());
				ps.setString(6, ticket.getEndStation());
				ps.setDouble(7, ticket.getPrice());
				ps.setString(8, ticket.getName());
				ps.setString(9, ticket.getPasgtype());
				ps.setString(10, ticket.getIdcard());
				ps.setString(11, ticket.getSellType());
				ps.setString(12, ticket.getSellDetail());
				ps.setString(13, ticket.getSellTime());
				ps.setString(14, ticket.getTicketState());
				ps.setString(15, ticket.getStateChgPeople());
				ps.setString(16, ticket.getStateChgStation());
				ps.setString(17, ticket.getStateChgTime());
				ps.setInt(18, ticket.getTicketid());
			}
		});

	}

	@Override
	public int getNewId() throws Exception {
		String sql = "SELECT max(TICKETID) FROM T_TICKET";
		List<Object> i = SQLUtil.executeAndGetResult(sql, new IDealWithResultSet<Object>() {
			@Override
			public Object dealWithResultSet(ResultSet resultSet) throws SQLException {
				Integer i = new Integer(resultSet.getInt(1) + 1);
				return i;
			}
		});
		return (i.size() == 0 ? 0 : (int) i.get(0));
	}

	@Override
	public List<Ticket> findByPhoneId(String idCard) throws Exception {
		String sql = "SELECT TICKETID, TRAINID, to_char(TDATE, 'yyyy-mm-dd'), TRAINBOX, SEATNUM, START_STATION, "
				+ "END_STATION, PRICE, NAME, TPASGTYPE, TUIDPHONE, TSELLTYPE, TSELLDETAIL, "
				+ "to_char(TSELLTIME, 'yyyy-mm-dd'), TTICKETSTATE, STATECHGEPLE, STATECHGSTATION, STATECHGTIME "
				+ "FROM T_TICKET where TUIDPHONE=?";
		List<Object> objList = SQLUtil.find(sql, new ISetStatementParam() {
			@Override
			public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setString(1, idCard);
			}
		}, new IDealWithResultSet<Object>() {

			@Override
			public Object dealWithResultSet(ResultSet resultSet) throws SQLException {
				Ticket ticket = new Ticket();
				ticket.setTicketid(resultSet.getInt(1));
				ticket.setTrainid(resultSet.getString(2));
				ticket.setDate(resultSet.getString(3));
				ticket.setTrainBox(resultSet.getInt(4));
				ticket.setSeatNum(resultSet.getString(5));
				ticket.setStartStation(resultSet.getString(6));
				ticket.setEndStation(resultSet.getString(7));
				ticket.setPrice(resultSet.getDouble(8));
				ticket.setName(resultSet.getString(9));
				ticket.setPasgtype(resultSet.getString(10));
				ticket.setIdcard(resultSet.getString(11));
				ticket.setSellType(resultSet.getString(12));
				ticket.setSellDetail(resultSet.getString(13));
				ticket.setSellTime(resultSet.getString(14));
				ticket.setTicketState(resultSet.getString(15));
				ticket.setStateChgPeople(resultSet.getString(16));
				ticket.setStateChgStation(resultSet.getString(17));
				ticket.setStateChgTime(resultSet.getString(18));
				return ticket;
			}
		});

		List<Ticket> tickets = new ArrayList<>();
		for (Object o : objList) {
			tickets.add((Ticket) o);
		}
		return tickets;
	}

	@Override
	public void updateTicketStatus(String idcard, String status) throws Exception {
		String sql = "UPDATE T_TICKET set TTICKETSTATE=? WHERE TUIDPHONE=?";
		SQLUtil.update(sql, new ISetStatementParam() {
			@Override
			public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setString(1, status);
				preparedStatement.setString(2, idcard);
			}
		});
	}

}
