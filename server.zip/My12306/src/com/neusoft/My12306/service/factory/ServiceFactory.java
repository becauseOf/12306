package com.neusoft.My12306.service.factory;

import com.neusoft.My12306.service.impl.admin.AdminService;
import com.neusoft.My12306.service.impl.basedata.DydjlService;
import com.neusoft.My12306.service.impl.basedata.OrganizeService;
import com.neusoft.My12306.service.impl.basedata.PareService;
import com.neusoft.My12306.service.impl.basedata.RouteService;
import com.neusoft.My12306.service.impl.basedata.StationService;
import com.neusoft.My12306.service.impl.basedata.TrainService;
import com.neusoft.My12306.service.impl.basedata.TripsectionService;
import com.neusoft.My12306.service.impl.bill.BillService;
import com.neusoft.My12306.service.impl.order.TicketService;
import com.neusoft.My12306.service.impl.plan.PlainService;
import com.neusoft.My12306.service.impl.plan.SeatService;
import com.neusoft.My12306.service.impl.user.UserServiceImpl;
import com.neusoft.My12306.service.iservice.admin.IAdminService;
import com.neusoft.My12306.service.iservice.basedata.IDydjlService;
import com.neusoft.My12306.service.iservice.basedata.IOrganizeService;
import com.neusoft.My12306.service.iservice.basedata.IPareService;
import com.neusoft.My12306.service.iservice.basedata.IRouteService;
import com.neusoft.My12306.service.iservice.basedata.IStationService;
import com.neusoft.My12306.service.iservice.basedata.ITrainService;
import com.neusoft.My12306.service.iservice.basedata.ITripsectionService;
import com.neusoft.My12306.service.iservice.bill.IBillService;
import com.neusoft.My12306.service.iservice.order.ITicketService;
import com.neusoft.My12306.service.iservice.plan.IPlainService;
import com.neusoft.My12306.service.iservice.plan.ISeatService;
import com.neusoft.My12306.service.iservice.user.IUserService;

public class ServiceFactory {

	public static IStationService getStationService() {
		return new StationService();
	}

	public static ITrainService getTrainService() {
		return new TrainService();
	}

	public static IRouteService getRouteService() {
		return new RouteService();
	}

	public static IOrganizeService getOrganizeService() {
		return new OrganizeService();
	}

	public static IPareService getPareService() {
		return new PareService();
	}

	public static ITripsectionService getTripsectionService() {
		return new TripsectionService();
	}

	public static IDydjlService getDydjlService() {
		return new DydjlService();
	}

	public static IUserService getUserServiceInstance(){
		return new UserServiceImpl();
	}
	
	public static IPlainService getPlainService(){
		return new PlainService();
	}
	
	public static IAdminService getAdminService(){
		return new AdminService();
	}
	

	public static ITicketService getTicketService() {
		return new TicketService();
	}
	
	public static ISeatService getSeatService() {
		return new SeatService();
	}
	
	public static IBillService getBillService() {
		return new BillService();
	}

}
