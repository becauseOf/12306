package com.neusoft.My12306.action.servlet.basedata;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.My12306.action.dispatch.basedata.DealWithDydjl;
import com.neusoft.My12306.dao.pojo.Dydjl;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.IDydjlService;

@WebServlet("/DydjlServlet")
public class DydjlServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private IDydjlService dydjlService;

	public DydjlServlet() {
		super();
		dydjlService = ServiceFactory.getDydjlService();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String operation = request.getParameter("operation");
		// 获取当前管理员的权限
		int permission = 1;
		// 返回票价率管理主页
		if (operation == null) {
			List<Dydjl> dydjlList = dydjlService.findAll(permission);
			request.setAttribute("dydjlList", dydjlList);
			request.getRequestDispatcher("WEB-INF/view/basedata/dydjlManager.jsp").forward(request, response);
			// 处理票价率信息更新
		} else if ("update".equalsIgnoreCase(operation)) {
			if (request.getParameter("submit") != null) {
				String result = DealWithDydjl.updateDydjl(request, dydjlService, permission);
				if ("success".equals(result)) {
					response.sendRedirect("DydjlServlet");
				} else {
					request.setAttribute("message", result);
					request.getRequestDispatcher("WEB-INF/view/basedata/reviseDydjl.jsp").forward(request, response);
				}
			} else {
				int id = Integer.parseInt(request.getParameter("dydjlid"));
				Dydjl dydjl = dydjlService.findById(id, permission);
				request.setAttribute("dydjl", dydjl);
				request.getRequestDispatcher("WEB-INF/view/basedata/reviseDydjl.jsp").forward(request, response);
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
