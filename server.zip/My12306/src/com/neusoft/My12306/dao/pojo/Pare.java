package com.neusoft.My12306.dao.pojo;

import java.math.BigDecimal;

/**
 * 票价率信息
 * 
 * @author hezhujun
 *
 */
public class Pare {
	private int pareid;
	private String ticketType;
	private BigDecimal pare;
	private int ratio;

	public int getPareid() {
		return pareid;
	}

	public void setPareid(int pareid) {
		this.pareid = pareid;
	}

	public String getTicketType() {
		return ticketType;
	}

	public void setTicketType(String ticketType) {
		this.ticketType = ticketType;
	}

	public BigDecimal getPare() {
		return pare;
	}

	public void setPare(BigDecimal pare) {
		this.pare = pare;
	}

	public int getRatio() {
		return ratio;
	}

	public void setRatio(int ratio) {
		this.ratio = ratio;
	}

	public Pare() {
		// TODO Auto-generated constructor stub
	}

	public Pare(int pareid, String ticketType, BigDecimal pare, int ratio) {
		super();
		this.pareid = pareid;
		this.ticketType = ticketType;
		this.pare = pare;
		this.ratio = ratio;
	}

	@Override
	public String toString() {
		return "Pare [pareid=" + pareid + ", ticketType=" + ticketType + ", pare=" + pare + ", ratio=" + ratio + "]";
	}

}
