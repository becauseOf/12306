package com.neusoft.My12306.action.dispatch.basedata;

import javax.servlet.http.HttpServletRequest;

import com.neusoft.My12306.dao.pojo.Route;
import com.neusoft.My12306.service.iservice.basedata.IRouteService;
import com.neusoft.My12306.util.CreateBean;

/**
 * 处理关于路线信息的请求
 * 
 * @author hezhujun
 *
 */
public class DealWithRoute {

	public static String createRoute(HttpServletRequest request, IRouteService routeService, int permission) {
		Route route = CreateBean.getBean(Route.class, request);
		String result = "error";
		if (route != null) {
			result = routeService.save(route, permission);
		}
		return result;
	}

	public static String updateRoute(HttpServletRequest request, IRouteService routeService, int permission) {
		Route route = CreateBean.getBean(Route.class, request);
		String result = "error";
		if (route != null) {
			result = routeService.update(route, permission);
		}
		return result;
	}

	public static String deleteRoute(HttpServletRequest request, IRouteService routeService, int permission) {
		String result = "error";
		int id = 0;
		id = Integer.parseInt(request.getParameter("routeid"));
		if (id != 0) {
			Route route = new Route();
			route.setRouteid(id);
			result = routeService.delete(route, permission);
		}
		return result;
	}

}
