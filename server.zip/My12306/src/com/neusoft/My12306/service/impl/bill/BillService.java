package com.neusoft.My12306.service.impl.bill;

import java.util.List;

import org.apache.log4j.Logger;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.ISeatDao;
import com.neusoft.My12306.dao.idao.ITicketDao;
import com.neusoft.My12306.dao.pojo.Seat;
import com.neusoft.My12306.dao.pojo.Ticket;
import com.neusoft.My12306.service.iservice.bill.IBillService;
import com.neusoft.My12306.util.AdminPermission;

public class BillService implements IBillService {
	private static Logger logger = Logger.getLogger(BillService.class);

	private ITicketDao ticketDao;
	private ISeatDao seatDao;

	public BillService() {
		ticketDao = DaoFactory.getTicketDaoInstance();
		seatDao = DaoFactory.getSeatDao();
	}

	@Override
	public List<Ticket> findTicket(String from, String to) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Ticket findById(String idcard, int permission) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTicket(int id, int permission) {
		if (permission == AdminPermission.STAFF_ADMIN.ordinal()) {
			try {
				Ticket ticket = ticketDao.findById(id);
				ticket.setTicketState("取票");
				ticketDao.update(ticket);
				return "success";
			} catch (Exception e) {
				e.printStackTrace();
				return "error";
			}
		} else {
			return "权限不够";
		}
	}

	@Override
	public String returnTicket(int id, int permission) {
		if (permission == AdminPermission.STAFF_ADMIN.ordinal()) {
			Ticket ticket = null;
			try {
				ticket = ticketDao.findById(id);
				logger.info("正在退票： " + ticket);
				ticket.setTicketState("退票");
				// 更新席位信息
				Seat seat = seatDao.getSeat(ticket.getStartStation(), ticket.getEndStation(), ticket.getTrainid(),
						ticket.getTrainBox(), ticket.getSeatNum(), ticket.getDate());
				logger.info("退票修改席位信息： " + seat);
				seatDao.cancelSeat(seat.getSeatid());
				// 更新车票信息
				ticketDao.update(ticket);
				logger.info("成功退票： " + ticket);
				return "success";
			} catch (Exception e) {
				e.printStackTrace();
				logger.error(e);
				logger.info("失败退票： " + ticket);
				return "error";
				
			}
		} else {
			return "权限不够";
		}
	}

	@Override
	public String modifyTicket(Ticket ticket, int permission) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String signChangeTicket(Ticket ticket, int permission) {
		// TODO Auto-generated method stub
		return null;
	}

}
