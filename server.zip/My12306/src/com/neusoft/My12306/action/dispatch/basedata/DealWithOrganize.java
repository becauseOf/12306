package com.neusoft.My12306.action.dispatch.basedata;

import javax.servlet.http.HttpServletRequest;

import com.neusoft.My12306.dao.pojo.Organize;
import com.neusoft.My12306.service.iservice.basedata.IOrganizeService;
import com.neusoft.My12306.util.CreateBean;

public class DealWithOrganize {

	public static String createOrganize(HttpServletRequest request, IOrganizeService organizeService, int permission) {
		Organize organize = CreateBean.getBean(Organize.class, request);
		String result = "error";
		if (organize != null) {
			result = organizeService.save(organize, permission);
		}
		return result;
	}

	public static String updateOrganize(HttpServletRequest request, IOrganizeService organizeService, int permission) {
		Organize organize = CreateBean.getBean(Organize.class, request);
		String result = "error";
		if (organize != null) {
			result = organizeService.update(organize, permission);
		}
		return result;
	}

	public static String deleteOrganize(HttpServletRequest request, IOrganizeService organizeService, int permission) {
		Organize organize = new Organize();
		int id = 0;
		id = Integer.parseInt(request.getParameter("organizeid"));
		organize.setOrganizeid(id);
		String result = "error";
		if (id != 0) {
			result = organizeService.delete(organize, permission);
		}
		return result;
	}

}
