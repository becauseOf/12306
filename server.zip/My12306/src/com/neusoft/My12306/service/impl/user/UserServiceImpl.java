package com.neusoft.My12306.service.impl.user;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IOrderDao;
import com.neusoft.My12306.dao.idao.ITicketDao;
import com.neusoft.My12306.dao.idao.IUserDao;
import com.neusoft.My12306.dao.idao.IUserLoginDao;
import com.neusoft.My12306.dao.impl.UserLoginDao;
import com.neusoft.My12306.dao.pojo.Order;
import com.neusoft.My12306.dao.pojo.Ticket;
import com.neusoft.My12306.dao.pojo.User;
import com.neusoft.My12306.dao.pojo.UserLogin;
import com.neusoft.My12306.service.iservice.user.IUserService;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * Created by xiangsong on 2016/9/14.
 */
public class UserServiceImpl implements IUserService {

	private static Logger logger = Logger.getLogger(UserServiceImpl.class);

	private IUserLoginDao iUserLoginDao;
	private IUserDao iUserDao;
	private ITicketDao iTicketDao;
	private IOrderDao iOrderDao;

	public UserServiceImpl() {
		super();
		iUserLoginDao = DaoFactory.getUserLoginDaoInstance();
		iUserDao = DaoFactory.getUserDaoInstance();
		iTicketDao = DaoFactory.getTicketDaoInstance();
		iOrderDao = DaoFactory.getOrderDaoInstance();
	}

	@Override
	public boolean registerUser(String email, String name, String sex, String phone, String idcard,String pwd) {
		boolean isSuccess = false;
		try {
            //state,少写了一个t
			User userTemp = iUserDao.findByEmail(email);
            int i = iUserDao.getNewId();
			User user = new User(i, email, name, sex, idcard, phone, "", "");
            UserLogin userLogin = new UserLogin(i,email,pwd);
			if (userTemp == null) {
				iUserDao.save(user);
                iUserLoginDao.save(new UserLogin(i,email,pwd));
				isSuccess = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isSuccess;
	}

	@Override
	public boolean validateLogin(String userName, String passWord) {
		boolean isSuccess = false;
		try {
			isSuccess = iUserLoginDao.validateLogin(userName, passWord);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isSuccess;
	}

	@Override
	public List queryTicket(String fromCity, String toCity, String date, boolean isOnlyQueryG, boolean isOnlyQueryZ) {
		List list = null;
		try {
			// 使用接口的好处好像是可以让别人看不到源代码。。。
			list = iUserDao.queryTicket(fromCity, toCity, date, isOnlyQueryG, isOnlyQueryZ);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	/*
	 * public boolean operateTicket(int operationCode) { return false; }
	 */

	@Override
	public boolean generateOrder(Ticket ticket, Order order) {
		boolean isSuccess = false;
		try {
			logger.info("正在保存订单信息: " + order);
			iOrderDao.save(order);
			logger.info("成功保存订单信息: " + order);
			logger.info("正在保存车票信息: " + ticket);
			iTicketDao.save(ticket);
			logger.info("成功保存车票信息: " + ticket);
			isSuccess = true;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("失败保存订单信息: " + order);
			logger.info("失败保存车票信息: " + ticket);
		}
		return isSuccess;
	}

	@Override
	public boolean operateOrder(String phoneId, int orderid, String operation) {
		boolean isSuccess = false;
		try {
			iTicketDao.updateTicketStatus(phoneId, operation);
			iOrderDao.updateOrderStatus(orderid, operation);
			isSuccess = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isSuccess;
	}

    @Override
    public boolean operateOrder(int orderid, String operation) {
        boolean isSuccess = false;
        try {
            iOrderDao.updateOrderStatus(orderid, operation);
            isSuccess = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isSuccess;
    }

    @Override
    public boolean deleteOrder(int orderid) {

        boolean isSuccess = false;
        Order order = new Order();
        order.setOrderid(orderid);
        Ticket ticket = new Ticket();
        ticket.setTicketid(orderid);
        try {
            iOrderDao.delete(order);
            iTicketDao.delete(ticket);
            isSuccess = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isSuccess;
    }

    @Override
	public boolean operateOrder(String phoneId, Ticket ticket) {
		boolean isSuccess = false;
		try {
			iTicketDao.update(ticket);
			isSuccess = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isSuccess;
	}

	/**
	 * 以list形式返回给用户，list包含list， 其中list.get(0)为order对象list
	 * list.get(1)为ticket对象list
	 * 
	 * @param userId
	 * @return
	 */
	@Override
	public List queryOrder(String phoneId, String userId) {
		List list = new ArrayList<>();
		try {
			list.add(iTicketDao.findByPhoneId(phoneId));
			list.add(iOrderDao.findByUserId(userId));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public User queryUser(int userId) {
		User user = null;
		try {
			user = iUserDao.findById(userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public User queryUserByEmail(String email) {
		User user = null;
		try {
			user = iUserDao.findByEmail(email);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public boolean editUser(User user) {
		boolean isSuccess = false;

		try {
			iUserDao.updateByEmail(user);
			isSuccess = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isSuccess;
	}
}
