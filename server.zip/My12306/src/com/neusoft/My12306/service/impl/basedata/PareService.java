package com.neusoft.My12306.service.impl.basedata;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IPareDao;
import com.neusoft.My12306.dao.pojo.Pare;
import com.neusoft.My12306.service.iservice.basedata.IPareService;
import com.neusoft.My12306.util.AdminPermission;

public class PareService implements IPareService {
	private static Logger logger = Logger.getLogger(PareService.class);

	private IPareDao pareDao;

	public PareService() {
		pareDao = DaoFactory.getPareDao();
	}

	@Override
	public String update(Pare pare, int permission) {
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在更新: " + pare);
				pareDao.update(pare);
				logger.info("成功更新: " + pare);
				return "success";
			} catch (Exception e) {
				logger.info("失败更新: " + pare);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public Pare findById(int id, int permission) {
		Pare pare = null;
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询票价率信息: id " + id);
				pare = pareDao.findById(id);
				logger.info("成功查询票价率信息: id " + id);
			} catch (Exception e) {
				logger.info("失败查询票价率信息: id " + id);
				logger.error(e);
				e.printStackTrace();
			}
		}
		return pare;
	}

	@Override
	public List<Pare> findAll(int permission) {
		List<Pare> pareList = new ArrayList<Pare>();
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询所有票价率信息");
				pareList.addAll(pareDao.findAll());
				logger.info("成功查询所有票价率信息");
			} catch (Exception e) {
				logger.info("失败查询所有票价率信息");
				logger.error(e);
				e.printStackTrace();
			}
		}
		return pareList;
	}

}
