package com.neusoft.My12306.service.iservice.user;

import com.neusoft.My12306.dao.pojo.Order;
import com.neusoft.My12306.dao.pojo.Ticket;
import com.neusoft.My12306.dao.pojo.User;

import java.util.List;

/**
 * Created by xiangsong on 2016/9/14.
 */
public interface IUserService {
    boolean registerUser(String email,String name,String sex,String phone,String idcard,String pwd);

    /**
     *
     * @param userName 用户邮箱
     * @param passWord
     * @return
     */
    boolean validateLogin(String userName,String passWord);

    /**
     * 查询余票信息
     * @param fromCity
     * @param toCity
     * @param date
     * @param isOnlyQueryG
     * @param isOnlyQueryZ
     * @return
     */
    List queryTicket(String fromCity,String toCity,String date,boolean isOnlyQueryG,boolean isOnlyQueryZ);


    /**
     * 生成订单，包括车票的信息和订单的基础信息
     * @param ticket
     * @param order
     * @return
     */
    boolean generateOrder(Ticket ticket, Order order);


    /**
     * 根据所传入的OrderID和operation进行订单的取消或者支付
     * @param orderid
     * @param operation 1取消 2支付 3车票已取 4退票
     * @return
     */
    boolean operateOrder(String phoneId,int orderid,String operation);


    boolean operateOrder(int orderid,String operation);

    boolean deleteOrder(int orderid);

    /**
     * 进行车票的改签,需要同时修改order和ticket两张表
     * @return
     */
    boolean operateOrder(String phoneId,Ticket ticket);

    /**
     * 查询用户的订单，只需传入用户ID即可
     * @param userId
     * @return
     */
    List queryOrder(String phoneId,String userId);

    /**
     * 查询用户个人信息
     */
    User queryUser(int userId);


    User queryUserByEmail(String email);

    /**
     * 修改用户个人信息
     * @param user
     * @return
     */
    boolean editUser(User user);

}
