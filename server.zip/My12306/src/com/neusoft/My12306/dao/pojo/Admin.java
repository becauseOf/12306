package com.neusoft.My12306.dao.pojo;

/**
 * 管理员信息
 * 
 * @author hezhujun
 *
 */
public class Admin {

	private int adminid;
	private String name;
	private String password;
	private int permission;

	public int getAdminid() {
		return adminid;
	}

	public void setAdminid(int adminid) {
		this.adminid = adminid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getPermission() {
		return permission;
	}

	public void setPermission(int permission) {
		this.permission = permission;
	}

	public Admin() {
		// TODO Auto-generated constructor stub
	}

	public Admin(int adminid, String name, String password, int permission) {
		super();
		this.adminid = adminid;
		this.name = name;
		this.password = password;
		this.permission = permission;
	}

	@Override
	public String toString() {
		return "Admin [adminid=" + adminid + ", name=" + name + ", password=" + password + ", permission=" + permission
				+ "]";
	}

}
