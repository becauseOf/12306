package com.neusoft.My12306.dao.impl;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IPareDao;
import com.neusoft.My12306.dao.pojo.Pare;

/**
 * @author wangzhihao
 *
 *         下午9:49:06 2016年9月13日
 */
public class PareDaoTest {

	private IPareDao pareDao;

	@Before
	public void setUp() {
		pareDao = DaoFactory.getPareDao();
	}

	@Test
	public void testGetNewId() throws SQLException {
		System.out.println(pareDao.getNewId());
	}

	@Test
	public void testSave() throws Exception {
		Pare pare = new Pare(pareDao.getNewId(), "软座", new BigDecimal(0.11722), 200);
		pareDao.save(pare);
	}

	@Test
	public void testFindAll() throws Exception {
		List<Pare> pareList = pareDao.findAll();
		for (Pare pare : pareList) {
			System.out.println(pare);
		}
	}

	@Test
	public void testFindById() throws Exception {
		Pare pare = pareDao.findById(1);
		assertEquals(1, pare.getPareid());
		assertEquals("硬座", pare.getTicketType());
		// BigDecimal构造函数参数为字符串时比较精确,double类型不精确
		assertEquals(new BigDecimal("0.05861"), pare.getPare());
		assertEquals(100, pare.getRatio());
	}

	@Test
	public void testUpdate() throws Exception {
		Pare pare = pareDao.findById(2);
		pare.setRatio(300);
		pareDao.update(pare);
	}

	@Test
	public void testDelete() throws Exception {
		Pare pare = pareDao.findById(2);
		pareDao.delete(pare);
	}

}
