package com.neusoft.My12306.service.iservice.admin;

import java.util.List;

import com.neusoft.My12306.dao.pojo.Admin;

public interface IAdminService {
	/**
	 * 增加一个管理员
	 * 
	 * @param Admin
	 *            管理员对象
	 * @param permission
	 *            超级管理员权限 
	 * @return 成功返回"success" 失败返回"error"
	 */
	String save(Admin admin,int permission);
	
	/**
	 * 删除一个管理员
	 * 
	 * @param Admin
	 *            管理员对象
	 * @param permission
	 *            超级管理员权限          
	 * @return 成功返回"success" 失败返回"error"
	 */
	String delete(Admin admin,int permission);
	
	/**
	 * 修改管理员信息
	 * 
	 * @param Admin
	 *            计划对象
	 * @param permission
	 *            超级管理员权限          
	 * @return 成功返回"success" 失败返回"error"
	 */
	String update(Admin admin,int permission);
	
	/**
	 * 通过id获取管理员信息
	 * 
	 * @param Admin
	 *            管理员对象
	 * @param permission
	 *            计划管理员权限          
	 * @return 成功返回"success" 失败返回"error"
	 */
	Admin findById(int id,int permission);
	
	/**
	 * 查看所有管理员信息
	 * 
	 * @param Admin
	 *            管理员对象
	 * @param permission
	 *            计划管理员权限          
	 * @return 成功返回"success" 失败返回"error"
	 */
	List<Admin> findAll(int permission);
}
