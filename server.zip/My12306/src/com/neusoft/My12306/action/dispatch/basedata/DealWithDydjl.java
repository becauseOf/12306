package com.neusoft.My12306.action.dispatch.basedata;

import javax.servlet.http.HttpServletRequest;

import com.neusoft.My12306.dao.pojo.Dydjl;
import com.neusoft.My12306.service.iservice.basedata.IDydjlService;
import com.neusoft.My12306.util.CreateBean;

public class DealWithDydjl {

	public static String updateDydjl(HttpServletRequest request, IDydjlService dydjlService, int permission) {
		Dydjl dydjl = CreateBean.getBean(Dydjl.class, request);
		String result = "error";
		if (dydjl != null) {
			result = dydjlService.update(dydjl, permission);
		}
		return result;
	}

}
