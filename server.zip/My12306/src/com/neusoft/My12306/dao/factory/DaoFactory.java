package com.neusoft.My12306.dao.factory;

import com.neusoft.My12306.dao.idao.IAdminDao;
import com.neusoft.My12306.dao.idao.IDydjlDao;
import com.neusoft.My12306.dao.idao.IOrderDao;
import com.neusoft.My12306.dao.idao.IOrganizeDao;
import com.neusoft.My12306.dao.idao.IPareDao;
import com.neusoft.My12306.dao.idao.IPlainDao;
import com.neusoft.My12306.dao.idao.IRouteDao;
import com.neusoft.My12306.dao.idao.ISeatDao;
import com.neusoft.My12306.dao.idao.IStationDao;
import com.neusoft.My12306.dao.idao.ITicketDao;
import com.neusoft.My12306.dao.idao.ITrainDao;
import com.neusoft.My12306.dao.idao.ITripsectionDao;
import com.neusoft.My12306.dao.idao.IUserDao;
import com.neusoft.My12306.dao.idao.IUserLoginDao;
import com.neusoft.My12306.dao.impl.AdminDao;
import com.neusoft.My12306.dao.impl.DydjlDao;
import com.neusoft.My12306.dao.impl.OrderDao;
import com.neusoft.My12306.dao.impl.OrganizeDao;
import com.neusoft.My12306.dao.impl.PareDao;
import com.neusoft.My12306.dao.impl.PlainDao;
import com.neusoft.My12306.dao.impl.RouteDao;
import com.neusoft.My12306.dao.impl.SeatDao;
import com.neusoft.My12306.dao.impl.StationDao;
import com.neusoft.My12306.dao.impl.TicketDao;
import com.neusoft.My12306.dao.impl.TrainDao;
import com.neusoft.My12306.dao.impl.TripsectionDao;
import com.neusoft.My12306.dao.impl.UserDao;
import com.neusoft.My12306.dao.impl.UserLoginDao;

public class DaoFactory {

	public static IStationDao getStationDao() {
		return new StationDao();
	}

	public static ITrainDao getTrainDao() {
		return new TrainDao();
	}

	public static IRouteDao getRouteDao() {
		return new RouteDao();
	}

	public static IOrganizeDao getOrganizeDao() {
		return new OrganizeDao();
	}

	public static IPareDao getPareDao() {
		return new PareDao();
	}

	public static ITripsectionDao getTripsectionDao() {
		return new TripsectionDao();
	}

	public static IDydjlDao getDydjlDao() {
		return new DydjlDao();
	}

	public static IUserDao getUserDaoInstance(){
		return new UserDao();
	}

	public static IUserLoginDao getUserLoginDaoInstance(){
		return new UserLoginDao();
	}

	public static ITicketDao getTicketDaoInstance(){
		return new TicketDao();
	}

	public static IOrderDao getOrderDaoInstance(){
		return new OrderDao();
	}
	
	public static IAdminDao getAdminDao(){
		return new AdminDao();
	}
	
	public static IPlainDao getPlainDao(){
		return new PlainDao();
	}
	
	public static ISeatDao getSeatDao(){
		return new SeatDao();
	}
}
