package com.neusoft.My12306.service.impl.basedata;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.pojo.Station;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.IStationService;

public class StationServiceTest {

	private IStationService stationService;

	@Before
	public void setUp() throws Exception {
		stationService = ServiceFactory.getStationService();
	}

	@Test
	public void testSave() throws Exception {
		Station station = new Station(0, "上海", "SH", "上海", "上海铁路", "特", "上海");
		assertEquals("success", stationService.save(station, 1));
	}

	@Test
	public void testFindAll() {
		List<Station> stationList = stationService.findAll(1);
		for (Station station : stationList) {
			System.out.println(station);
		}
	}

	@Test
	public void testFindById() {
		Station station = stationService.findById(5, 1);
		System.out.println(station);
	}

	@Test
	public void testFindByName() {
		List<Station> stationList = stationService.findByName("长", 1);
		for (Station station : stationList) {
			System.out.println(station);
		}
	}

	@Test
	public void testFindByPinyin() {
		List<Station> stationList = stationService.findByPinyin("S", 1);
		for (Station station : stationList) {
			System.out.println(station);
		}
	}

	@Test
	public void testUpdate() {
		Station station = stationService.findById(5, 1);
		station.setAddress("四川");
		station.setStationname("四川");
		station.setPingyin("SC");
		station.setAdministrativeArea("四川");
		station.setRailwayStation("四川");
		station.setStationLevel("二");
		stationService.update(station, 1);
	}

	@Test
	public void testDelete() {
		Station station = stationService.findById(5, 1);
		stationService.delete(station, 1);
	}

}
