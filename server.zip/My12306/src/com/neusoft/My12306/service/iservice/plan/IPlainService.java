package com.neusoft.My12306.service.iservice.plan;

import java.util.List;

import com.neusoft.My12306.dao.pojo.Plain;


/**
 * @author wangzhihao
 *
 * 上午9:35:48 2016年9月14日
 */
public interface IPlainService {
	/**
	 * 保存计划信息
	 * 
	 * @param Plain
	 *            计划对象
	 * @param Train          
	 *            车次对象
	 * @param permission
	 *            计划管理员权限          
	 * @return 成功返回"success" 失败返回"error"
	 */
	String save(Plain plain,int permission);

	/**
	 * 删除计划信息
	 * 
	 * @param Plain
	 *            计划对象
	 * @param permission
	 *            计划管理员权限          
	 * @return 成功返回"success" 失败返回"error"
	 */
	String delete(Plain plain,int permission);
	
	/**
	 * 更改计划信息
	 * 
	 * @param Plain
	 *            计划对象
	 * @param permission
	 *            计划管理员权限          
	 * @return 成功返回"success" 失败返回"error"
	 */
	String update(Plain plain,int permission);
	
	/**
	 * 通过车次id获取计划对象
	 * 
	 * @param Plain
	 *            计划对象
	 * @param trainid           
	 * 			  车次对象
	 * @param permission
	 *            计划管理员权限          
	 * @return 成功返回"success" 失败返回"error"
	 */
	List<Plain> findByTrain(String trainid,int permission);
	
	/**
	 * 通过id获取计划对象
	 * 
	 * @param Plain
	 *            计划对象
	 * @param permission
	 *            计划管理员权限          
	 * @return 成功返回"success" 失败返回"error"
	 */
	Plain findById(int id,int permission);
	
	/**
	 * 查询所有计划信息
	 * 
	 * @param Plain
	 *            计划对象
	 * @param permission
	 *            计划管理员权限          
	 * @return 成功返回"success" 失败返回"error"
	 */
	List<Plain> findAll(int permission);
	
	/**
	 * 执行计划，完成席位发布
	 * 
	 * @param Plain
	 *            计划对象
	 * @param permission
	 *            计划管理员权限          
	 * @return 成功返回"success" 失败返回"error"
	 */
	void doPlain(Plain plain,int permission);
}


