package com.neusoft.My12306.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hehujun.framework.dbhelper.util.IDealWithResultSet;
import com.hehujun.framework.dbhelper.util.ISetStatementParam;
import com.hehujun.framework.dbhelper.util.SQLUtil;
import com.neusoft.My12306.dao.idao.IStationDao;
import com.neusoft.My12306.dao.pojo.Station;

public class StationDao implements IStationDao {

	@Override
	public void delete(Station station) throws Exception {
		String sql = "delete from t_station where stationid=?";
		SQLUtil.delete(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, station.getStationid());
			}
		});
	}

	@Override
	public List<Station> findAll() throws Exception {
		String sql = "select stationid, stationname, pingyin, administrative_area,"
				+ " railway_station, station_level, address from t_station order by stationid asc";
		List<Object> oList = SQLUtil.find(sql, new IDealWithResultSet<Station>() {

			@Override
			public Station dealWithResultSet(ResultSet rs) throws SQLException {
				Station station = new Station();
				station.setStationid(rs.getInt(1));
				station.setStationname(rs.getString(2));
				station.setPingyin(rs.getString(3));
				station.setAdministrativeArea(rs.getString(4));
				station.setRailwayStation(rs.getString(5));
				station.setStationLevel(rs.getString(6));
				station.setAddress(rs.getString(7));
				return station;
			}

		});
		List<Station> stationList = new ArrayList<Station>();
		for (int i = 0; i < oList.size(); i++) {
			stationList.add((Station) oList.get(i));
		}
		return stationList;
	}

	@Override
	public Station findById(Integer arg0) throws Exception {
		String sql = "select stationid, stationname, pingyin, administrative_area,"
				+ " railway_station, station_level, address from t_station where stationid=?";
		List<Object> oList = SQLUtil.find(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, arg0);

			}
		}, new IDealWithResultSet<Station>() {

			@Override
			public Station dealWithResultSet(ResultSet rs) throws SQLException {
				Station station = new Station();
				station.setStationid(rs.getInt(1));
				station.setStationname(rs.getString(2));
				station.setPingyin(rs.getString(3));
				station.setAdministrativeArea(rs.getString(4));
				station.setRailwayStation(rs.getString(5));
				station.setStationLevel(rs.getString(6));
				station.setAddress(rs.getString(7));
				return station;
			}

		});
		Station station = null;
		if (!oList.isEmpty()) {
			station = (Station) oList.get(0);
		}
		return station;
	}

	@Override
	public void save(Station station) throws Exception {
		String sql = "insert into T_STATION(stationid,stationname,pingyin,"
				+ "administrative_area,railway_station,station_level,address)" + " values(?,?,?,?,?,?,?)";
		SQLUtil.save(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, station.getStationid());
				ps.setString(2, station.getStationname());
				ps.setString(3, station.getPingyin().toUpperCase());
				ps.setString(4, station.getAdministrativeArea());
				ps.setString(5, station.getRailwayStation());
				ps.setString(6, station.getStationLevel());
				ps.setString(7, station.getAddress());
			}
		});
	}

	@Override
	public void update(Station station) throws Exception {
		String sql = "update t_station set stationname=?,pingyin=?,administrative_area=?,"
				+ "railway_station=?,station_level=?,address=?" + "where stationid=?";
		SQLUtil.update(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, station.getStationname());
				ps.setString(2, station.getPingyin().toUpperCase());
				ps.setString(3, station.getAdministrativeArea());
				ps.setString(4, station.getRailwayStation());
				ps.setString(5, station.getStationLevel());
				ps.setString(6, station.getAddress());
				ps.setInt(7, station.getStationid());
			}
		});
	}

	@Override
	public int getNewId() throws SQLException {
		String sql = "select max(stationid) from t_station";
		List<Object> i = SQLUtil.executeAndGetResult(sql, new IDealWithResultSet<Integer>() {

			@Override
			public Integer dealWithResultSet(ResultSet rs) throws SQLException {
				Integer i = new Integer(rs.getInt(1) + 1);
				return i;
			}
		});
		return (i.size() == 0 ? 0 : (int) i.get(0));
	}

	@Override
	public List<Station> findByName(String name) throws SQLException {
		String sql = "select stationid, stationname, pingyin, administrative_area,"
				+ " railway_station, station_level, address from t_station"
				+ " where stationname like ? order by stationid asc";
		List<Object> oList = SQLUtil.find(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, "%" + name + "%");

			}
		}, new IDealWithResultSet<Station>() {

			@Override
			public Station dealWithResultSet(ResultSet rs) throws SQLException {
				Station station = new Station();
				station.setStationid(rs.getInt(1));
				station.setStationname(rs.getString(2));
				station.setPingyin(rs.getString(3));
				station.setAdministrativeArea(rs.getString(4));
				station.setRailwayStation(rs.getString(5));
				station.setStationLevel(rs.getString(6));
				station.setAddress(rs.getString(7));
				return station;
			}

		});
		List<Station> stationList = new ArrayList<Station>();
		for (int i = 0; i < oList.size(); i++) {
			stationList.add((Station) oList.get(i));
		}
		return stationList;
	}

	@Override
	public List<Station> findByPinyin(String name) throws SQLException {
		String sql = "select stationid, stationname, pingyin, administrative_area,"
				+ " railway_station, station_level, address from t_station where pingyin like ? order by stationid asc";
		List<Object> oList = SQLUtil.find(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, "%" + name + "%");

			}
		}, new IDealWithResultSet<Station>() {

			@Override
			public Station dealWithResultSet(ResultSet rs) throws SQLException {
				Station station = new Station();
				station.setStationid(rs.getInt(1));
				station.setStationname(rs.getString(2));
				station.setPingyin(rs.getString(3));
				station.setAdministrativeArea(rs.getString(4));
				station.setRailwayStation(rs.getString(5));
				station.setStationLevel(rs.getString(6));
				station.setAddress(rs.getString(7));
				return station;
			}

		});
		List<Station> stationList = new ArrayList<Station>();
		for (int i = 0; i < oList.size(); i++) {
			stationList.add((Station) oList.get(i));
		}
		return stationList;
	}

}
