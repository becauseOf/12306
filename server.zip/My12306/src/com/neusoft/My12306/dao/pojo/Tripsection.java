package com.neusoft.My12306.dao.pojo;

/**
 * 旅程区段信息
 * 
 * @author hezhujun
 *
 */
public class Tripsection {
	private int tripsectionid;
	private String mileageSectionFrom;
	private String mileageSectionTo;
	private long length;
	private int count;

	public int getTripsectionid() {
		return tripsectionid;
	}

	public void setTripsectionid(int tripsectionid) {
		this.tripsectionid = tripsectionid;
	}

	public String getMileageSectionFrom() {
		return mileageSectionFrom;
	}

	public void setMileageSectionFrom(String mileageSectionFrom) {
		this.mileageSectionFrom = mileageSectionFrom;
	}

	public String getMileageSectionTo() {
		return mileageSectionTo;
	}

	public void setMileageSectionTo(String mileageSectonTo) {
		this.mileageSectionTo = mileageSectonTo;
	}

	public long getLength() {
		return length;
	}

	public void setLength(long length) {
		this.length = length;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public Tripsection() {
		// TODO Auto-generated constructor stub
	}

	public Tripsection(int tripsectionid, String mileageSectionFrom, String mileageSectonTo, long length, int count) {
		super();
		this.tripsectionid = tripsectionid;
		this.mileageSectionFrom = mileageSectionFrom;
		this.mileageSectionTo = mileageSectonTo;
		this.length = length;
		this.count = count;
	}

	@Override
	public String toString() {
		return "Tripsection [tripsectionid=" + tripsectionid + ", mileageSectionFrom=" + mileageSectionFrom
				+ ", mileageSectonTo=" + mileageSectionTo + ", length=" + length + ", count=" + count + "]";
	}

}
