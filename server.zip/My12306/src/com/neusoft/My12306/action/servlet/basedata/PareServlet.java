package com.neusoft.My12306.action.servlet.basedata;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.My12306.action.dispatch.basedata.DealWithPare;
import com.neusoft.My12306.dao.pojo.Pare;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.IPareService;

@WebServlet("/PareServlet")
public class PareServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private IPareService pareService;

	public PareServlet() {
		super();
		pareService = ServiceFactory.getPareService();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String operation = request.getParameter("operation");
		// 获取当前管理员的权限
		int permission = 1;
		// 返回票价率管理主页
		if (operation == null) {
			List<Pare> pareList = pareService.findAll(permission);
			request.setAttribute("pareList", pareList);
			request.getRequestDispatcher("WEB-INF/view/basedata/priceManager.jsp").forward(request, response);
			// 处理票价率信息更新
		} else if ("update".equalsIgnoreCase(operation)) {
			if (request.getParameter("submit") != null) {
				String result = DealWithPare.updatePare(request, pareService, permission);
				if ("success".equals(result)) {
					response.sendRedirect("PareServlet");
				} else {
					request.setAttribute("message", result);
					request.getRequestDispatcher("WEB-INF/view/basedata/revisePrice.jsp").forward(request, response);
				}
			} else {
				int id = Integer.parseInt(request.getParameter("pareid"));
				Pare pare = pareService.findById(id, permission);
				request.setAttribute("pare", pare);
				request.getRequestDispatcher("WEB-INF/view/basedata/revisePrice.jsp").forward(request, response);
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
