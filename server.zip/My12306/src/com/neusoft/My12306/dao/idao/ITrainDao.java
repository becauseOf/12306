package com.neusoft.My12306.dao.idao;

import com.hehujun.framework.dbhelper.idao.IBaseDao;
import com.neusoft.My12306.dao.pojo.Train;

public interface ITrainDao extends IBaseDao<Train, String> {

}
