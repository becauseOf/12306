package com.neusoft.My12306.action.dispatch.plan;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.My12306.dao.pojo.Plain;
import com.neusoft.My12306.dao.pojo.Station;
import com.neusoft.My12306.service.iservice.plan.IPlainService;
import com.neusoft.My12306.util.CreateBean;

/**
 * 处理关于计划信息的请求
 * 
 * @author wangzhihao
 *
 * 下午10:13:42 2016年9月18日
 */
public class DealWithPlain {
	/**
	 * 保存plain数据
	 * 
	 * @param request
	 * @param plainService
	 * @param permission
	 * @return
	 */
	public static String createPlain(HttpServletRequest request,IPlainService plainService,int permission){
		Plain plain = CreateBean.getBean(Plain.class, request);
		String result = "error";
		if(plain != null){
			result = plainService.save(plain, permission);
		}
		return result;
	}
	
	public static String updatePlain(HttpServletRequest request,IPlainService plainService,int permission){
		Plain plain = CreateBean.getBean(Plain.class, request);
		String result = "error";
		if (plain != null) {
			result = plainService.update(plain, permission);
		}
		return result;
	}
	
	public static String deletePlain(HttpServletRequest request,IPlainService plainService,int permission){
		String result = "error";
		int id = 0;
		try{
			id = Integer.parseInt(request.getParameter("plainid"));
		}catch(NumberFormatException e){
			result = "计划id为整型";
		}
		if(id != 0){
			Plain plain = new Plain();
			plain.setPlainid(id);
			result = plainService.delete(plain, permission);
		}
		return result;
	}
	
}
