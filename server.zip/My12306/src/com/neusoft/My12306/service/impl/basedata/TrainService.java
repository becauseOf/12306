package com.neusoft.My12306.service.impl.basedata;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.ITrainDao;
import com.neusoft.My12306.dao.pojo.Train;
import com.neusoft.My12306.service.iservice.basedata.ITrainService;
import com.neusoft.My12306.util.AdminPermission;

public class TrainService implements ITrainService {
	private static Logger logger = Logger.getLogger(TrainService.class);

	private ITrainDao trainDao;

	public TrainService() {
		trainDao = DaoFactory.getTrainDao();
	}

	@Override
	public String save(Train train, int permission) {
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在保存: " + train);
				trainDao.save(train);
				logger.info("成功保存: " + train);
				return "success";
			} catch (Exception e) {
				logger.info("失败保存: " + train);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public String delete(Train train, int permission) {
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在删除: " + train);
				trainDao.delete(train);
				logger.info("成功删除: " + train);
				return "success";
			} catch (Exception e) {
				logger.info("失败删除: " + train);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public String update(Train train, int permission) {
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在更新: " + train);
				trainDao.update(train);
				logger.info("成功更新: " + train);
				return "success";
			} catch (Exception e) {
				logger.info("失败更新: " + train);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public Train findById(String id, int permission) {
		Train train = null;
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询车次信息: id " + id);
				train = trainDao.findById(id);
				logger.info("成功查询车次信息: id " + id);
			} catch (Exception e) {
				logger.info("失败查询车次信息: id " + id);
				logger.error(e);
				e.printStackTrace();
			}
		}
		return train;
	}

	@Override
	public List<Train> findAll(int permission) {
		List<Train> trainList = new ArrayList<Train>();
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询所有车次信息");
				trainList.addAll(trainDao.findAll());
				logger.info("成功查询所有车次信息");
			} catch (Exception e) {
				logger.info("失败查询所有车次信息");
				logger.error(e);
				e.printStackTrace();
			}
		}
		return trainList;
	}

}
