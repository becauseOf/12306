package com.neusoft.My12306.dao.idao;

import java.sql.SQLException;
import java.util.List;

import com.hehujun.framework.dbhelper.idao.IBaseDao;
import com.neusoft.My12306.bean.TicketBean;
import com.neusoft.My12306.dao.pojo.Seat;

public interface ISeatDao extends IBaseDao<Seat, Integer> {
	/**
	 * 获得新id
	 * 
	 * @return id
	 * @throws SQLException
	 */
	int getNewId() throws SQLException;

	/**
	 * 获取余票信息
	 * 
	 * @param from
	 *            起始站
	 * @param to
	 *            终点站
	 * @return TicketBean列表
	 * @throws Exception
	 */
	List<TicketBean> getTicketInfo(String from, String to) throws Exception;

	/**
	 * 获取乘车区间对应的票种的个数
	 * 
	 * @param ticketBean
	 *            ticketBean
	 * @param seatClass
	 *            车票类型
	 * @return
	 * @throws Exception
	 */
	int getTicketCount(TicketBean ticketBean, String seatClass) throws Exception;

	/**
	 * 选择一张余票，同时锁定相应的席位
	 * 
	 * @param from
	 *            起始站
	 * @param to
	 *            终点站
	 * @param trainid
	 *            车次
	 * @param seatClass
	 *            席位类型
	 * @param day
	 *            日期
	 * @return 席位信息
	 * @throws Exception
	 */
	Seat selectSeat(String from, String to, String trainid, String seatClass, String day) throws Exception;

	/**
	 * 买票，修改席位信息为已售
	 * 
	 * @param id
	 * @throws Exception
	 */
	void selectedSeat(int id) throws Exception;

	/**
	 * 退票或取消操作，修改席位信息，同时解开相应席位的锁
	 * 
	 * @param id
	 * @throws Exception
	 */
	void cancelSeat(int id) throws Exception;

	/**
	 * 锁定或解锁相应的席位
	 * 
	 * @param id
	 * @param state
	 *            状态
	 * @throws Exception
	 */
	void lockToggle(int id, String state) throws Exception;

	/**
	 * 获取席位信息
	 * 
	 * @param from
	 *            起始站
	 * @param to
	 *            终点站
	 * @param trainid
	 *            车次
	 * @param num
	 *            车厢
	 * @param seatNumber
	 *            座位号
	 * @param day
	 *            日期
	 * @return
	 * @throws SQLException
	 */
	Seat getSeat(String from, String to, String trainid, int num, String seatNumber, String day) throws SQLException;
}
