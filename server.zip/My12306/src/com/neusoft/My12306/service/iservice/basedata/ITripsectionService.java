package com.neusoft.My12306.service.iservice.basedata;

import java.util.List;

import com.neusoft.My12306.dao.pojo.Tripsection;

/**
 * 旅程区段信息管理
 * 
 * @author hezhujun
 *
 */
public interface ITripsectionService {
	/**
	 * 更新旅程区段信息
	 * 
	 * @param tripsection
	 *            旅程区段对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回"error"
	 */
	String update(Tripsection tripsection, int permission);

	/**
	 * 通过id查询旅程区段信息
	 * 
	 * @param id
	 *            id
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Tripsection对象 失败返回 null
	 */
	Tripsection findById(int id, int permission);

	/**
	 * 查询所有信息
	 * 
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Tripsection列表 失败返回 空列表
	 */
	List<Tripsection> findAll(int permission);
}
