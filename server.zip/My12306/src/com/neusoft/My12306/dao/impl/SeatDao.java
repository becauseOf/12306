package com.neusoft.My12306.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hehujun.framework.dbhelper.util.IDealWithResultSet;
import com.hehujun.framework.dbhelper.util.ISetStatementParam;
import com.hehujun.framework.dbhelper.util.SQLUtil;
import com.neusoft.My12306.bean.TicketBean;
import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IRouteDao;
import com.neusoft.My12306.dao.idao.ISeatDao;
import com.neusoft.My12306.dao.idao.ITrainDao;
import com.neusoft.My12306.dao.pojo.Seat;
import com.neusoft.My12306.dao.pojo.Train;

public class SeatDao implements ISeatDao {

	private IRouteDao routeDao;
	private ITrainDao trainDao;

	public SeatDao() {
		routeDao = DaoFactory.getRouteDao();
		trainDao = DaoFactory.getTrainDao();
	}

	@Override
	public void delete(Seat seat) throws Exception {
		String sql = "delete from t_seat where seatid=?";
		SQLUtil.delete(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, seat.getSeatid());

			}
		});

	}

	@Override
	public List<Seat> findAll() throws Exception {
		String sql = "select seatid,trainid,num,seat_number,"
				+ "station_start,station_end,to_char(time, 'yyyy-mm-dd'),state from t_seat order by seatid asc";
		List<Object> oList = SQLUtil.find(sql, new IDealWithResultSet<Seat>() {

			@Override
			public Seat dealWithResultSet(ResultSet rs) throws SQLException {
				Seat seat = new Seat();
				seat.setSeatid(rs.getInt(1));
				seat.setTrainid(rs.getString(2));
				seat.setNum(rs.getInt(3));
				seat.setSeatNubmer(rs.getString(4));
				seat.setStationStart(rs.getString(5));
				seat.setStationEnd(rs.getString(6));
				seat.setTime(rs.getString(7));
				seat.setState(rs.getString(8));
				return seat;
			}
		});
		List<Seat> seatList = new ArrayList<Seat>();
		for (int i = 0; i < oList.size(); i++) {
			seatList.add((Seat) oList.get(i));
		}
		return seatList;
	}

	@Override
	public Seat findById(Integer id) throws Exception {
		String sql = "select seatid,trainid,num,seat_number,"
				+ "station_start,station_end,to_char(time, 'yyyy-mm-dd'),state from t_seat where seatid=?";
		List<Object> oList = SQLUtil.find(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, id);

			}
		}, new IDealWithResultSet<Seat>() {

			@Override
			public Seat dealWithResultSet(ResultSet rs) throws SQLException {
				Seat seat = new Seat();
				seat.setSeatid(rs.getInt(1));
				seat.setTrainid(rs.getString(2));
				seat.setNum(rs.getInt(3));
				seat.setSeatNubmer(rs.getString(4));
				seat.setStationStart(rs.getString(5));
				seat.setStationEnd(rs.getString(6));
				seat.setTime(rs.getString(7));
				seat.setState(rs.getString(8));
				return seat;
			}
		});
		Seat seat = null;
		if (!oList.isEmpty()) {
			seat = (Seat) oList.get(0);
		}
		return seat;
	}

	@Override
	public void save(Seat seat) throws Exception {
		String sql = "insert into t_seat(seatid,trainid,num,seat_number,"
				+ "station_start,station_end,time,state) values(?,?,?,?,?,?,to_date(?,'yyyy-mm-dd'),?)";
		SQLUtil.save(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, seat.getSeatid());
				ps.setString(2, seat.getTrainid());
				ps.setInt(3, seat.getNum());
				ps.setString(4, seat.getSeatNubmer());
				ps.setString(5, seat.getStationStart());
				ps.setString(6, seat.getStationEnd());
				ps.setString(7, seat.getTime());
				ps.setString(8, seat.getState());

			}
		});

	}

	@Override
	public void update(Seat seat) throws Exception {
		String sql = "update t_seat set trainid=?,num=?,seat_number=?,"
				+ "station_start=?,station_end=?,time=to_date(?,'yyyy-mm-dd'),state=? where seatid=?";
		SQLUtil.update(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, seat.getTrainid());
				ps.setInt(2, seat.getNum());
				ps.setString(3, seat.getSeatNubmer());
				ps.setString(4, seat.getStationStart());
				ps.setString(5, seat.getStationEnd());
				ps.setString(6, seat.getTime());
				ps.setString(7, seat.getState());
				ps.setInt(8, seat.getSeatid());
			}
		});

	}

	@Override
	public int getNewId() throws SQLException {
		String sql = "select max(seatid) from t_seat";
		List<Object> i = SQLUtil.executeAndGetResult(sql, new IDealWithResultSet<Integer>() {

			@Override
			public Integer dealWithResultSet(ResultSet rs) throws SQLException {
				Integer i = new Integer(rs.getInt(1) + 1);
				return i;
			}
		});
		return (i.size() == 0 ? 0 : (int) i.get(0));
	}

	@Override
	public List<TicketBean> getTicketInfo(String from, String to) throws Exception {
		String sql = "SELECT JAVA.T_ROUTE.TRAINID, JAVA.T_STATION.STATIONNAME,"
				+ " JAVA.T_ROUTE.STATIONNAME, to_char(JAVA.T_ROUTE.START_TIME, 'hh24:mi:ss'),"
				+ " to_char(JAVA.T_ROUTE.END_TIME, 'hh24:mi:ss'), to_char(JAVA.T_ROUTE.TIME, 'hh24:mi:ss') "
				+ "FROM JAVA.T_ROUTE INNER JOIN JAVA.T_STATION ON "
				+ "JAVA.T_ROUTE.STATIONID = JAVA.T_STATION.STATIONID"
				+ " WHERE JAVA.T_STATION.STATIONNAME=? AND JAVA.T_ROUTE.STATIONNAME=?";
		List<Object> oList = SQLUtil.executeAndGetResult(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, from);
				ps.setString(2, to);
			}
		}, new IDealWithResultSet<TicketBean>() {

			@Override
			public TicketBean dealWithResultSet(ResultSet rs) throws SQLException {
				TicketBean ticketBean = new TicketBean();
				ticketBean.setTrainid(rs.getString(1));
				ticketBean.setStartStation(rs.getString(2));
				ticketBean.setEndStation(rs.getString(3));
				ticketBean.setStartTime(rs.getString(4));
				ticketBean.setEndTime(rs.getString(5));
				ticketBean.setTime(rs.getString(6));
				return ticketBean;
			}
		});
		List<TicketBean> ticketBeanList = new ArrayList<TicketBean>();
		for (Object o : oList) {
			ticketBeanList.add((TicketBean) o);
		}
		return ticketBeanList;
	}

	@Override
	public int getTicketCount(TicketBean ticketBean, String seatClass) throws Exception {
		String sql = "SELECT COUNT (JAVA .T_SEAT.SEATID) FROM JAVA .T_SEAT, "
				+ "JAVA .T_PLAIN WHERE JAVA .T_SEAT.TRAINID = ? " + "AND JAVA .T_SEAT.TRAINID = JAVA .T_PLAIN.TRAINID "
				+ "AND JAVA .T_SEAT.NUM = JAVA .T_PLAIN.NUM " + "AND JAVA .T_SEAT.STATION_START = ? "
				+ "AND JAVA .T_SEAT.STATION_END = ? " + "AND JAVA .T_SEAT.STATE = '未售' "
				+ "AND to_char(JAVA .T_SEAT.Time, 'yyyy-mm-dd') = ? "
				+ "AND JAVA .T_SEAT.NUM IN ( SELECT num FROM JAVA .T_ORGANIZE " + "WHERE JAVA .T_ORGANIZE.TRAINID = ? "
				+ "AND JAVA .T_ORGANIZE.SEAT_CLASS = ? )";

		List<Object> i = SQLUtil.executeAndGetResult(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, ticketBean.getTrainid());
				ps.setString(2, ticketBean.getStartStation());
				ps.setString(3, ticketBean.getEndStation());
				ps.setString(4, ticketBean.getDate());
				ps.setString(5, ticketBean.getTrainid());
				ps.setString(6, seatClass);
			}
		}, new IDealWithResultSet<Integer>() {

			@Override
			public Integer dealWithResultSet(ResultSet rs) throws SQLException {
				return rs.getInt(1);
			}
		});

		return (i.size() == 0 ? 0 : (int) i.get(0));
	}

	@Override
	public Seat selectSeat(String from, String to, String trainid, String seatClass, String day) throws Exception {
		// 先获取未售席位
		String sql = "SELECT JAVA .T_SEAT.SEATID, JAVA .T_SEAT.TRAINID, "
				+ "JAVA .T_SEAT.NUM, JAVA .T_SEAT.SEAT_NUMBER, "
				+ "JAVA .T_SEAT.STATION_START, JAVA .T_SEAT.STATION_END, "
				+ "TO_CHAR ( JAVA .T_SEAT. TIME, 'yyyy-mm-dd' ), JAVA .T_SEAT.STATE "
				+ "FROM JAVA .T_SEAT, JAVA .T_PLAIN WHERE JAVA .T_SEAT.TRAINID = ? "
				+ "AND JAVA .T_SEAT.TRAINID = JAVA .T_PLAIN.TRAINID AND JAVA .T_SEAT.NUM = JAVA .T_PLAIN.NUM "
				+ "AND JAVA .T_SEAT.STATION_START = ? AND JAVA .T_SEAT.STATION_END = ? "
				+ "AND JAVA .T_SEAT.STATE = '未售' AND TO_CHAR ( JAVA .T_SEAT. TIME, 'yyyy-mm-dd' ) = ? "
				+ "AND JAVA .T_SEAT.NUM IN ( SELECT num FROM JAVA .T_ORGANIZE WHERE JAVA .T_ORGANIZE.TRAINID = ? "
				+ "AND JAVA .T_ORGANIZE.SEAT_CLASS = ? ) AND ROWNUM <= 1";
		List<Object> oList = SQLUtil.executeAndGetResult(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, trainid);
				ps.setString(2, from);
				ps.setString(3, to);
				ps.setString(4, day);
				ps.setString(5, trainid);
				ps.setString(6, seatClass);
			}
		}, new IDealWithResultSet<Seat>() {

			@Override
			public Seat dealWithResultSet(ResultSet rs) throws SQLException {
				Seat seat = new Seat();
				seat.setSeatid(rs.getInt(1));
				seat.setTrainid(rs.getString(2));
				seat.setNum(rs.getInt(3));
				seat.setSeatNubmer(rs.getString(4));
				seat.setStationStart(rs.getString(5));
				seat.setStationEnd(rs.getString(6));
				seat.setTime(rs.getString(7));
				seat.setState(rs.getString(8));
				return seat;
			}
		});
		Seat seat = null;
		if (!oList.isEmpty()) {
			seat = (Seat) oList.get(0);
			// 锁定相应的席位
			lockToggle(seat, "锁定");
		}
		return seat;
	}

	// 相应席位信息解锁或加锁
	private void lockToggle(Seat seat, String state) {
		try {
			// 已经按照顺序读取
			// 获取线路上的所有车站
			List<String> stationNameList = routeDao.getStationNameList(seat.getStationStart(), seat.getStationEnd(),
					seat.getTrainid());
			// 获取车次的所有经过的车站
			Train train = trainDao.findById(seat.getTrainid());
			List<String> allStationNameList = routeDao.getStationNameList(train.getStartStation(),
					train.getEndStation(), train.getTrainid());
			/*
			 * 列车的线路 S S0： S --------------------------------------------------------- S0
			 * 席位对应的站 A B：             ...  A1     A                      B B1 ...
			 * 中间站 C D：                                                                                        C ... D
			 */
			// 分成5段车站
			// 起始站
			String a = stationNameList.remove(0);
			// 终点站
			String b = stationNameList.remove(stationNameList.size() - 1);
			// sa1
			List<String> sa1 = new ArrayList<String>();
			int index = 0;
			String stationTemp = null;
			for (index = 0; index < allStationNameList.size(); index++) {
				stationTemp = allStationNameList.get(index);
				if (stationTemp.equals(a)) {
					break;
				}
				sa1.add(stationTemp);
			}
			// cd
			List<String> cd = stationNameList;
			// b1s0
			List<String> b1s0 = new ArrayList<String>();
			for (; index < allStationNameList.size(); index++) {
				if (allStationNameList.get(index).equals(b)) {
					break;
				}
			}
			index++;
			for(; index < allStationNameList.size(); index++){
				b1s0.add(allStationNameList.get(index));
			}
			// 开始锁定
			Seat temp = null;
			// A -> S0 锁定，这里只需操作A -> B1S0
			for (int i=0; i < b1s0.size(); i++){
				temp = getSeat(a, b1s0.get(i), seat.getTrainid(),
						seat.getNum(), seat.getSeatNubmer(), seat.getTime());
				temp.setState(state);
				update(temp);
			}
			// S -> B 锁定, 这里只需操作 SA1 -> B
			for(int i = 0; i < sa1.size(); i++){
				temp =getSeat(sa1.get(i), b, seat.getTrainid(),
						seat.getNum(), seat.getSeatNubmer(), seat.getTime());
				temp.setState(state);
				update(temp);
			}
			// C -> D 有关的席位都锁定
			String cdTemp = null;
			for (int i = 0; i < cd.size(); i++){
				cdTemp = cd.get(i);
				index = allStationNameList.indexOf(cdTemp);
				// 以cdTemp为到达站
				for (int j = 0; j < index; j++){
					temp =getSeat(allStationNameList.get(j), cdTemp, seat.getTrainid(),
							seat.getNum(), seat.getSeatNubmer(), seat.getTime());
					temp.setState(state);
					update(temp);
				}
				// 以cdTemp为起始站
				for(int j = index + 1; j < allStationNameList.size(); j++){
					temp =getSeat(cdTemp, allStationNameList.get(j), seat.getTrainid(),
							seat.getNum(), seat.getSeatNubmer(), seat.getTime());
					temp.setState(state);
					update(temp);
				}
			}
			// SA1 -> B1S0 锁定
			String sa1Temp = null;
			String b1s0Temp = null;
			for(int i = 0; i < sa1.size(); i++){
				sa1Temp = sa1.get(i);
				for (int j = 0; j < b1s0.size(); j++){
					b1s0Temp = b1s0.get(j);
					temp =getSeat(sa1Temp, b1s0Temp, seat.getTrainid(),
							seat.getNum(), seat.getSeatNubmer(), seat.getTime());
					temp.setState(state);
					update(temp);
				}
			}
			// 锁定 AB
			temp =getSeat(a, b, seat.getTrainid(),
					seat.getNum(), seat.getSeatNubmer(), seat.getTime());
			temp.setState(state);
			update(temp);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void selectedSeat(int id) throws Exception {
		Seat seat = findById(id);
		if (seat != null && !"已售".equals(seat.getState())) {
			seat.setState("已售");
			update(seat);
		} else {
			throw new SQLException("车票已售");
		}
	}

	@Override
	public void cancelSeat(int id) throws Exception {
		Seat seat = findById(id);
		lockToggle(seat, "未售");
	}

	@Override
	public Seat getSeat(String from, String to, String trainid, int num, String seatNumber, String day)
			throws SQLException {
		String sql = "SELECT JAVA .T_SEAT.SEATID, JAVA .T_SEAT.TRAINID, JAVA .T_SEAT.NUM, "
				+ "JAVA .T_SEAT.SEAT_NUMBER, JAVA .T_SEAT.STATION_START, "
				+ "JAVA .T_SEAT.STATION_END, to_char(JAVA .T_SEAT. TIME, 'yyyy-mm-dd'), JAVA .T_SEAT.STATE "
				+ "FROM JAVA .T_SEAT WHERE JAVA .T_SEAT.TRAINID = ? AND JAVA .T_SEAT.NUM = ? AND "
				+ "JAVA .T_SEAT.SEAT_NUMBER = ?AND JAVA .T_SEAT.STATION_START = ? AND "
				+ "JAVA .T_SEAT.STATION_END = ?AND TO_CHAR ( JAVA .T_SEAT. TIME, 'yyyy-mm-dd' ) = ?";
		List<Object> oList = SQLUtil.executeAndGetResult(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, trainid);
				ps.setInt(2, num);
				ps.setString(3, seatNumber);
				ps.setString(4, from);
				ps.setString(5, to);
				ps.setString(6, day);
			}
		}, new IDealWithResultSet<Seat>() {

			@Override
			public Seat dealWithResultSet(ResultSet rs) throws SQLException {
				Seat seat = new Seat();
				seat.setSeatid(rs.getInt(1));
				seat.setTrainid(rs.getString(2));
				seat.setNum(rs.getInt(3));
				seat.setSeatNubmer(rs.getString(4));
				seat.setStationStart(rs.getString(5));
				seat.setStationEnd(rs.getString(6));
				seat.setTime(rs.getString(7));
				seat.setState(rs.getString(8));
				return seat;
			}
		});
		Seat seat = null;
		if (!oList.isEmpty()) {
			seat = (Seat) oList.get(0);
		}
		return seat;
	}

	@Override
	public void lockToggle(int id, String state) throws Exception {
		Seat seat = findById(id);
		lockToggle(seat, state);
	}

}
