package com.neusoft.My12306.action.userservlet;

import com.google.gson.JsonObject;
import com.neusoft.My12306.dao.pojo.QueryTicketItem;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.user.IUserService;
import com.neusoft.My12306.util.GsonUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 查询订单
 * Created by xiangsong on 2016/9/17.
 */
@WebServlet("/QueryOrder")
public class QueryOrder extends HttpServlet{

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idcard = request.getParameter("idcard");
        String userid = request.getParameter("userid");

        IUserService userService = ServiceFactory.getUserServiceInstance();

        JsonObject result = new JsonObject();

        List resultData = userService.queryOrder(idcard,userid);

        result.addProperty("order",GsonUtil.toJson(resultData.get(1),List.class));
        result.addProperty("ticket",GsonUtil.toJson(resultData.get(0),List.class));

        response.getWriter().println(result.toString());
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        doPost(request, response);
    }

}
