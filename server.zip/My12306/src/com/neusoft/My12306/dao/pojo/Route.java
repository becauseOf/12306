package com.neusoft.My12306.dao.pojo;

/**
 * 线路基本信息
 * 
 * @author hezhujun
 *
 */
public class Route {
	private int routeid;
	private String trainid;
	private String stationName;
	private String startTime;
	private String endTime;
	private long length;
	private String waitTime;
	private String time;
	private int stationid;

	public int getRouteid() {
		return routeid;
	}

	public void setRouteid(int routeid) {
		this.routeid = routeid;
	}

	public String getTrainid() {
		return trainid;
	}

	public void setTrainid(String trainid) {
		this.trainid = trainid;
	}

	public String getStationName() {
		return stationName;
	}

	public void setStationName(String stationName) {
		this.stationName = stationName;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public long getLength() {
		return length;
	}

	public void setLength(long length) {
		this.length = length;
	}

	public String getWaitTime() {
		return waitTime;
	}

	public void setWaitTime(String waitTime) {
		this.waitTime = waitTime;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public int getStationid() {
		return stationid;
	}

	public void setStationid(int stationid) {
		this.stationid = stationid;
	}

	public Route() {
		// TODO Auto-generated constructor stub
	}

	public Route(int routeid, String trainid, String stationName, String startTime, String endTime, long length,
			String waitTime, String time, int stationid) {
		super();
		this.routeid = routeid;
		this.trainid = trainid;
		this.stationName = stationName;
		this.startTime = startTime;
		this.endTime = endTime;
		this.length = length;
		this.waitTime = waitTime;
		this.time = time;
		this.stationid = stationid;
	}

	@Override
	public String toString() {
		return "Route [routeid=" + routeid + ", trainid=" + trainid + ", stationName=" + stationName + ", startTime="
				+ startTime + ", endTime=" + endTime + ", length=" + length + ", waitTime=" + waitTime + ", time="
				+ time + ", stationid=" + stationid + "]";
	}

}
