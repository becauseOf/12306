package com.neusoft.My12306.service.iservice.bill;

import java.util.List;

import com.neusoft.My12306.dao.pojo.Ticket;

/**
 * 票务管理
 * 
 * @author hezhujun
 *
 */
public interface IBillService {

	/**
	 * 查询余票
	 * 
	 * @param from
	 *            出发地
	 * @param to
	 *            目的地
	 * @return Ticket的列表
	 */
	List<Ticket> findTicket(String from, String to);

	/**
	 * 查询已购车票
	 * 
	 * @param idcard
	 *            身份证号码
	 * @param permission
	 *            权限
	 * @return 车票对象
	 */
	Ticket findById(String idcard, int permission);

	/**
	 * 取票
	 * 
	 * @param id
	 *            车票id
	 * @return 成功返回"success" 失败返回"error"
	 */
	String getTicket(int id, int permission);

	/**
	 * 退票
	 * 
	 * @param id
	 *            车票id
	 * @return 成功返回"success" 失败返回"error"
	 */
	String returnTicket(int id, int permission);

	/**
	 * 改票
	 * 
	 * @param ticket
	 *            车票对象
	 * @return 成功返回"success" 失败返回"error"
	 */
	String modifyTicket(Ticket ticket, int permission);

	/**
	 * 转签
	 * 
	 * @param ticket
	 *            ticket 车票对象
	 * @return 成功返回"success" 失败返回"error"
	 */
	String signChangeTicket(Ticket ticket, int permission);
}
