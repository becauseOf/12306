package com.neusoft.My12306.service.iservice.plan;

import java.util.List;

import com.neusoft.My12306.dao.pojo.Seat;

/**
 * @author wangzhihao
 *
 *         下午3:10:25 2016年9月18日
 */
public interface ISeatService {
	/**
	 * 保存席位信息
	 * 
	 * @param seat
	 *            席位对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回失败原因
	 */
	String save(Seat seat, int permission);

	/**
	 * 删除席位信息
	 * 
	 * @param seat
	 *            席位对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回失败原因
	 */
	String delete(Seat seat, int permission);

	/**
	 * 修改席位信息
	 * 
	 * @param seat
	 *            席位对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回失败原因
	 */
	String update(Seat seat, int permission);

	/**
	 * 通过id查询席位信息
	 * 
	 * @param seat
	 *            席位对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回null
	 */
	Seat findById(int id, int permission);

	/**
	 * 查询所有席位信息
	 * 
	 * @param seat
	 *            席位对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回失败原因
	 */
	List<Seat> findAll(int permission);

	/**
	 * 获取席位信息
	 * 
	 * @param from
	 *            起始站
	 * @param to
	 *            终点站
	 * @param trainid
	 *            车次
	 * @param num
	 *            车厢
	 * @param seatNumber
	 *            座位号
	 * @param day
	 *            日期
	 * @return
	 */
	Seat getSeat(String from, String to, String trainid, int num, String seatNumber, String day);

}
