package com.neusoft.My12306.service.impl.basedata;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IOrganizeDao;
import com.neusoft.My12306.dao.pojo.Organize;
import com.neusoft.My12306.service.iservice.basedata.IOrganizeService;
import com.neusoft.My12306.util.AdminPermission;

public class OrganizeService implements IOrganizeService {
	private static Logger logger = Logger.getLogger(OrganizeService.class);

	private IOrganizeDao organizeDao;

	public OrganizeService() {
		organizeDao = DaoFactory.getOrganizeDao();
	}

	@Override
	public String save(Organize organize, int permission) {
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				organize.setOrganizeid(organizeDao.getNewId());
				logger.info("正在保存: " + organize);
				organizeDao.save(organize);
				logger.info("成功保存: " + organize);
				return "success";
			} catch (Exception e) {
				logger.info("失败保存: " + organize);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public String delete(Organize organize, int permission) {
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在删除: " + organize);
				organizeDao.delete(organize);
				logger.info("成功删除: " + organize);
				return "success";
			} catch (Exception e) {
				logger.info("失败删除: " + organize);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public String update(Organize organize, int permission) {
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在更新: " + organize);
				organizeDao.update(organize);
				logger.info("成功更新: " + organize);
				return "success";
			} catch (Exception e) {
				logger.info("失败更新: " + organize);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public Organize findById(int id, int permission) {
		Organize organize = null;
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询列车编组信息: id " + id);
				organize = organizeDao.findById(id);
				logger.info("成功查询列车编组信息: id " + id);
			} catch (Exception e) {
				logger.info("失败查询列车编组信息: id " + id);
				logger.error(e);
				e.printStackTrace();
			}
		}
		return organize;
	}

	@Override
	public List<Organize> findAll(int permission) {
		List<Organize> organizeList = new ArrayList<Organize>();
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询所有列车编组信息");
				organizeList.addAll(organizeDao.findAll());
				logger.info("成功查询所有列车编组信息");
			} catch (Exception e) {
				logger.info("失败查询所有列车编组信息");
				logger.error(e);
				e.printStackTrace();
			}
		}
		return organizeList;

	}

	@Override
	public Organize findByTrainAndNum(String trainid, int num) {
		Organize organize = null;
		try {
			logger.info("正在查询列车编组信息: 车次 " + trainid + " 车厢号： " + num);
			organize = organizeDao.findByTrainAndNum(trainid, num);
			logger.info("成功查询列车编组信息: 车次 " + trainid + " 车厢号： " + num);
		} catch (Exception e) {
			logger.info("失败查询询列车编组信息: 车次 " + trainid + " 车厢号： " + num);
			logger.error(e);
			e.printStackTrace();
		}
		return organize;
	}

}
