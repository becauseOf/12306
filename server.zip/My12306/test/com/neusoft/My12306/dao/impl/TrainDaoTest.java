package com.neusoft.My12306.dao.impl;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.ITrainDao;
import com.neusoft.My12306.dao.pojo.Train;

/**
 * @author wangzhihao
 *
 *         下午9:49:27 2016年9月13日
 */
@FixMethodOrder(MethodSorters.DEFAULT)
public class TrainDaoTest {
	private ITrainDao trainDao;

	@Before
	public void setUp() {
		trainDao = DaoFactory.getTrainDao();
	}

	@Test
	public void testSave() throws Exception {
		Train train = new Train("G946", "广州南", "北京", "08:00:00", "17:30:00", 
				"09:30:00", 2197, 0, "普通", "特快");
		trainDao.save(train);
	}

	@Test
	public void testFindAll() throws Exception {
		List<Train> trainList = trainDao.findAll();
		for(Train train : trainList){
			System.out.println(train);
		}
	}

	@Test
	public void testFindById() throws Exception {
		Train train = trainDao.findById("G94");
		assertEquals("广州南", train.getStartStation());
		assertEquals("北京", train.getEndStation());
		assertEquals("08:00:00", train.getStartTime());
		assertEquals("17:30:00", train.getEndTime());
		assertEquals("09:30:00", train.getTime());
		assertEquals(2197, train.getLength());
		assertEquals(0, train.getCount());
		assertEquals("普通", train.getBodyCategory());
		assertEquals("特快", train.getCategory());
	}

	@Test
	public void testUpdate() throws Exception {
		Train train = trainDao.findById("G94");
		train.setCount(10);
		trainDao.update(train);
	}

	@Test
	public void testDelete() throws Exception {
		Train train = trainDao.findById("G94");
		trainDao.delete(train);
	}

}
