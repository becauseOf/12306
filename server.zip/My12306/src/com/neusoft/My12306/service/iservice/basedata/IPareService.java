package com.neusoft.My12306.service.iservice.basedata;

import java.util.List;

import com.neusoft.My12306.dao.pojo.Pare;

/**
 * 票价率管理
 * 
 * @author hezhujun
 *
 */
public interface IPareService {

	/**
	 * 更新票价率信息
	 * 
	 * @param pare
	 *            票价率对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回"error"
	 */
	String update(Pare pare, int permission);

	/**
	 * 通过id查询票价率信息
	 * 
	 * @param id
	 *            id
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Pare对象 失败返回 null
	 */
	Pare findById(int id, int permission);

	/**
	 * 查询所有信息
	 * 
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Pare列表 失败返回 空列表
	 */
	List<Pare> findAll(int permission);
}
