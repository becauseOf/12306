package com.neusoft.My12306.dao.impl;

import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.ISeatDao;
import com.neusoft.My12306.dao.pojo.Seat;

public class SeatDaoTest1 {
	
	ISeatDao seatDao;

	@Before
	public void setUp() throws Exception {
		seatDao = DaoFactory.getSeatDao();
	}

	@Test
	public void testSelectSeat() {
		try {
			Seat seat = seatDao.selectSeat("广州", "北京", "Z202", "硬座", "2016-09-21");
			System.out.println(seat);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Test
	public void testSelectedSeat() {
		fail("Not yet implemented");
	}

	@Test
	public void testCancelSeat() {
		try {
			seatDao.cancelSeat(21);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetSeat() {
		fail("Not yet implemented");
	}

	@Test
	public void testLockToggle() {
		try {
			seatDao.lockToggle(22, "未售");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
