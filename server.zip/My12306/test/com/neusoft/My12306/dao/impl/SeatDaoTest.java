package com.neusoft.My12306.dao.impl;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.ISeatDao;
import com.neusoft.My12306.dao.pojo.Seat;

/**
 * @author wangzhihao
 *
 *         下午9:49:18 2016年9月13日
 */
public class SeatDaoTest {
	private ISeatDao seatDao;

	@Before
	public void setUp() {
		seatDao = DaoFactory.getSeatDao();
	}

	@Test
	public void testDelete() throws Exception {
		Seat seat = seatDao.findById(6);
		seatDao.delete(seat);
	}

	@Test
	public void testFindAll() throws Exception {
		List<Seat> seatList = seatDao.findAll();
		for (Seat s : seatList) {
			System.out.println(s);
		}
	}

	@Test
	public void testFindById() throws Exception {
		Seat seat = seatDao.findById(6);
		assertEquals(6, seat.getSeatid());
		assertEquals("G94", seat.getTrainid());
		assertEquals(1, seat.getNum());
		assertEquals("2", seat.getSeatNubmer());
		assertEquals("广州", seat.getStationStart());
		assertEquals("长沙", seat.getStationEnd());
		assertEquals("2016-09-02", seat.getTime());
		assertEquals("未售", seat.getState());
	}

	@Test
	public void testSave() throws Exception {
		Seat seat = new Seat(seatDao.getNewId(), "G94", 1, "1", "广州", "长沙", "2016-09-02", "未售");
		seatDao.save(seat);
	}

	@Test
	public void testUpdate() throws Exception {
		Seat seat = seatDao.findById(6);
		seat.setSeatNubmer("2");
		seatDao.update(seat);
	}

	@Test
	public void testGetNewId() throws SQLException {
		System.out.println(seatDao.getNewId());
	}

}
