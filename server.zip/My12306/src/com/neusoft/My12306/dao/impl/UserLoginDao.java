package com.neusoft.My12306.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.hehujun.framework.dbhelper.util.IDealWithResultSet;
import com.hehujun.framework.dbhelper.util.ISetStatementParam;
import com.hehujun.framework.dbhelper.util.SQLUtil;
import com.neusoft.My12306.dao.idao.IUserLoginDao;
import com.neusoft.My12306.dao.pojo.User;
import com.neusoft.My12306.dao.pojo.UserLogin;

public class UserLoginDao implements IUserLoginDao {


	@Override
	public boolean validateLogin(String username, String password) throws SQLException {
        // TODO Auto-generated method stub
        String sql  = "select * from T_USERLOGIN WHERE UEMAIL=? AND UPASSWORD=?";

        List<Object> objList = SQLUtil.find(sql, new ISetStatementParam() {
            @Override
            public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
                preparedStatement.setString(1,username);
                preparedStatement.setString(2,password);
            }
        }, new IDealWithResultSet<Object>() {

            @Override
            public Object dealWithResultSet(ResultSet resultSet) throws SQLException {

                return null;
            }
        });
        return !objList.isEmpty();
	}

    @Override
    public void save(UserLogin userLogin) throws Exception {
        String sql = "INSERT into T_USERLOGIN(USERID, UEMAIL, UPASSWORD) VALUES (?,?,?)";
        SQLUtil.save(sql, new ISetStatementParam() {
            @Override
            public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
                preparedStatement.setInt(1,userLogin.getUserid());
                preparedStatement.setString(2,userLogin.getEmail());
                preparedStatement.setString(3,userLogin.getPassword());
            }
        });
    }


}
