package com.neusoft.My12306.dao.impl;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IDydjlDao;
import com.neusoft.My12306.dao.pojo.Dydjl;

/**
 * @author wangzhihao
 *
 *         下午9:48:55 2016年9月13日
 */
public class DydjlDaoTest {
	private IDydjlDao dydjlDao;

	@Before
	public void setUp() {
		dydjlDao = DaoFactory.getDydjlDao();
	}

	@Test
	public void testGetNewId() throws SQLException {
		System.out.println(dydjlDao.getNewId());
	}

	@Test
	public void testSave() throws Exception {
		Dydjl dydjl = new Dydjl(dydjlDao.getNewId(), "1", "200", 0, new BigDecimal(0.05861), new BigDecimal(11.722),
				new BigDecimal(11.722));
		dydjlDao.save(dydjl);
	}

	@Test
	public void testFindAll() throws Exception {
		List<Dydjl> dydjlList = dydjlDao.findAll();
		for (Dydjl d : dydjlList) {
			System.out.println(d);
		}
	}

	@Test
	public void testFindById() throws Exception {
		Dydjl dydjl = dydjlDao.findById(1);
		assertEquals(1, dydjl.getDydjlid());
		assertEquals("1", dydjl.getMileageSectionFrom());
		assertEquals("200", dydjl.getMileageSectionTo());
		assertEquals(0, dydjl.getLapseRate());
	}

	@Test
	public void testUpdate() throws Exception {
		Dydjl dydjl = dydjlDao.findById(1);
		dydjl.setMileageSectionTo("2553");
		dydjlDao.update(dydjl);
	}

	@Test
	public void testDelete() throws Exception {
		Dydjl dydjl = dydjlDao.findById(1);
		dydjlDao.delete(dydjl);
	}

}
