package com.neusoft.My12306.dao.impl;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IPlainDao;
import com.neusoft.My12306.dao.pojo.Plain;


/**
 * @author wangzhihao
 *
 * 下午9:49:10 2016年9月13日
 */
public class PlainDaoTest {
	
	private IPlainDao plainDao;
	
	@Before
	public void setUp(){
		plainDao = DaoFactory.getPlainDao();
	}
	@Test
	public void testDelete() throws Exception {
		Plain plain = plainDao.findById(4);
		plainDao.delete(plain);
	}

	@Test
	public void testFindAll() throws Exception {
		List<Plain> plainList = plainDao.findAll();
		for(Plain p : plainList){
			System.out.println(p);
		}
	}

	@Test
	public void testFindById() throws Exception {
		Plain plain = plainDao.findById(4);
		assertEquals(4, plain.getPlainid());
		assertEquals("Z202", plain.getTrainid());
		assertEquals(1, plain.getNum());
		assertEquals("=", plain.getCompare());
		assertEquals("广州", plain.getStation());
	}

	@Test
	public void testSave() throws Exception {
		Plain plain = new Plain(plainDao.getNewId(),"G94",1,"=","广州");
		plainDao.save(plain);
	}

	@Test
	public void testUpdate() throws Exception {
		Plain plain = plainDao.findById(4);
		plain.setTrainid("Z202");
		plainDao.update(plain);
	}

	@Test
	public void testGetNewId() throws SQLException {
		System.out.println(plainDao.getNewId());;
	}

}
