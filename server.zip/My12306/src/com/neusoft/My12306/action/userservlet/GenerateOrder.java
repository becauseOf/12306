package com.neusoft.My12306.action.userservlet;

import com.google.gson.JsonObject;
import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IOrderDao;
import com.neusoft.My12306.dao.idao.ITicketDao;
import com.neusoft.My12306.dao.pojo.Order;
import com.neusoft.My12306.dao.pojo.Ticket;
import com.neusoft.My12306.dao.pojo.User;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.user.IUserService;
import com.neusoft.My12306.util.GsonUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 进行下订单的操作
 * Created by xiangsong on 2016/9/17.
 */
@WebServlet("/GenerateOrder")
public class GenerateOrder extends HttpServlet{

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String ticketStr = request.getParameter("ticket");
        String orderStr = request.getParameter("order");
        Ticket ticket = (Ticket) GsonUtil.fromJson(ticketStr,Ticket.class);

        Order order = (Order) GsonUtil.fromJson(orderStr,Order.class);
        IUserService userService = ServiceFactory.getUserServiceInstance();
        ITicketDao ticketDao = DaoFactory.getTicketDaoInstance();
        try {
            ticket.setTicketid(ticketDao.getNewId());
        } catch (Exception e) {
            e.printStackTrace();
        }

        IOrderDao orderDao = DaoFactory.getOrderDaoInstance();
        try {
            order.setOrderid(orderDao.getNewId());
        } catch (Exception e) {
            e.printStackTrace();
        }

        JsonObject result = new JsonObject();
        boolean isSuccess = userService.generateOrder(ticket,order);

        result.addProperty("content",isSuccess);

        response.getWriter().println(result.toString());
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        doPost(request, response);
    }

}
