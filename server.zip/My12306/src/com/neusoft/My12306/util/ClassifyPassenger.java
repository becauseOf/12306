package com.neusoft.My12306.util;

import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ClassifyPassenger {
	public static final String REGEX = "^(\\d{6})(\\d{4})(\\d{2})(\\d{2})(\\d{3})([0-9]|X)$";
	public static final Pattern PATTERN = Pattern.compile(REGEX);

	public static String classifyPassenger(String idNumber) {
		Matcher matcher = PATTERN.matcher(idNumber);
		if (matcher.find()) {
			String yearStr = matcher.group(2);
			int year = Integer.parseInt(yearStr);
			Calendar c1 = Calendar.getInstance();

			int i = -1;
			i = c1.get(Calendar.YEAR) - year;
			System.out.println(i);
			if (i != -1) {
				if (i <= 14) {
					return "儿童";
				} else if (i >= 60) {
					return "老人";
				} else {
					return "成年人";
				}
			} else {
				return "身份证号信息有误！";
			}
		} else {
			return "身份证格式有问题！";
		}
	}

}
