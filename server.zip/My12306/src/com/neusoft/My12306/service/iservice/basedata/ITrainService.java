package com.neusoft.My12306.service.iservice.basedata;

import java.util.List;

import com.neusoft.My12306.dao.pojo.Train;

/**
 * 车次信息管理
 * 
 * @author hezhujun
 *
 */
public interface ITrainService {

	/**
	 * 保存车次信息
	 * 
	 * @param train
	 *            车次对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回"error"
	 */
	String save(Train train, int permission);

	/**
	 * 删除车次信息
	 * 
	 * @param train
	 *            车次对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回"error"
	 */
	String delete(Train train, int permission);

	/**
	 * 更新车次信息
	 * 
	 * @param train
	 *            车次对象
	 * @param permission
	 *            基础管理员权限
	 * @return 成功返回"success" 失败返回"error"
	 */
	String update(Train train, int permission);

	/**
	 * 通过id获取车次对象
	 * 
	 * @param id
	 *            id
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Station对象 失败返回 null
	 */
	Train findById(String id, int permission);

	/**
	 * 查询所有车次信息
	 * 
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Train列表 失败返回 空列表
	 */
	List<Train> findAll(int permission);

}
