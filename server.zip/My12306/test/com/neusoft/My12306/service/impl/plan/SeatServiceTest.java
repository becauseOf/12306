package com.neusoft.My12306.service.impl.plan;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.pojo.Seat;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.plan.ISeatService;

public class SeatServiceTest {
	ISeatService seatService;

	@Before
	public void setUp() throws Exception {
		seatService = ServiceFactory.getSeatService();
	}

	@Test
	public void testSave() {
		for(int i= 1; i <= 10 ; i++){
			Seat seat1 = new Seat(0, "Z202", 1, i + "", "广州", "长沙", "2016-09-21", "未售");
			Seat seat2 = new Seat(0, "Z202", 1, i + "", "广州", "武汉", "2016-09-21", "未售");
			Seat seat3 = new Seat(0, "Z202", 1, i + "", "广州", "北京", "2016-09-21", "未售");
			Seat seat4 = new Seat(0, "Z202", 1, i + "", "长沙", "武汉", "2016-09-21", "未售");
			Seat seat5 = new Seat(0, "Z202", 1, i + "", "长沙", "北京", "2016-09-21", "未售");
			Seat seat6 = new Seat(0, "Z202", 1, i + "", "武汉", "北京", "2016-09-21", "未售");
			seatService.save(seat1, 2);
			seatService.save(seat2, 2);
			seatService.save(seat3, 2);
			seatService.save(seat4, 2);
			seatService.save(seat5, 2);
			seatService.save(seat6, 2);
		}
	}

	@Test
	public void testDelete() {
		Seat seat = seatService.findById(0, 2);
		seatService.delete(seat, 2);
	}

	@Test
	public void testUpdate() {
		Seat seat = seatService.findById(6, 2);
		seat.setSeatNubmer("12");
		seatService.update(seat, 2);
	}

	@Test
	public void testFindById() {
		Seat seat = seatService.findById(6, 2);
		System.out.println(seat);
	}

	@Test
	public void testFindAll() {
		List<Seat> seatList = seatService.findAll(2);
		for (Seat s : seatList) {
			System.out.println(s);
		}
	}

}
