package com.neusoft.My12306.service.impl.basedata;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IStationDao;
import com.neusoft.My12306.dao.pojo.Station;
import com.neusoft.My12306.service.iservice.basedata.IStationService;
import com.neusoft.My12306.util.AdminPermission;

public class StationService implements IStationService {

	private static Logger logger = Logger.getLogger(StationService.class);

	private IStationDao stationDao;

	public StationService() {
		stationDao = DaoFactory.getStationDao();
	}

	@Override
	public String save(Station station, int permission) {
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				station.setStationid(stationDao.getNewId());
				logger.info("正在保存: " + station);
				stationDao.save(station);
				logger.info("成功保存: " + station);
				return "success";
			} catch (Exception e) {
				logger.info("失败保存: " + station);
				logger.error(e);
				e.printStackTrace();
				if (e.getMessage().contains("ORA-00001: 违反唯一约束条件")) {
					return "车站名已经存在";
				} else {
					return "error";
				}
			}
		} else {
			return "error";
		}
	}

	@Override
	public String delete(Station station, int permission) {
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在删除: " + station);
				stationDao.delete(station);
				logger.info("成功删除: " + station);
				return "success";
			} catch (Exception e) {
				logger.info("失败删除: " + station);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public String update(Station station, int permission) {
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在更新: " + station);
				stationDao.update(station);
				logger.info("成功更新: " + station);
				return "success";
			} catch (Exception e) {
				logger.info("失败更新: " + station);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public Station findById(int id, int permission) {
		Station station = null;
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询车站信息: id " + id);
				station = stationDao.findById(id);
				logger.info("成功查询车站信息: id " + id);
			} catch (Exception e) {
				logger.info("失败查询车站信息: id " + id);
				logger.error(e);
				e.printStackTrace();
			}
		}
		return station;
	}

	@Override
	public List<Station> findAll(int permission) {
		List<Station> stationList = new ArrayList<Station>();
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询所有车站信息");
				stationList.addAll(stationDao.findAll());
				logger.info("成功查询所有车站信息");
			} catch (Exception e) {
				logger.info("失败查询所有车站信息");
				logger.error(e);
				e.printStackTrace();
			}
		}
		return stationList;
	}

	@Override
	public List<Station> findByName(String name, int permission) {
		List<Station> stationList = new ArrayList<Station>();
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询车站信息: 车站名 " + name);
				stationList.addAll(stationDao.findByName(name));
				logger.info("成功查询所有车站信息: 车站名 " + name);
			} catch (Exception e) {
				logger.info("失败查询所有车站信息: 车站名 " + name);
				logger.error(e);
				e.printStackTrace();
			}
		}
		return stationList;
	}

	@Override
	public List<Station> findByPinyin(String name, int permission) {
		List<Station> stationList = new ArrayList<Station>();
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询车站信息: 拼音 " + name);
				stationList.addAll(stationDao.findByPinyin(name));
				logger.info("成功查询所有车站信息: 拼音 " + name);
			} catch (Exception e) {
				logger.info("失败查询所有车站信息: 拼音 " + name);
				logger.error(e);
				e.printStackTrace();
			}
		}
		return stationList;
	}

}
