package com.neusoft.My12306.action.servlet.bill;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.My12306.action.dispatch.DealWithBill;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.bill.IBillService;

@WebServlet("/BillServlet")
public class BillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private IBillService billService;

	public BillServlet() {
		super();
		billService = ServiceFactory.getBillService();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int permission = 4;
		String operation = request.getParameter("operation");
		if (operation == null) {
			DealWithBill.dealWithMainPage(request, response);
		} else if ("getticket".equals(operation)) {
			int ticketid = Integer.parseInt(request.getParameter("ticketid"));
			billService.getTicket(ticketid, permission);
			response.sendRedirect("BillServlet");
		} else if ("returnticket".equals(operation)) {
			int ticketid = Integer.parseInt(request.getParameter("ticketid"));
			billService.returnTicket(ticketid, permission);
			response.sendRedirect("BillServlet");
		} else if ("modifyticket".equals(operation)) {
			DealWithBill.dealWithModifyticket(request, response);
		} else if ("sigchangeticket".equals(operation)) {
			DealWithBill.dealWithSignChangeticket(request, response);
		} else if ("findremainticket".equals(operation)) {
			DealWithBill.dealWithFindRemainTicket(request, response);
		} else if ("buy".equals(operation)) {
			DealWithBill.dealWithBuy(request, response, permission);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
