package com.neusoft.My12306.util;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.neusoft.My12306.dao.pojo.Dydjl;
import com.neusoft.My12306.dao.pojo.Pare;
import com.neusoft.My12306.dao.pojo.Tripsection;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.IDydjlService;
import com.neusoft.My12306.service.iservice.basedata.IPareService;
import com.neusoft.My12306.service.iservice.basedata.IRouteService;
import com.neusoft.My12306.service.iservice.basedata.ITripsectionService;

public class CalculatePrice {

	private static IRouteService routeService = ServiceFactory.getRouteService();
	private static ITripsectionService trService = ServiceFactory.getTripsectionService();
	private static IPareService pareService = ServiceFactory.getPareService();
	private static IDydjlService dydjlService = ServiceFactory.getDydjlService();
	private static Map<String, Integer> ticketPrice = null;

	/**
	 * 计算票价
	 * 
	 * @param stationStart
	 *            出发车站
	 * @param stationEnd
	 *            到达车站
	 * @param seatClass
	 *            车票类型: 硬座、软座、硬卧、软卧
	 * @param trainid
	 *            车次
	 * @return 票价
	 */
	public static BigDecimal getPrice(String stationStart, String stationEnd, String seatClass, String trainid) {
		long length = routeService.getLength(trainid, stationStart, stationEnd);
		// 计算实际计算的里程
		length = getLength(length);
		// 计算硬席基本价：
		BigDecimal basePrice = getBasePrice(length);
		// 保险费(单位：角， 取整)
		BigDecimal baoxian = basePrice.multiply(new BigDecimal("0.02")).setScale(1, BigDecimal.ROUND_UP);
		// 客票价(四舍五入取整)
		BigDecimal kepiao = new BigDecimal(0);
		if ("硬".equals(seatClass.substring(0, 1))) {
			// 硬席客票价格
			kepiao = kepiao.add(basePrice).add(baoxian).setScale(0, BigDecimal.ROUND_HALF_UP);
		} else {
			// 软席客票价格
			kepiao = kepiao.add(basePrice).multiply(new BigDecimal(2)).setScale(0, BigDecimal.ROUND_HALF_UP);
		}
		// 特快加快票价格(四舍五入取整)
		BigDecimal tekuai = basePrice.multiply(new BigDecimal("0.4")).setScale(0, BigDecimal.ROUND_HALF_UP);
		// 空调票价格(四舍五入取整)
		BigDecimal kongtiao = basePrice.multiply(new BigDecimal("0.25")).setScale(0, BigDecimal.ROUND_HALF_UP);
		// 卧铺票价格(四舍五入取整)
		BigDecimal wopu = new BigDecimal(0);
		ticketPrice = getTicketPrice();
		if ("卧".equals(seatClass.substring(1, 2))) {
			if ("硬".equals(seatClass.substring(1, 2))) {
				// 硬席卧铺票
				wopu.add(basePrice).multiply(new BigDecimal(ticketPrice.get("硬卧上"))).divide(new BigDecimal(100))
						.setScale(0, BigDecimal.ROUND_HALF_UP);
			} else {
				// 软席卧铺票
				wopu.add(basePrice).multiply(new BigDecimal(ticketPrice.get("软卧上"))).divide(new BigDecimal(100))
						.setScale(0, BigDecimal.ROUND_HALF_UP);
			}
		}
		// 新型空调车上浮50%:客票价,特快加快票价格,空调票价格,卧铺票价格.(四舍五入取整)
		kepiao = kepiao.multiply(new BigDecimal("1.5")).setScale(0, BigDecimal.ROUND_HALF_UP);
		tekuai = tekuai.multiply(new BigDecimal("1.5")).setScale(0, BigDecimal.ROUND_HALF_UP);
		kongtiao = kongtiao.multiply(new BigDecimal("1.5")).setScale(0, BigDecimal.ROUND_HALF_UP);
		wopu = wopu.multiply(new BigDecimal("1.5")).setScale(0, BigDecimal.ROUND_HALF_UP);
		// 附加费:卧铺订票费10元,客票发展金1元
		BigDecimal fujia = new BigDecimal(1);
		if ("卧".equals(seatClass.substring(1, 2))) {
			fujia.add(new BigDecimal(10));
		}
		// 求和取整:
		return kepiao.add(tekuai.add(kongtiao)).add(wopu).add(fujia);
	}

	private static Map<String, Integer> getTicketPrice() {
		Map<String, Integer> ticketPrice = new HashMap<String, Integer>();
		List<Pare> pareList = pareService.findAll(1);
		for (Pare pare : pareList) {
			ticketPrice.put(pare.getTicketType(), pare.getRatio());
		}
		return ticketPrice;
	}

	/**
	 * 获取计算票价的里程
	 * 
	 * @param length
	 *            线路里程
	 * @return 里程
	 */
	public static long getLength(long length) {
		// 计算里程
		List<Tripsection> trList = trService.findAll(1);
		for (Tripsection tr : trList) {
			long from = Long.parseLong(tr.getMileageSectionFrom());
			if (from <= length) {
				if ("以上".equals(tr.getMileageSectionTo())) {
					long duo = length - from + 1;
					long yu = duo % tr.getLength();
					length = length - yu + tr.getLength() / 2;
					return length;
				} else {
					long to = Long.parseLong(tr.getMileageSectionTo());
					if (length <= to) {
						long duo = length - from + 1;
						long yu = duo % tr.getLength();
						length = length - yu + tr.getLength() / 2;
						return length;
					}
				}
			}
		}
		return 0;
	}

	public static BigDecimal getBasePrice(long length) {
		List<Dydjl> dydjlList = dydjlService.findAll(1);
		int current = 0;
		for (int i = 0; i < dydjlList.size(); i++) {
			long from = Long.parseLong(dydjlList.get(i).getMileageSectionFrom());
			if (from <= length) {
				if ("以上".equals(dydjlList.get(i).getMileageSectionTo())) {
					current = i;
					// 已经到最后
				} else {
					long to = Long.parseLong(dydjlList.get(i).getMileageSectionTo());
					if (length <= to) {
						current = i;
						break;
					}
				}
			}
		}
		// 该区段的票价率
		BigDecimal currentPare = dydjlList.get(current).getFares();
		// 该区段的里程
		long len = length - Long.parseLong(dydjlList.get(current).getMileageSectionFrom()) + 1;
		// 该区段中里程的价格
		BigDecimal currentPrice = currentPare.multiply(new BigDecimal(len));
		if (current == 0) {
			// 按起码里程算
			return dydjlList.get(0).getTotal();
		} else {
			// 之前区段价格+该区段的价格
			return currentPrice.add(dydjlList.get(current - 1).getTotal());
		}

	}

}
