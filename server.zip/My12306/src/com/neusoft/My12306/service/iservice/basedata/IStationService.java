package com.neusoft.My12306.service.iservice.basedata;

import java.util.List;

import com.neusoft.My12306.dao.pojo.Station;

/**
 * 车站管理
 * 
 * @author hezhujun
 *
 */
public interface IStationService {
	/**
	 * 保存车站信息
	 * 
	 * @param station
	 *            车站对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回失败原因
	 */
	String save(Station station, int permission);

	/**
	 * 删除车站信息
	 * 
	 * @param station
	 *            车站对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回"error"
	 */
	String delete(Station station, int permission);

	/**
	 * 更新车站信息
	 * 
	 * @param station
	 *            车站信息
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回"error"
	 */
	String update(Station station, int permission);

	/**
	 * 通过id查询车站信息
	 * 
	 * @param id
	 *            id
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Station对象 失败返回 null
	 */
	Station findById(int id, int permission);

	/**
	 * 查询所有车站信息
	 * 
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Station列表 失败返回 空列表
	 */
	List<Station> findAll(int permission);

	/**
	 * 通过车站名查询
	 * 
	 * @param name
	 *            车站名
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Station列表 失败返回 空列表
	 */
	List<Station> findByName(String name, int permission);

	/**
	 * 通过拼音查询
	 * 
	 * @param name
	 *            车站名
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Station列表 失败返回 空列表
	 */
	List<Station> findByPinyin(String name, int permission);

}
