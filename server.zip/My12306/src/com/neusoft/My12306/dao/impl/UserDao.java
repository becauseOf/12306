package com.neusoft.My12306.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.hehujun.framework.dbhelper.util.IDealWithResultSet;
import com.hehujun.framework.dbhelper.util.ISetStatementParam;
import com.hehujun.framework.dbhelper.util.SQLUtil;
import com.neusoft.My12306.dao.idao.IUserDao;
import com.neusoft.My12306.dao.pojo.*;

public class UserDao implements IUserDao {

	@Override
	public void delete(User arg0) throws Exception {
		// TODO Auto-generated method stub
		String sql = "delete from t_user where userid=?";
		SQLUtil.delete(sql, new ISetStatementParam() {
			@Override
			public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setInt(1,arg0.getUserid());
			}
		});
	}

	@Override
	public List<User> findAll() throws Exception {
		// TODO Auto-generated method stub
        String sql  = "select userid,uemail,uname,usex,uidcard,uphone,ureclogtime,ustade from t_user";
		List<Object> objectList = SQLUtil.find(sql, new IDealWithResultSet<Object>() {

            @Override
            public Object dealWithResultSet(ResultSet resultSet) throws SQLException {
                User user = new User();
                user.setUserid(resultSet.getInt(1));
                user.setEmail(resultSet.getString(2));
                user.setName(resultSet.getString(3));
                user.setSex(resultSet.getString(4));
                user.setIdcard(resultSet.getString(5));
                user.setPhone(resultSet.getString(6));
                user.setLastLoginTime(resultSet.getString(7));
                user.setState(resultSet.getString(8));

                return user;
            }
        });

        List<User> userList = new ArrayList<>();
        for(Object obj:objectList){
            userList.add((User) obj);
        }

		return userList;
	}

	@Override
	public User findById(Integer arg0) throws Exception {
		// TODO Auto-generated method stub
        /**
         * 标识符无效？
         */
        String sql  = "select userid,uemail,uname,usex,uidcard,uphone,ureclogtime,usate from t_user WHERE userid=?";
        List<Object> objList = SQLUtil.find(sql, new ISetStatementParam() {
            @Override
            public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
                preparedStatement.setInt(1,arg0);
            }
        }, new IDealWithResultSet<Object>() {

            @Override
            public Object dealWithResultSet(ResultSet resultSet) throws SQLException {

                User user = new User();
                user.setUserid(resultSet.getInt(1));
                user.setEmail(resultSet.getString(2));
                user.setName(resultSet.getString(3));
                user.setSex(resultSet.getString(4));
                user.setIdcard(resultSet.getString(5));
                user.setPhone(resultSet.getString(6));
                user.setLastLoginTime(resultSet.getString(7));
                user.setState(resultSet.getString(8));

                return user;
            }
        });
        User user = null;
        if (!objList.isEmpty()) {
            user = (User) objList.get(0);
        }
        return user;
	}

	@Override
	public void save(User arg0) throws Exception {
		// TODO Auto-generated method stub
        String sql = "INSERT INTO T_USER(USERID, UEMAIL, UNAME, USEX, UIDCARD, UPHONE, URECLOGTIME, USATE) VALUES (?,?,?,?,?,?,?,?)";
        SQLUtil.save(sql, new ISetStatementParam() {
            @Override
            public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
                preparedStatement.setInt(1,arg0.getUserid());
                preparedStatement.setString(2,arg0.getEmail());
                preparedStatement.setString(3,arg0.getName());
                preparedStatement.setString(4,arg0.getSex());
                preparedStatement.setString(5,arg0.getIdcard());
                preparedStatement.setString(6,arg0.getPhone());
                preparedStatement.setString(7,arg0.getLastLoginTime());
                preparedStatement.setString(8,arg0.getState());
            }
        });


	}

	@Override
	public void update(User arg0) throws Exception {
		    // TODO Auto-generated method stub
        String sql = "UPDATE T_USER SET UEMAIL=?,UNAME=?,USEX=?,UIDCARD=?,UPHONE=?,URECLOGTIME=?,USATE=? WHERE USERID=?";
        SQLUtil.update(sql, new ISetStatementParam() {
            @Override
            public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
                preparedStatement.setString(1,arg0.getEmail());
                preparedStatement.setString(2,arg0.getName());
                preparedStatement.setString(3,arg0.getSex());
                preparedStatement.setString(4,arg0.getIdcard());
                preparedStatement.setString(5,arg0.getPhone());
                preparedStatement.setString(6,arg0.getLastLoginTime());
                preparedStatement.setString(7,arg0.getState());
                preparedStatement.setInt(8,arg0.getUserid());
            }
        });


	}

	@Override
	public int getNewId() throws SQLException {
		// TODO Auto-generated method stub
        String sql = "SELECT max(USERID) FROM T_USER";
        List<Object> i = SQLUtil.executeAndGetResult(sql, new IDealWithResultSet<Object>() {
            @Override
            public Object dealWithResultSet(ResultSet resultSet) throws SQLException {
                Integer i = new Integer(resultSet.getInt(1)+1);
                return i;
            }
        });
		return (i.size() == 0 ? 0 : (int) i.get(0));
	}

    @Override
    public User findByEmail(String email) throws Exception {
        String sql  = "select userid,uemail,uname,usex,uidcard,uphone,ureclogtime,usate from t_user WHERE uemail=?";
        List<Object> objList = SQLUtil.find(sql, new ISetStatementParam() {
            @Override
            public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
                preparedStatement.setString(1,email);
            }
        }, new IDealWithResultSet<Object>() {

            @Override
            public Object dealWithResultSet(ResultSet resultSet) throws SQLException {

                User user = new User();
                user.setUserid(resultSet.getInt(1));
                user.setEmail(resultSet.getString(2));
                user.setName(resultSet.getString(3));
                user.setSex(resultSet.getString(4));
                user.setIdcard(resultSet.getString(5));
                user.setPhone(resultSet.getString(6));
                user.setLastLoginTime(resultSet.getString(7));
                user.setState(resultSet.getString(8));

                return user;
            }
        });
        User user = null;
        if (!objList.isEmpty()) {
            user = (User) objList.get(0);
        }
        return user;
    }

    @Override
    public List queryTicket(String fromCity, String toCity, String date, boolean isOnlyQueryG, boolean isOnlyQueryZ) throws Exception {
        String sql = "SELECT T_SEAT.TRAINID,T_TRAIN.START_TIME,T_TRAIN.END_TIME,T_ORGANIZE.SEAT_CLASS,COUNT(T_SEAT.SEATID)\n" +
                "FROM T_SEAT INNER JOIN T_ORGANIZE ON T_SEAT.TRAINID = T_ORGANIZE.TRAINID\n" +
                "                                     AND T_SEAT.NUM = T_ORGANIZE.NUM INNER JOIN T_TRAIN ON T_SEAT.TRAINID = T_TRAIN.TRAINID INNER JOIN T_PLAIN ON T_SEAT.TRAINID = T_PLAIN.TRAINID AND T_SEAT.NUM = T_PLAIN.NUM\n" +
                "WHERE T_SEAT.STATE='未售' AND  T_TRAIN.TRAINID IN (SELECT TRAINID FROM T_TRAIN\n" +
                "WHERE START_STATION  IN (SELECT T_STATION.STATIONNAME FROM T_STATION WHERE T_STATION.STATIONID < (SELECT T_STATION.STATIONID FROM T_STATION WHERE T_STATION.STATIONNAME=?))\n" +
                " AND END_STATION  IN (SELECT T_STATION.STATIONNAME FROM T_STATION WHERE T_STATION.STATIONID > (SELECT T_STATION.STATIONID FROM T_STATION WHERE T_STATION.STATIONNAME=?))\n" +
                "AND to_date(to_char(START_TIME,'yyyy-mm-dd'),'yyyy-mm-dd')=to_date(?,'yyyy-mm-dd') AND TRAINID like ? )\n" +
                "GROUP BY T_SEAT.TRAINID,T_TRAIN.START_TIME,T_TRAIN.END_TIME,T_ORGANIZE.SEAT_CLASS";


        List<Object> objList = SQLUtil.find(sql, new ISetStatementParam() {
            @Override
            public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
                preparedStatement.setString(1,fromCity);
                preparedStatement.setString(2,toCity);
                preparedStatement.setString(3,date);
                if (isOnlyQueryG) {
                    preparedStatement.setString(4,"G%");
                }else if (isOnlyQueryZ) {
                    preparedStatement.setString(4,"Z%");
                }else if (isOnlyQueryG&&isOnlyQueryZ) {
                    preparedStatement.setString(4,"%");
                }else {
                    preparedStatement.setString(4,"%");
                }

            }
        }, new IDealWithResultSet<Object>() {

            @Override
            public Object dealWithResultSet(ResultSet resultSet) throws SQLException {

                HashMap<String,Integer> hashMap = new HashMap<String, Integer>();
                RemainTicketItem remainTicketItem = new RemainTicketItem();
                remainTicketItem.setStartTime(resultSet.getString(2));
                remainTicketItem.setEndTime(resultSet.getString(3));
                remainTicketItem.setTrainId(resultSet.getString(1));

                hashMap.put(resultSet.getString(4),resultSet.getInt(5));
                remainTicketItem.setNumsItem(hashMap);

                return remainTicketItem;
            }
        });


        RemainTicket remainTicket ;
        List<HashMap<String,Integer>> hashMapList = new ArrayList<HashMap<String, Integer>>();

        HashMap<String,Integer> hashMap;

        List<RemainTicket> list = new ArrayList<>();

        int i = 0,count = 0;
        Map.Entry<String,Integer> entey;
        if (!objList.isEmpty()) {
            for (int j = 0; j <objList.size() ; j++) {
                RemainTicketItem rNew = (RemainTicketItem) objList.get(j);
                RemainTicketItem rOld = (RemainTicketItem) objList.get(i);
                remainTicket = new RemainTicket();
                remainTicket.setTrainId(rOld.getTrainId());
                remainTicket.setStartTime(rOld.getStartTime());
                remainTicket.setEndTime(rOld.getEndTime());

                while (rNew.getTrainId().equals(rOld.getTrainId())){
                    count++;
                    hashMap = new HashMap<>();
                    entey = rNew.getNumsItem().entrySet().iterator().next();
                    hashMap.put(entey.getKey(),entey.getValue());
                    hashMapList.add(hashMap);
                    if (count==objList.size()-1) {
                        break;
                    }
                    count = count==objList.size()-1?count-1:count;
                }
                i = count+1;
                j = count+1;

                rNew = (RemainTicketItem) objList.get(i-1);
                hashMap = new HashMap<>();
                entey = rNew.getNumsItem().entrySet().iterator().next();
                hashMap.put(entey.getKey(),entey.getValue());
                hashMapList.add(hashMap);

                remainTicket.setRemainNums(hashMapList);
                list.add(remainTicket);

            }
        }

        return list;
    }

    @Override
    public boolean generateOrder(Ticket ticket, Order order) throws Exception {

        return false;
    }

    @Override
    public boolean operateOrder(int orderid, int operation) throws Exception {
        return false;
    }

    @Override
    public boolean operateOrder(int orderid, Ticket ticket) throws Exception {
        return false;
    }

    @Override
    public List queryOrder(String userId) throws Exception {
        return null;
    }

    @Override
    public void updateByEmail(User arg0) throws Exception {
        String sql = "UPDATE T_USER SET UEMAIL=?,UNAME=?,USEX=?,UIDCARD=?,UPHONE=?,USATE=? WHERE UEMAIL=?";
        SQLUtil.update(sql, new ISetStatementParam() {
            @Override
            public void setStatementParam(PreparedStatement preparedStatement) throws SQLException {
                preparedStatement.setString(1,arg0.getEmail());
                preparedStatement.setString(2,arg0.getName());
                preparedStatement.setString(3,arg0.getSex());
                preparedStatement.setString(4,arg0.getIdcard());
                preparedStatement.setString(5,arg0.getPhone());
                preparedStatement.setString(6,arg0.getState());
                preparedStatement.setString(7,arg0.getEmail());
            }
        });
    }

}
