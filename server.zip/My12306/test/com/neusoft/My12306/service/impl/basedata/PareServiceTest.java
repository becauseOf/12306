package com.neusoft.My12306.service.impl.basedata;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.pojo.Pare;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.IPareService;

public class PareServiceTest {

	private IPareService pareService;

	@Before
	public void setUp() throws Exception {
		pareService = ServiceFactory.getPareService();
	}

	@Test
	public void testUpdate() {
		Pare pare = pareService.findById(1, 1);
		pare.setRatio(100);
		pareService.update(pare, 1);
	}

	@Test
	public void testFindById() {
		Pare pare = pareService.findById(1, 1);
		System.out.println(pare);
	}

	@Test
	public void testFindAll() {
		List<Pare> pareList = pareService.findAll(1);
		for (Pare pare : pareList) {
			System.out.println(pare);
		}
	}

}
