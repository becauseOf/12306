package com.neusoft.My12306.service.impl.admin;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.pojo.Admin;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.admin.IAdminService;

public class AdminServiceTest {

	IAdminService adminService;

	@Before
	public void setUp() {
		adminService = ServiceFactory.getAdminService();
	}

	@Test
	public void testSave() {
		Admin admin = new Admin(0, "superadmin1", "123", 0);
		System.out.println(adminService.save(admin, 0));
	}

	@Test
	public void testDelete() {
		Admin admin = adminService.findById(2, 0);
		adminService.delete(admin, 0);
	}

	@Test
	public void testUpdate() {
		Admin admin = adminService.findById(3, 0);
		admin.setPassword("123456");
		adminService.update(admin, 0);
	}

	@Test
	public void testFindById() {
		Admin admin = adminService.findById(3, 0);
		System.out.println(admin);
	}

	@Test
	public void testFindAll() {
		List<Admin> adminList = adminService.findAll(0);
		for (Admin admin : adminList) {
			System.out.println(admin);
		}
	}

}
