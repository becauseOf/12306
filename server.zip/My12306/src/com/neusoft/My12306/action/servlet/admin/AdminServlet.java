package com.neusoft.My12306.action.servlet.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.My12306.action.dispatch.admin.DealWithAdmin;
import com.neusoft.My12306.dao.pojo.Admin;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.admin.IAdminService;

@WebServlet("/AdminServlet")
public class AdminServlet {
	private IAdminService adminService;
	
	public AdminServlet(){
		super();
		adminService = ServiceFactory.getAdminService();
	}
	
	protected void doGet(HttpServletRequest request,HttpServletResponse response) 
			throws ServletException,IOException{
		String operation = request.getParameter("operation");
		//获取当前管理员的权限
		int permission = 0;
		//返回管理员操作主页
		if(operation == null){
			List<Admin> adminList = adminService.findAll(permission);
			request.setAttribute("adminList", adminList);
			request.getRequestDispatcher("WEB-INF/view/admin/adminManager.jsp").forward(request, response);
			
		}//处理管理员数据更新
		else if("update".equalsIgnoreCase(operation)){
			if(request.getParameter("submit") != null){
				String result = DealWithAdmin.updateAdmin(request, adminService, permission);
				if("success".equals(result)){
					response.sendRedirect("AdminServlet");
				}else{
					request.setAttribute("message", result);
					request.getRequestDispatcher("WEB-INF/view/admin/reviseAdmin.jsp").forward(request, response);
					
				}
			}
			else{
				int id = Integer.parseInt(request.getParameter("adminid"));
				Admin admin = adminService.findById(id, permission);
				request.setAttribute("admin", admin);
				request.getRequestDispatcher("WEB-INF/view/admin/reviseAdmin.jsp").forward(request, response);
				
			}
		}
	}
	protected void doPost(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{
		doGet(request,response);
	}
}
