package com.neusoft.My12306.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hehujun.framework.dbhelper.util.IDealWithResultSet;
import com.hehujun.framework.dbhelper.util.ISetStatementParam;
import com.hehujun.framework.dbhelper.util.SQLUtil;
import com.neusoft.My12306.dao.idao.ITripsectionDao;
import com.neusoft.My12306.dao.pojo.Tripsection;

public class TripsectionDao implements ITripsectionDao {

	@Override
	public void delete(Tripsection tr) throws Exception {
		String sql = "delete from t_tripsection where tripsectionid=?";
		SQLUtil.delete(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, tr.getTripsectionid());
			}
		});

	}

	@Override
	public List<Tripsection> findAll() throws Exception {
		String sql = "SELECT JAVA.T_TRIPSECTION.TRIPSECTIONID, " + "JAVA.T_TRIPSECTION.MILEAGE_SECTIONFROM, "
				+ "JAVA.T_TRIPSECTION.MILEAGE_SECTIONTO, " + "JAVA.T_TRIPSECTION.LENGTH, " + "JAVA.T_TRIPSECTION.COUNT "
				+ "FROM JAVA.T_TRIPSECTION order by tripsectionid asc";
		List<Object> oList = SQLUtil.find(sql, new IDealWithResultSet<Tripsection>() {

			@Override
			public Tripsection dealWithResultSet(ResultSet rs) throws SQLException {
				Tripsection tripsection = new Tripsection();
				tripsection.setTripsectionid(rs.getInt(1));
				tripsection.setMileageSectionFrom(rs.getString(2));
				tripsection.setMileageSectionTo(rs.getString(3));
				tripsection.setLength(rs.getLong(4));
				tripsection.setCount(rs.getInt(5));
				return tripsection;
			}
		});
		List<Tripsection> tripsectionList = new ArrayList<Tripsection>();
		for (Object o : oList) {
			tripsectionList.add((Tripsection) o);
		}
		return tripsectionList;
	}

	@Override
	public Tripsection findById(Integer id) throws Exception {
		String sql = "SELECT JAVA.T_TRIPSECTION.TRIPSECTIONID, " + "JAVA.T_TRIPSECTION.MILEAGE_SECTIONFROM, "
				+ "JAVA.T_TRIPSECTION.MILEAGE_SECTIONTO, " + "JAVA.T_TRIPSECTION.LENGTH, " + "JAVA.T_TRIPSECTION.COUNT "
				+ "FROM JAVA.T_TRIPSECTION where tripsectionid=? order by tripsectionid asc";
		List<Object> oList = SQLUtil.find(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, id);
			}
		}, new IDealWithResultSet<Tripsection>() {

			@Override
			public Tripsection dealWithResultSet(ResultSet rs) throws SQLException {
				Tripsection tripsection = new Tripsection();
				tripsection.setTripsectionid(rs.getInt(1));
				tripsection.setMileageSectionFrom(rs.getString(2));
				tripsection.setMileageSectionTo(rs.getString(3));
				tripsection.setLength(rs.getLong(4));
				tripsection.setCount(rs.getInt(5));
				return tripsection;
			}
		});
		Tripsection tr = null;
		if (!oList.isEmpty()) {
			tr = (Tripsection) oList.get(0);
		}
		return tr;
	}

	@Override
	public void save(Tripsection tr) throws Exception {
		String sql = "insert into t_tripsection(tripsectionid, " + "mileage_sectionfrom, mileage_sectionto, "
				+ "length, count) values(?,?,?,?,?)";
		SQLUtil.save(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, tr.getTripsectionid());
				ps.setString(2, tr.getMileageSectionFrom());
				ps.setString(3, tr.getMileageSectionTo());
				ps.setLong(4, tr.getLength());
				ps.setInt(5, tr.getCount());
			}
		});
	}

	@Override
	public void update(Tripsection tr) throws Exception {
		String sql = "update t_tripsection set mileage_sectionfrom=?, "
				+ "mileage_sectionto=?, length=?, count=? where tripsectionid=?";
		SQLUtil.update(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, tr.getMileageSectionFrom());
				ps.setString(2, tr.getMileageSectionTo());
				ps.setLong(3, tr.getLength());
				ps.setInt(4, tr.getCount());
				ps.setInt(5, tr.getTripsectionid());
			}
		});
	}

	@Override
	public int getNewId() throws SQLException {
		String sql = "select max(tripsectionid) from t_tripsection";
		List<Object> i = SQLUtil.executeAndGetResult(sql, new IDealWithResultSet<Integer>() {

			@Override
			public Integer dealWithResultSet(ResultSet rs) throws SQLException {
				Integer i = new Integer(rs.getInt(1) + 1);
				return i;
			}
		});
		return (i.size() == 0 ? 0 : (int) i.get(0));
	}

}
