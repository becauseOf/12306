package com.neusoft.My12306.dao.pojo;

/**
 * 计划信息
 * 
 * @author hezhujun
 *
 */
public class Plain {
	private int plainid;
	private String trainid;
	private int num;
	private String compare;
	private String station;

	public int getPlainid() {
		return plainid;
	}

	public void setPlainid(int plainid) {
		this.plainid = plainid;
	}

	public String getTrainid() {
		return trainid;
	}

	public void setTrainid(String trainid) {
		this.trainid = trainid;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getCompare() {
		return compare;
	}

	public void setCompare(String compare) {
		this.compare = compare;
	}

	public String getStation() {
		return station;
	}

	public void setStation(String station) {
		this.station = station;
	}

	public Plain() {
		// TODO Auto-generated constructor stub
	}

	public Plain(int plainid, String trainid, int num, String compare, String station) {
		super();
		this.plainid = plainid;
		this.trainid = trainid;
		this.num = num;
		this.compare = compare;
		this.station = station;
	}

	@Override
	public String toString() {
		return "Plain [plainid=" + plainid + ", trainid=" + trainid + ", num=" + num + ", compare=" + compare
				+ ", station=" + station + "]";
	}

}
