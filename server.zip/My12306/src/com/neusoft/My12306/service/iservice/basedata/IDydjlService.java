package com.neusoft.My12306.service.iservice.basedata;

import java.util.List;

import com.neusoft.My12306.dao.pojo.Dydjl;

/**
 * 递远递减率管理
 * 
 * @author hezhujun
 *
 */
public interface IDydjlService {
	/**
	 * 更新递远递减率信息
	 * 
	 * @param dydjl
	 *            递远递减率对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回"error"
	 */
	String update(Dydjl dydjl, int permission);

	/**
	 * 通过id查询递远递减率信息
	 * 
	 * @param id
	 *            id
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Dydjl对象 失败返回 null
	 */
	Dydjl findById(int id, int permission);

	/**
	 * 查询所有信息
	 * 
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Dydjl列表 失败返回 空列表
	 */
	List<Dydjl> findAll(int permission);
}
