package com.neusoft.My12306.service.iservice.basedata;

import java.util.List;

import com.neusoft.My12306.dao.pojo.Organize;

/**
 * 车厢编组管理
 * 
 * @author hezhujun
 *
 */
public interface IOrganizeService {
	/**
	 * 保存车厢编组信息
	 * 
	 * @param organize
	 *            车厢编组对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回"error"
	 */
	String save(Organize organize, int permission);

	/**
	 * 删除车厢编组信息
	 * 
	 * @param organize
	 *            车厢编组对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回"error"
	 */
	String delete(Organize organize, int permission);

	/**
	 * 更新车厢编组信息
	 * 
	 * @param organize
	 *            车厢编组对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回"error"
	 */
	String update(Organize organize, int permission);

	/**
	 * 通过id查询车厢编组信息
	 * 
	 * @param id
	 *            id
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Organize对象 失败返回 null
	 */
	Organize findById(int id, int permission);

	/**
	 * 通过列车车次和车厢号查询
	 * @param trainid 列车车次
	 * @param num 车厢号
	 * @return 列车编组信息
	 */
	Organize findByTrainAndNum(String trainid, int num);

	/**
	 * 查询所有信息
	 * 
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Organize列表 失败返回 空列表
	 */
	List<Organize> findAll(int permission);
}
