package com.neusoft.My12306.action.userservlet;

import com.google.gson.JsonObject;
import com.neusoft.My12306.dao.impl.UserLoginDao;
import com.neusoft.My12306.dao.pojo.User;
import com.neusoft.My12306.dao.pojo.UserLogin;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.impl.user.UserServiceImpl;
import com.neusoft.My12306.service.iservice.user.IUserService;
import com.neusoft.My12306.util.GsonUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 注册用户
 * Created by xiangsong on 2016/9/17.
 */
@WebServlet("/Register")
public class Register extends HttpServlet{

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userStr = request.getParameter("user");
        User user = (User) GsonUtil.fromJson(userStr,User.class);
        String loginStr = request.getParameter("login");
        UserLogin login = (UserLogin) GsonUtil.fromJson(loginStr,UserLogin.class);

        IUserService userService = ServiceFactory.getUserServiceInstance();

        JsonObject result = new JsonObject();
        boolean isSuccess = userService.registerUser(user.getEmail(),user.getName(),user.getSex(),user.getPhone(),user.getIdcard(),login.getPassword());

        result.addProperty("content",isSuccess);

        response.getWriter().println(result.toString());
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        doPost(request, response);
    }
}
/*
* //////////////////////////////////////////////////////////////////
	@Test
	public void testSaveOrder()throws Exception{
		IOrderDao orderDao = DaoFactory.getOrderDaoInstance();
		orderDao.save(new Order(orderDao.getNewId(),1,"已支付","2016-9-18"));
	}
	@Test
	public void testUpdateOrder()throws Exception{
		IOrderDao orderDao = DaoFactory.getOrderDaoInstance();
		orderDao.updateOrderStatus(2,"未支付");
	}

	@Test
	public void testSaveTicket()throws Exception{
		ITicketDao ticketDao = DaoFactory.getTicketDaoInstance();
		ticketDao.save(new Ticket(ticketDao.getNewId(),"Z202","2016-9-18",1,"12","长沙","武汉","向松","学生","155332635263",",","","","未取票","","",""));

	}
	@Test
	public void testUpdateTicketStatus()throws Exception{
		ITicketDao ticketDao = DaoFactory.getTicketDaoInstance();
		List<Ticket> list = ticketDao.findByPhoneId("155332635263");
		ticketDao.updateTicketStatus("155332635263","已取票");
	}
	@Test
	public void testUpdateTicket()throws Exception{
		/*ITicketDao ticketDao = DaoFactory.getTicketDaoInstance();
		ticketDao.update(new Ticket(ticketDao.getNewId(),"Z202","2016-10-28",1,"12","长沙","北京","向松","学生","155332635263",",","","","未取票","","",""));*/
/*IUserService userService = ServiceFactory.getUserServiceInstance();
    List resultData = userService.queryOrder("155332635263","1");
}*/
