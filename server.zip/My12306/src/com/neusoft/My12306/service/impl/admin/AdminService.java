package com.neusoft.My12306.service.impl.admin;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IAdminDao;
import com.neusoft.My12306.dao.pojo.Admin;
import com.neusoft.My12306.service.iservice.admin.IAdminService;
import com.neusoft.My12306.util.AdminPermission;

public class AdminService implements IAdminService{
	private static Logger logger = Logger.getLogger(AdminService.class);
	
	private IAdminDao adminDao;
	
	public AdminService(){
		adminDao = DaoFactory.getAdminDao();
	}

	@Override
	public String save(Admin admin, int permission) {
		if(permission == AdminPermission.SUPER_ADMIN.ordinal()){
			try{
				admin.setAdminid(adminDao.getNewId());
				logger.info("正在保存: " + admin);
				adminDao.save(admin);
				logger.info("保存成功: " + admin);
				return "成功";
			}catch(Exception e){
				logger.info("保存失败" + admin);
				logger.error(e);
				e.printStackTrace();
				if(e.getMessage().contains("ORA-00001:违反了唯一约束条件")){
					return "该管理员已经存在";
				}else{
					return "错误";
				}
			}
		}else{
			return "错误";
		}
	}

	@Override
	public String delete(Admin admin, int permission) {
		if(permission == AdminPermission.SUPER_ADMIN.ordinal()){
			try{
				logger.info("正在删除: " + admin);
				adminDao.delete(admin);
				logger.info("成功删除: " + admin);
				return "success";
			}catch(Exception e){
				logger.info("删除失败: " + admin);
				logger.error(e);
				e.printStackTrace();
				return "错误";
			}
		}else{
			return "错误";
		}
	}

	@Override
	public String update(Admin admin, int permission) {
		if(permission == AdminPermission.SUPER_ADMIN.ordinal()){
			try{
				logger.info("正在更新" + admin);
				adminDao.update(admin);
				logger.info("成功更新" + admin);
				return "success";
			}catch(Exception e){
				logger.info("更新失败: " + admin);
				logger.error(e);
				e.printStackTrace();
				return "错误";
			}
		}else{
			return "错误";
		}
	}

	@Override
	public Admin findById(int id, int permission) {
		Admin admin = null;
		if(permission == AdminPermission.SUPER_ADMIN.ordinal()){
			try{
				logger.info("正在查询管理员信息: id" + id);
				admin = adminDao.findById(id);
				logger.info("成功查询管理员信息: id" + id);
			}catch(Exception e){
				logger.info("查询管理员信息失败: id" + id);
				logger.error(e);
				e.printStackTrace();
			}
		}
		return admin;
	}

	@Override
	public List<Admin> findAll(int permission) {
		List<Admin> adminList = new ArrayList<Admin>();
		if(permission == AdminPermission.SUPER_ADMIN.ordinal()){
			try{
				logger.info("正在查询所有管理员信息");
				adminList.addAll(adminDao.findAll());
				logger.info("成功查询所有管理员信息");
			}catch(Exception e){
				logger.info("查询所有管理员信息失败");
				logger.error(e);
				e.printStackTrace();
			}
		}
		return adminList;
	}

}
