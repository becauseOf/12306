package com.neusoft.My12306.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hehujun.framework.dbhelper.util.IDealWithResultSet;
import com.hehujun.framework.dbhelper.util.ISetStatementParam;
import com.hehujun.framework.dbhelper.util.SQLUtil;
import com.neusoft.My12306.dao.idao.IRouteDao;
import com.neusoft.My12306.dao.pojo.Route;

public class RouteDao implements IRouteDao {

	@Override
	public void delete(Route route) throws Exception {
		String sql = "delete from t_route where routeid=?";
		SQLUtil.delete(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, route.getRouteid());
			}
		});
	}

	@Override
	public List<Route> findAll() throws Exception {
		String sql = "SELECT JAVA .T_ROUTE.ROUTEID, JAVA .T_ROUTE.TRAINID, " + "JAVA .T_ROUTE.STATIONNAME, "
				+ "TO_CHAR ( JAVA .T_ROUTE.START_TIME, 'hh24:mi:ss' ), "
				+ "TO_CHAR ( JAVA .T_ROUTE.END_TIME, 'hh24:mi:ss' ), " + "JAVA .T_ROUTE. LENGTH, "
				+ "TO_CHAR ( JAVA .T_ROUTE.WAIT_TIME, 'hh24:mi:ss' ), "
				+ "TO_CHAR ( JAVA .T_ROUTE. TIME, 'hh24:mi:ss' ), "
				+ "JAVA .T_ROUTE.STATIONID FROM JAVA .T_ROUTE order by routeid asc";
		List<Object> oList = SQLUtil.find(sql, new IDealWithResultSet<Route>() {

			@Override
			public Route dealWithResultSet(ResultSet rs) throws SQLException {
				Route route = new Route();
				route.setRouteid(rs.getInt(1));
				route.setTrainid(rs.getString(2));
				route.setStationName(rs.getString(3));
				route.setStartTime(rs.getString(4));
				route.setEndTime(rs.getString(5));
				route.setLength(rs.getLong(6));
				route.setWaitTime(rs.getString(7));
				route.setTime(rs.getString(8));
				route.setStationid(rs.getInt(9));
				return route;
			}
		});
		List<Route> routeList = new ArrayList<Route>();
		for (Object o : oList) {
			routeList.add((Route) o);
		}
		return routeList;
	}

	@Override
	public Route findById(Integer id) throws Exception {
		String sql = "SELECT JAVA .T_ROUTE.ROUTEID, JAVA .T_ROUTE.TRAINID, " + "JAVA .T_ROUTE.STATIONNAME, "
				+ "TO_CHAR ( JAVA .T_ROUTE.START_TIME, 'hh24:mi:ss' ), "
				+ "TO_CHAR ( JAVA .T_ROUTE.END_TIME, 'hh24:mi:ss' ), " + "JAVA .T_ROUTE. LENGTH, "
				+ "TO_CHAR ( JAVA .T_ROUTE.WAIT_TIME, 'hh24:mi:ss' ), "
				+ "TO_CHAR ( JAVA .T_ROUTE. TIME, 'hh24:mi:ss' ), " + "JAVA .T_ROUTE.STATIONID FROM JAVA .T_ROUTE "
				+ "where ROUTEID=? order by ROUTEID asc";
		List<Object> oList = SQLUtil.find(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, id);
			}
		}, new IDealWithResultSet<Route>() {

			@Override
			public Route dealWithResultSet(ResultSet rs) throws SQLException {
				Route route = new Route();
				route.setRouteid(rs.getInt(1));
				route.setTrainid(rs.getString(2));
				route.setStationName(rs.getString(3));
				route.setStartTime(rs.getString(4));
				route.setEndTime(rs.getString(5));
				route.setLength(rs.getLong(6));
				route.setWaitTime(rs.getString(7));
				route.setTime(rs.getString(8));
				route.setStationid(rs.getInt(9));
				return route;
			}
		});
		Route route = null;
		if (!oList.isEmpty()) {
			route = (Route) oList.get(0);
		}
		return route;
	}

	@Override
	public void save(Route route) throws Exception {
		String sql = "insert into t_route (routeid, trainid, stationname, "
				+ "start_time, end_time, length, wait_time, time, stationid)"
				+ " VALUES (?,?,?,to_date(?, 'hh24:mi:ss')," + "to_date(?, 'hh24:mi:ss'),?,to_date(?, 'hh24:mi:ss'),"
				+ "to_date(?, 'hh24:mi:ss'),?)";
		SQLUtil.save(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, route.getRouteid());
				ps.setString(2, route.getTrainid());
				ps.setString(3, route.getStationName());
				ps.setString(4, route.getStartTime());
				ps.setString(5, route.getEndTime());
				ps.setLong(6, route.getLength());
				ps.setString(7, route.getWaitTime());
				ps.setString(8, route.getTime());
				ps.setInt(9, route.getStationid());
			}
		});
	}

	@Override
	public void update(Route route) throws Exception {
		String sql = "update T_ROUTE set trainid=?, stationname=?, "
				+ "start_time=to_date(?, 'hh24:mi:ss'), end_time=to_date(?, 'hh24:mi:ss'), "
				+ "length=?, wait_time=to_date(?, 'hh24:mi:ss'), time=to_date(?, 'hh24:mi:ss'), "
				+ "stationid=? where routeid=?";
		SQLUtil.save(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, route.getTrainid());
				ps.setString(2, route.getStationName());
				ps.setString(3, route.getStartTime());
				ps.setString(4, route.getEndTime());
				ps.setLong(5, route.getLength());
				ps.setString(6, route.getWaitTime());
				ps.setString(7, route.getTime());
				ps.setInt(8, route.getStationid());
				ps.setInt(9, route.getRouteid());
			}
		});
	}

	@Override
	public int getNewId() throws SQLException {
		String sql = "select max(routeid) from t_route";
		List<Object> i = SQLUtil.executeAndGetResult(sql, new IDealWithResultSet<Integer>() {

			@Override
			public Integer dealWithResultSet(ResultSet rs) throws SQLException {
				Integer i = new Integer(rs.getInt(1) + 1);
				return i;
			}
		});
		return (i.size() == 0 ? 0 : (int) i.get(0));
	}

	@Override
	public long getLength(String trainid, String startStation, String endStation) throws Exception {
		String sql = "SELECT LENGTH FROM T_ROUTE route, T_STATION station "
				+ "WHERE ROUTE.STATIONID = STATION.STATIONID AND ROUTE.TRAINID=? "
				+ "AND STATION.STATIONNAME=? AND ROUTE.STATIONNAME=?";
		List<Object> len = SQLUtil.executeAndGetResult(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, trainid);
				ps.setString(2, startStation);
				ps.setString(3, endStation);
			}
		}, new IDealWithResultSet<Long>() {

			@Override
			public Long dealWithResultSet(ResultSet rs) throws SQLException {
				return rs.getLong(1);
			}
		});
		return (len.size() == 0 ? 0 : (long) len.get(0));
	}

	@Override
	public List<String> getStationNameList(String from, String to, String trainid) throws SQLException {
		String sql = "SELECT JAVA .T_ROUTE.STATIONNAME FROM JAVA .T_ROUTE "
				+ "INNER JOIN JAVA .T_STATION ON JAVA .T_ROUTE.STATIONID = JAVA .T_STATION.STATIONID "
				+ "WHERE  JAVA .T_STATION.STATIONNAME = ? AND JAVA .T_ROUTE.TRAINID = ? AND JAVA .T_ROUTE. LENGTH < "
				+ "( SELECT JAVA .T_ROUTE. LENGTH FROM JAVA .T_ROUTE " + "WHERE JAVA .T_ROUTE.STATIONNAME = ? "
				+ "AND JAVA .T_ROUTE.STATIONID = JAVA .T_STATION.STATIONID )" + "ORDER BY LENGTH ASC";

		List<Object> oList = SQLUtil.executeAndGetResult(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, from);
				ps.setString(2, trainid);
				ps.setString(3, to);
			}
		}, new IDealWithResultSet<String>() {

			@Override
			public String dealWithResultSet(ResultSet rs) throws SQLException {
				return rs.getString(1);
			}
		});
		List<String> list = new ArrayList<String>();
		list.add(from);
		for (Object o : oList) {
			list.add((String) o);
		}
		list.add(to);
		return list;
	}

}
