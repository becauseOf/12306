package com.neusoft.My12306.action.userservlet;

import com.google.gson.JsonObject;
import com.neusoft.My12306.dao.impl.UserLoginDao;
import com.neusoft.My12306.dao.pojo.UserLogin;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.impl.user.UserServiceImpl;
import com.neusoft.My12306.service.iservice.user.IUserService;
import com.neusoft.My12306.util.GsonUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 处理用户登陆
 * Created by xiangsong on 2016/9/17.
 */
@WebServlet("/Login")
public class Login extends HttpServlet{

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String content = request.getParameter("content");
        UserLogin userLogin = (UserLogin) GsonUtil.fromJson(content,UserLogin.class);
        IUserService userService = ServiceFactory.getUserServiceInstance();

        JsonObject result = new JsonObject();

        boolean isSuccess = userService.validateLogin(userLogin.getEmail(),userLogin.getPassword());

        result.addProperty("issuccess",isSuccess);
        response.getWriter().println(result.toString());
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        doPost(request, response);
    }

}
