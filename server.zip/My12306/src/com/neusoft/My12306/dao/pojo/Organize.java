package com.neusoft.My12306.dao.pojo;

/**
 * 列车编组信息
 * 
 * @author hezhujun
 *
 */
public class Organize {
	private int organizeid;
	private String trainid;
	private int num;
	private String seatClass;
	private int seatCount;
	private String category;

	public int getOrganizeid() {
		return organizeid;
	}

	public void setOrganizeid(int organizeid) {
		this.organizeid = organizeid;
	}

	public String getTrainid() {
		return trainid;
	}

	public void setTrainid(String trainid) {
		this.trainid = trainid;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getSeatClass() {
		return seatClass;
	}

	public void setSeatClass(String seatClass) {
		this.seatClass = seatClass;
	}

	public int getSeatCount() {
		return seatCount;
	}

	public void setSeatCount(int seatCount) {
		this.seatCount = seatCount;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Organize() {
		// TODO Auto-generated constructor stub
	}

	public Organize(int organizeid, String trainid, int num, String seatClass, int seatCount, String category) {
		super();
		this.organizeid = organizeid;
		this.trainid = trainid;
		this.num = num;
		this.seatClass = seatClass;
		this.seatCount = seatCount;
		this.category = category;
	}

	@Override
	public String toString() {
		return "Organize [organizeid=" + organizeid + ", trainid=" + trainid + ", num=" + num + ", seatClass="
				+ seatClass + ", seatCount=" + seatCount + ", category=" + category + "]";
	}

}
