package com.neusoft.My12306.service.iservice.basedata;

import java.util.List;

import com.neusoft.My12306.dao.pojo.Route;

/**
 * 线路管理
 * 
 * @author hezhujun
 *
 */
public interface IRouteService {
	/**
	 * 保存线路信息
	 * 
	 * @param route
	 *            线路对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回"error"
	 */
	String save(Route route, int permission);

	/**
	 * 删除线路信息
	 * 
	 * @param route
	 *            线路对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回"error"
	 */
	String delete(Route route, int permission);

	/**
	 * 更新线路信息
	 * 
	 * @param route
	 *            线路对象
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回"success" 失败返回"error"
	 */
	String update(Route route, int permission);

	/**
	 * 通过id查询线路信息
	 * 
	 * @param id
	 *            id
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Route对象 失败返回 null
	 */
	Route findById(int id, int permission);

	/**
	 * 查询所有信息
	 * 
	 * @param permission
	 *            基础数据管理员权限
	 * @return 成功返回Route列表 失败返回 空列表
	 */
	List<Route> findAll(int permission);
	
	/**
	 * 查询线路的里程
	 * @param trainid 列车车次
	 * @param startStation 开始站
	 * @param endStation 终点站
	 * @return 里程
	 */
	long getLength(String trainid, String startStation, String endStation);
}
