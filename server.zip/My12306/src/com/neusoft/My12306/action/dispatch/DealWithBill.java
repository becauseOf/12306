package com.neusoft.My12306.action.dispatch;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.My12306.bean.TicketBean;
import com.neusoft.My12306.dao.pojo.Seat;
import com.neusoft.My12306.dao.pojo.Ticket;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.order.ITicketService;
import com.neusoft.My12306.service.iservice.plan.ISeatService;
import com.neusoft.My12306.util.CalculatePrice;
import com.neusoft.My12306.util.ClassifyPassenger;
import com.neusoft.My12306.util.CreateBean;

public class DealWithBill {

	private static ITicketService ticketService = ServiceFactory.getTicketService();
	private static ISeatService seatService = ServiceFactory.getSeatService();

	public static void dealWithMainPage(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("submit") == null) {
			String idcard = (String) request.getSession().getAttribute("idcard");
			if (idcard != null) {
				List<Ticket> ticketList = ticketService.getTicketByIdcard(idcard);
				Iterator<Ticket> iter = ticketList.iterator();
				while (iter.hasNext()) {
					String ticketState = iter.next().getTicketState();
					if ("取票".equals(ticketState) || "退票".equals(ticketState)) {
						iter.remove();
					}
				}
				request.setAttribute("ticketList", ticketList);
			}
			request.getRequestDispatcher("WEB-INF/view/bill/ticketManager.jsp").forward(request, response);
		} else {
			String idcard = request.getParameter("idcard");
			request.getSession().setAttribute("idcard", idcard);
			List<Ticket> ticketList = ticketService.getTicketByIdcard(idcard);
			Iterator<Ticket> iter = ticketList.iterator();
			while (iter.hasNext()) {
				String ticketState = iter.next().getTicketState();
				if ("取票".equals(ticketState) || "退票".equals(ticketState)) {
					iter.remove();
				}
			}
			request.setAttribute("ticketList", ticketList);
			request.getRequestDispatcher("WEB-INF/view/bill/ticketManager.jsp").forward(request, response);
		}

	}

	public static void dealWithModifyticket(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getSession().setAttribute("operation", "改票");
		int ticketid = Integer.parseInt(request.getParameter("ticketid"));
		Ticket ticket = ticketService.getTicketById(ticketid);
		request.getSession().setAttribute("ticket", ticket);
		// 保存旧车票信息
		try {
			Ticket old = (Ticket) ticket.clone();
			request.getSession().setAttribute("oldTicket", old);
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		List<TicketBean> ticketBeanList = ticketService.getTicketBean(ticket.getStartStation(), ticket.getEndStation(),
				ticket.getDate());
		request.setAttribute("ticketBeanList", ticketBeanList);
		request.getRequestDispatcher("WEB-INF/view/bill/remainTicket.jsp").forward(request, response);
	}

	public static void dealWithSignChangeticket(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getSession().setAttribute("operation", "改签");
		int ticketid = Integer.parseInt(request.getParameter("ticketid"));
		Ticket ticket = ticketService.getTicketById(ticketid);
		request.getSession().setAttribute("ticket", ticket);
		// 保存旧车票信息
		try {
			Ticket old = (Ticket) ticket.clone();
			request.getSession().setAttribute("oldTicket", old);
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		List<TicketBean> ticketBeanList = ticketService.getTicketBean(ticket.getStartStation(), ticket.getEndStation(),
				ticket.getDate());
		request.setAttribute("ticketBeanList", ticketBeanList);
		request.getRequestDispatcher("WEB-INF/view/bill/remainTicket.jsp").forward(request, response);
	}

	public static void dealWithFindRemainTicket(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("submit") == null) {
			request.getRequestDispatcher("WEB-INF/view/bill/remainTicket.jsp").forward(request, response);
		} else {
			String from = request.getParameter("from");
			String to = request.getParameter("to");
			String day = request.getParameter("day");
			List<TicketBean> ticketBeanList = ticketService.getTicketBean(from, to, day);
			request.setAttribute("ticketBeanList", ticketBeanList);
			request.getRequestDispatcher("WEB-INF/view/bill/remainTicket.jsp").forward(request, response);
		}
	}

	public static void dealWithBuy(HttpServletRequest request, HttpServletResponse response, int permission)
			throws ServletException, IOException {
		String result = request.getParameter("submit");
		if (result == null) {
			String from = request.getParameter("from");
			String to = request.getParameter("to");
			String day = request.getParameter("day");
			String trainid = request.getParameter("trainid");
			String seatClass = request.getParameter("seatclass");
			Seat seat = ticketService.selectSeat(from, to, trainid, seatClass, day);
			Ticket ticket = (Ticket) request.getSession().getAttribute("ticket");
			ticket.setDate(day);
			ticket.setStartStation(from);
			ticket.setEndStation(to);
			ticket.setTrainid(trainid);
			ticket.setTrainBox(seat.getNum());
			ticket.setSeatNum(seat.getSeatNubmer());
			ticket.setTicketState((String) request.getSession().getAttribute("operation"));
			request.getSession().setAttribute("seat", seat);
			BigDecimal price = CalculatePrice.getPrice(from, to, seatClass, trainid);
			// 判断是否是儿童或小孩
			String type = ClassifyPassenger.classifyPassenger(ticket.getIdcard());
			if ("儿童".equals(type) || "老人".equals(type)) {
				price.divide(new BigDecimal(2));
			}
			ticket.setPrice(price.doubleValue());
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			ticket.setStateChgTime(format.format(new Date()));
			request.getRequestDispatcher("WEB-INF/view/bill/reviseTicket.jsp").forward(request, response);
		} else if ("确定".equals(result)) {
			Ticket ticket = CreateBean.getBean(Ticket.class, request);
			Seat seat = (Seat) request.getSession().getAttribute("seat");
			ticketService.selectedSeat(seat.getSeatid());
			ticketService.update(ticket, permission);
			// 旧车票的席位状态设置为未售
			Ticket old = (Ticket) request.getSession().getAttribute("oldTicket");
			if (old != null) {
				Seat oldSeat = seatService.getSeat(old.getStartStation(), old.getEndStation(),
						old.getTrainid(), old.getTrainBox(), old.getSeatNum(), old.getDate());
				if (oldSeat != null) {
					ticketService.cancelSeat(oldSeat.getSeatid());
				}
			}
			response.sendRedirect("BillServlet");
		} else if ("取消".equals(result)) {
			Seat seat = (Seat) request.getSession().getAttribute("seat");
			ticketService.cancelSeat(seat.getSeatid());
			response.sendRedirect("BillServlet");
		}
	}

}
