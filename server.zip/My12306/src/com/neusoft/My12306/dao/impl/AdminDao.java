package com.neusoft.My12306.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hehujun.framework.dbhelper.util.IDealWithResultSet;
import com.hehujun.framework.dbhelper.util.ISetStatementParam;
import com.hehujun.framework.dbhelper.util.SQLUtil;
import com.neusoft.My12306.dao.idao.IAdminDao;
import com.neusoft.My12306.dao.pojo.Admin;

public class AdminDao implements IAdminDao {

	@Override
	public void delete(Admin admin) throws Exception {
		String sql = "delete from t_admin where adminid=?";
		SQLUtil.delete(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, admin.getAdminid());
			}
		});

	}

	@Override
	public List<Admin> findAll() throws Exception {
		String sql = "SELECT JAVA.T_ADMIN.ADMINID," + "JAVA.T_ADMIN.NAME,JAVA.T_ADMIN.PASSWORD,"
				+ "JAVA.T_ADMIN.PERMISSION " + "FROM JAVA.T_ADMIN order by adminid";
		List<Object> oList = SQLUtil.find(sql, new IDealWithResultSet<Admin>() {

			@Override
			public Admin dealWithResultSet(ResultSet rs) throws SQLException {
				Admin admin = new Admin();
				admin.setAdminid(rs.getInt(1));
				admin.setName(rs.getString(2));
				admin.setPassword(rs.getString(3));
				admin.setPermission(rs.getInt(4));
				return admin;
			}
		});
		List<Admin> adminList = new ArrayList<Admin>();
		for (Object o : oList) {
			adminList.add((Admin) o);
		}
		return adminList;
	}

	@Override
	public Admin findById(Integer id) throws Exception {
		String sql = "SELECT JAVA.T_ADMIN.ADMINID,JAVA.T_ADMIN.NAME," + "JAVA.T_ADMIN.PASSWORD,JAVA.T_ADMIN.PERMISSION"
				+ " FROM JAVA.T_ADMIN where adminid=? order by adminid";
		List<Object> oList = SQLUtil.find(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, id);
			}
		}, new IDealWithResultSet<Admin>() {

			@Override
			public Admin dealWithResultSet(ResultSet rs) throws SQLException {
				Admin admin = new Admin();
				admin.setAdminid(rs.getInt(1));
				admin.setName(rs.getString(2));
				admin.setPassword(rs.getString(3));
				admin.setPermission(rs.getInt(4));
				return admin;
			}
		});
		Admin admin = null;
		if (!oList.isEmpty()) {
			admin = (Admin) oList.get(0);
		}
		return admin;
	}

	@Override
	public void save(Admin admin) throws Exception {
		String sql = "insert into t_admin(adminid,name," + "password,permission) values(?,?,?,?)";
		SQLUtil.save(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, admin.getAdminid());
				ps.setString(2, admin.getName());
				ps.setString(3, admin.getPassword());
				ps.setInt(4, admin.getPermission());
			}
		});

	}

	@Override
	public void update(Admin admin) throws Exception {
		String sql = "update t_admin set name=?,password=?,permission=? where adminid=?";
		SQLUtil.save(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, admin.getName());
				ps.setString(2, admin.getPassword());
				ps.setInt(3, admin.getPermission());
				ps.setInt(4, admin.getAdminid());
			}
		});

	}

	@Override
	public int getNewId() throws SQLException {
		String sql = "select max(adminid) from t_admin";
		List<Object> i = SQLUtil.executeAndGetResult(sql, new IDealWithResultSet<Integer>() {

			@Override
			public Integer dealWithResultSet(ResultSet rs) throws SQLException {
				Integer i = new Integer(rs.getInt(1) + 1);
				return i;
			}
		});
		return (i.size() == 0 ? 0 : (int) i.get(0));
	}

}
