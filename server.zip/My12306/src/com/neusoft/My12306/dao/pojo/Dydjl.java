package com.neusoft.My12306.dao.pojo;

import java.math.BigDecimal;

/**
 * 递远递减率
 * 
 * @author hezhujun
 *
 */
public class Dydjl {
	private int dydjlid;
	private String mileageSectionFrom;
	private String mileageSectionTo;
	private int lapseRate;
	private BigDecimal fares;
	private BigDecimal eachTotal;
	private BigDecimal total;

	public int getDydjlid() {
		return dydjlid;
	}

	public void setDydjlid(int dydjlid) {
		this.dydjlid = dydjlid;
	}

	public String getMileageSectionFrom() {
		return mileageSectionFrom;
	}

	public void setMileageSectionFrom(String mileageSectionFrom) {
		this.mileageSectionFrom = mileageSectionFrom;
	}

	public String getMileageSectionTo() {
		return mileageSectionTo;
	}

	public void setMileageSectionTo(String mileageSectionTo) {
		this.mileageSectionTo = mileageSectionTo;
	}

	public int getLapseRate() {
		return lapseRate;
	}

	public void setLapseRate(int lapseRate) {
		this.lapseRate = lapseRate;
	}

	public BigDecimal getFares() {
		return fares;
	}

	public void setFares(BigDecimal fares) {
		this.fares = fares;
	}

	public BigDecimal getEachTotal() {
		return eachTotal;
	}

	public void setEachTotal(BigDecimal eachTotal) {
		this.eachTotal = eachTotal;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public Dydjl() {
		// TODO Auto-generated constructor stub
	}

	public Dydjl(int dydjlid, String mileageSectionFrom, String mileageSectionTo, int lapseRate, BigDecimal fares,
			BigDecimal eachTotal, BigDecimal total) {
		super();
		this.dydjlid = dydjlid;
		this.mileageSectionFrom = mileageSectionFrom;
		this.mileageSectionTo = mileageSectionTo;
		this.lapseRate = lapseRate;
		this.fares = fares;
		this.eachTotal = eachTotal;
		this.total = total;
	}

	@Override
	public String toString() {
		return "Dydjl [dydjlid=" + dydjlid + ", mileageSectionFrom=" + mileageSectionFrom + ", mileageSectionTo="
				+ mileageSectionTo + ", lapseRate=" + lapseRate + ", fares=" + fares + ", eachTotal=" + eachTotal
				+ ", total=" + total + "]";
	}

}
