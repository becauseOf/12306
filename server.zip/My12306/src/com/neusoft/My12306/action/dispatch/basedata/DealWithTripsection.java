package com.neusoft.My12306.action.dispatch.basedata;

import javax.servlet.http.HttpServletRequest;

import com.neusoft.My12306.dao.pojo.Tripsection;
import com.neusoft.My12306.service.iservice.basedata.ITripsectionService;
import com.neusoft.My12306.util.CreateBean;

public class DealWithTripsection {

	public static String updateTripsection(HttpServletRequest request, ITripsectionService tripsectionService,
			int permission) {
		Tripsection tripsection = CreateBean.getBean(Tripsection.class, request);
		String result = "error";
		if (tripsection != null) {
			result = tripsectionService.update(tripsection, permission);
		}
		return result;
	}

}
