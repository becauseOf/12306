package com.neusoft.My12306.dao.idao;

import com.neusoft.My12306.dao.impl.UserLoginDao;
import com.neusoft.My12306.dao.pojo.UserLogin;

import java.sql.SQLException;

public interface IUserLoginDao {
	boolean validateLogin(String username,String password) throws SQLException;

	void save(UserLogin userLogin)throws Exception;
}
