package com.neusoft.My12306.dao.idao;

import java.sql.SQLException;
import java.util.List;

import com.hehujun.framework.dbhelper.idao.IBaseDao;
import com.neusoft.My12306.dao.pojo.Station;

public interface IStationDao extends IBaseDao<Station, Integer> {
	/**
	 * 获得新id
	 * 
	 * @return id
	 * @throws SQLException
	 */
	int getNewId() throws SQLException;

	/**
	 * 通过车站名查询
	 * 
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	List<Station> findByName(String name) throws SQLException;

	/**
	 * 通过拼音查询
	 * 
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	List<Station> findByPinyin(String name) throws SQLException;
}
