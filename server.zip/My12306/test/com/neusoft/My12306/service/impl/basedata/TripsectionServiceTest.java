package com.neusoft.My12306.service.impl.basedata;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.dao.pojo.Tripsection;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.basedata.ITripsectionService;

public class TripsectionServiceTest {

	private ITripsectionService trService;

	@Before
	public void setUp() throws Exception {
		trService = ServiceFactory.getTripsectionService();
	}

	@Test
	public void testUpdate() {
		Tripsection tr = trService.findById(1, 1);
		tr.setMileageSectionFrom("1");
		trService.update(tr, 1);
	}

	@Test
	public void testFindById() {
		Tripsection tr = trService.findById(1, 1);
		System.out.println(tr);
	}

	@Test
	public void testFindAll() {
		List<Tripsection> trList = trService.findAll(1);
		for (Tripsection tr : trList) {
			System.out.println(tr);
		}
	}

}
