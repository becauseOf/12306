package com.neusoft.My12306.service.impl.plan;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.IPlainDao;
import com.neusoft.My12306.dao.pojo.Plain;
import com.neusoft.My12306.service.iservice.plan.IPlainService;
import com.neusoft.My12306.util.AdminPermission;

public class PlainService implements IPlainService{
	private static Logger logger = Logger.getLogger(PlainService.class);
	private IPlainDao plainDao;
	
	public PlainService(){
		plainDao = DaoFactory.getPlainDao();
	}
	
	@Override
	public String save(Plain plain, int permission) {
		if(permission == AdminPermission.PLAN_ADMIN.ordinal()){
			try {
				plain.setPlainid(plainDao.getNewId());
				logger.info("正在保存：" + plain);
				plainDao.save(plain);
				logger.info("成功保存：" + plain);
				return "success";
			} catch (Exception e) {
				logger.info("保存失败:" + plain);
				logger.error(e);
				e.printStackTrace();
				if(e.getMessage().contains("ORA-00001:违反约束条件")){
					return "计划已经存在";
				}
				else{
					return "错误";
				}
			}
		}else{
			return "错误";
		}
	}
	@Override
	public String delete(Plain plain, int permission) {
		if(permission == AdminPermission.PLAN_ADMIN.ordinal()){
			try{
				logger.info("正在删除: " + plain);
				plainDao.delete(plain);
				logger.info("成功删除: " + plain);
				return "success";
			}catch(Exception e){
				logger.info("删除失败: " + plain);
				logger.error(e);
				e.printStackTrace();
				return "错误";
			}
		}else{
			return "错误";
		}
	}
	@Override
	public String update(Plain plain, int permission) {
		if(permission == AdminPermission.PLAN_ADMIN.ordinal()){
			try {
				logger.info("正在更新: " + plain);
				plainDao.update(plain);
				logger.info("成功更新: " + plain);
			} catch (Exception e) {
				logger.info("更新失败: " + plain);
				logger.info(e);
				e.printStackTrace();
				return "error";
			}
		}
		else{
			return "错误";
		}
		return null;
	}
	@Override
	public List<Plain> findByTrain(String trainid, int permission) {
		List<Plain> plainList = new ArrayList<Plain>();
		if(permission == AdminPermission.PLAN_ADMIN.ordinal()){
			try{
				logger.info("正在查询计划信息 : 车次代码" + trainid);
				plainList.addAll(plainDao.findBytrainid(trainid));
				logger.info("成功查询所有计划信息: 车次代码" + trainid);
			}catch(Exception e){
				logger.info("查询所有计划信息失败: 车次代码" + trainid);
				logger.error(e);
				e.printStackTrace();
			}
		}
		return plainList;
	}
	@Override
	public Plain findById(int id, int permission) {
		Plain plain = null;
		if(permission == AdminPermission.PLAN_ADMIN.ordinal()){
			try{
				logger.info("正在查询计划信息: id" + id);
				plain = plainDao.findById(id);
				logger.info("成功查询计划信息: id" + id);
			}catch(Exception e){
				logger.info("查询计划信息失败: id" + id);
				logger.error(e);
				e.printStackTrace();
			}
		}
		return plain;
	}
	@Override
	public List<Plain> findAll(int permission) {
		List<Plain> plainList = new ArrayList<Plain>();
		if(permission == AdminPermission.PLAN_ADMIN.ordinal()){
			try{
				logger.info("正在查询所有计划信息");
				plainList.addAll(plainDao.findAll());
				logger.info("成功查询所有计划信息");
			}catch(Exception e){
				logger.info("查询所有计划信息失败");
				logger.error(e);
				e.printStackTrace();
			}
		}
		return plainList;
	}
	
	@Override
	public void doPlain(Plain plain, int permission) {
		// TODO Auto-generated method stub
		
	}
}
