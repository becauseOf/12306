package com.neusoft.My12306.service.impl.basedata;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.ITripsectionDao;
import com.neusoft.My12306.dao.pojo.Tripsection;
import com.neusoft.My12306.service.iservice.basedata.ITripsectionService;
import com.neusoft.My12306.util.AdminPermission;

public class TripsectionService implements ITripsectionService {
	private static Logger logger = Logger.getLogger(TripsectionService.class);

	private ITripsectionDao tripsectionDao;

	public TripsectionService() {
		tripsectionDao = DaoFactory.getTripsectionDao();
	}

	@Override
	public String update(Tripsection tripsection, int permission) {
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在更新: " + tripsection);
				tripsectionDao.update(tripsection);
				logger.info("成功更新: " + tripsection);
				return "success";
			} catch (Exception e) {
				logger.info("失败更新: " + tripsection);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public Tripsection findById(int id, int permission) {
		Tripsection tripsection = null;
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询旅程区段信息: id " + id);
				tripsection = tripsectionDao.findById(id);
				logger.info("成功查询旅程区段信息: id " + id);
			} catch (Exception e) {
				logger.info("失败查询旅程区段信息: id " + id);
				logger.error(e);
				e.printStackTrace();
			}
		}
		return tripsection;
	}

	@Override
	public List<Tripsection> findAll(int permission) {
		List<Tripsection> tripsectionList = new ArrayList<Tripsection>();
		if (permission == AdminPermission.BASEDATE_ADMIN.ordinal()) {
			try {
				logger.info("正在查询所有旅程区段信息");
				tripsectionList.addAll(tripsectionDao.findAll());
				logger.info("成功查询所有旅程区段信息");
			} catch (Exception e) {
				logger.info("失败查询所有旅程区段信息");
				logger.error(e);
				e.printStackTrace();
			}
		}
		return tripsectionList;
	}

}
