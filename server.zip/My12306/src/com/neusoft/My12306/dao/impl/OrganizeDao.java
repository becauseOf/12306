package com.neusoft.My12306.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hehujun.framework.dbhelper.util.IDealWithResultSet;
import com.hehujun.framework.dbhelper.util.ISetStatementParam;
import com.hehujun.framework.dbhelper.util.SQLUtil;
import com.neusoft.My12306.dao.idao.IOrganizeDao;
import com.neusoft.My12306.dao.pojo.Organize;

public class OrganizeDao implements IOrganizeDao {

	@Override
	public void delete(Organize organize) throws Exception {
		String sql = "delete from t_organize where organizeid=?";
		SQLUtil.delete(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, organize.getOrganizeid());
			}
		});
	}

	@Override
	public List<Organize> findAll() throws Exception {
		String sql = "SELECT JAVA.T_ORGANIZE.ORGANIZEID, JAVA.T_ORGANIZE.TRAINID, "
				+ "JAVA.T_ORGANIZE.NUM, JAVA.T_ORGANIZE.SEAT_CLASS, "
				+ "JAVA.T_ORGANIZE.SEAT_COUNT, JAVA.T_ORGANIZE.CATAGORY "
				+ "FROM JAVA.T_ORGANIZE order by organizeid asc";
		List<Object> oList = SQLUtil.find(sql, new IDealWithResultSet<Organize>() {

			@Override
			public Organize dealWithResultSet(ResultSet rs) throws SQLException {
				Organize organize = new Organize();
				organize.setOrganizeid(rs.getInt(1));
				organize.setTrainid(rs.getString(2));
				organize.setNum(rs.getInt(3));
				organize.setSeatClass(rs.getString(4));
				organize.setSeatCount(rs.getInt(5));
				organize.setCategory(rs.getString(6));
				return organize;
			}
		});
		List<Organize> organizeList = new ArrayList<Organize>();
		for (Object o : oList) {
			organizeList.add((Organize) o);
		}
		return organizeList;
	}

	@Override
	public Organize findById(Integer id) throws Exception {
		String sql = "SELECT JAVA.T_ORGANIZE.ORGANIZEID, JAVA.T_ORGANIZE.TRAINID, "
				+ "JAVA.T_ORGANIZE.NUM, JAVA.T_ORGANIZE.SEAT_CLASS, "
				+ "JAVA.T_ORGANIZE.SEAT_COUNT, JAVA.T_ORGANIZE.CATAGORY, "
				+ "JAVA.T_ORGANIZE.CANDIDATE1, JAVA.T_ORGANIZE.CANDIDATE2 "
				+ "FROM JAVA.T_ORGANIZE where organizeid=? order by organizeid asc";
		List<Object> oList = SQLUtil.find(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, id);
			}
		}, new IDealWithResultSet<Organize>() {

			@Override
			public Organize dealWithResultSet(ResultSet rs) throws SQLException {
				Organize organize = new Organize();
				organize.setOrganizeid(rs.getInt(1));
				organize.setTrainid(rs.getString(2));
				organize.setNum(rs.getInt(3));
				organize.setSeatClass(rs.getString(4));
				organize.setSeatCount(rs.getInt(5));
				organize.setCategory(rs.getString(6));
				return organize;
			}
		});
		Organize organize = null;
		if (!oList.isEmpty()) {
			organize = (Organize) oList.get(0);
		}
		return organize;
	}

	@Override
	public void save(Organize organize) throws Exception {
		String sql = "insert into t_organize(organizeid, trainid, num, seat_class, "
				+ "seat_count, catagory) values(?,?,?,?,?,?)";
		SQLUtil.save(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setInt(1, organize.getOrganizeid());
				ps.setString(2, organize.getTrainid());
				ps.setInt(3, organize.getNum());
				ps.setString(4, organize.getSeatClass());
				ps.setInt(5, organize.getSeatCount());
				ps.setString(6, organize.getCategory());
			}
		});

	}

	@Override
	public void update(Organize organize) throws Exception {
		String sql = "update t_organize set trainid=?, num=?, seat_class=?, "
				+ "seat_count=?, catagory=? where organizeid=?";
		SQLUtil.update(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, organize.getTrainid());
				ps.setInt(2, organize.getNum());
				ps.setString(3, organize.getSeatClass());
				ps.setInt(4, organize.getSeatCount());
				ps.setString(5, organize.getCategory());
				ps.setInt(6, organize.getOrganizeid());
			}
		});
	}

	@Override
	public int getNewId() throws SQLException {
		String sql = "select max(organizeid) from t_organize";
		List<Object> i = SQLUtil.executeAndGetResult(sql, new IDealWithResultSet<Integer>() {

			@Override
			public Integer dealWithResultSet(ResultSet rs) throws SQLException {
				Integer i = new Integer(rs.getInt(1) + 1);
				return i;
			}
		});
		return (i.size() == 0 ? 0 : (int) i.get(0));
	}

	@Override
	public Organize findByTrainAndNum(String trainid, int num) throws Exception {
		String sql = "SELECT JAVA .T_ORGANIZE.ORGANIZEID, JAVA .T_ORGANIZE.TRAINID,"
				+ " JAVA .T_ORGANIZE.NUM, JAVA .T_ORGANIZE.SEAT_CLASS, "
				+ "JAVA .T_ORGANIZE.SEAT_COUNT, JAVA .T_ORGANIZE.CATAGORY "
				+ "FROM JAVA .T_ORGANIZE WHERE traInid=? AND NUM=?";
		List<Object> oList = SQLUtil.find(sql, new ISetStatementParam() {

			@Override
			public void setStatementParam(PreparedStatement ps) throws SQLException {
				ps.setString(1, trainid);
				ps.setInt(2, num);
			}
		}, new IDealWithResultSet<Organize>() {

			@Override
			public Organize dealWithResultSet(ResultSet rs) throws SQLException {
				Organize organize = new Organize();
				organize.setOrganizeid(rs.getInt(1));
				organize.setTrainid(rs.getString(2));
				organize.setNum(rs.getInt(3));
				organize.setSeatClass(rs.getString(4));
				organize.setSeatCount(rs.getInt(5));
				organize.setCategory(rs.getString(6));
				return organize;
			}
		});
		Organize organize = null;
		if (!oList.isEmpty()) {
			organize = (Organize) oList.get(0);
		}
		return organize;
	}

}
