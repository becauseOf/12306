package com.neusoft.My12306.dao.factory;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.hehujun.framework.dbhelper.factory.ConnectionFactory;

public class FactoryTest {
	@Test
	public void getConnectionTest() {
		try {
			assertNotNull(ConnectionFactory.getInstance().getConnection());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
