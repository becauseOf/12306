package com.neusoft.My12306.dao.idao;

import java.util.List;

import com.hehujun.framework.dbhelper.idao.IBaseDao;
import com.neusoft.My12306.dao.pojo.Ticket;

public interface ITicketDao extends IBaseDao<Ticket, Integer> {
	/**
	 * 获得新id
	 * 
	 * @return id
	 */
	int getNewId()throws Exception;

	/**
	 *
	 * @param userId
	 * @return
	 */
	List<Ticket> findByPhoneId(String userId) throws Exception;

	void updateTicketStatus(String idcard,String status) throws Exception;
}
