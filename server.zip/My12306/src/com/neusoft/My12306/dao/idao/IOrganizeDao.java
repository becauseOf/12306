package com.neusoft.My12306.dao.idao;

import java.sql.SQLException;

import com.hehujun.framework.dbhelper.idao.IBaseDao;
import com.neusoft.My12306.dao.pojo.Organize;

public interface IOrganizeDao extends IBaseDao<Organize, Integer> {
	/**
	 * 获得新id
	 * 
	 * @return id
	 * @throws SQLException 
	 */
	int getNewId() throws SQLException;
	
	/**
	 * 通过列车车次和车厢号查询
	 * @param trainid 列车车次
	 * @param num 车厢号
	 * @return 列车编组信息
	 * @throws Exception 
	 */
	Organize findByTrainAndNum(String trainid, int num) throws Exception;
}
