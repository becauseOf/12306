package com.neusoft.My12306.service.impl.plan;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.neusoft.My12306.dao.factory.DaoFactory;
import com.neusoft.My12306.dao.idao.ISeatDao;
import com.neusoft.My12306.dao.pojo.Seat;
import com.neusoft.My12306.service.iservice.plan.ISeatService;
import com.neusoft.My12306.util.AdminPermission;

public class SeatService implements ISeatService {
	private static Logger logger = Logger.getLogger(SeatService.class);

	private ISeatDao seatDao;

	public SeatService() {
		seatDao = DaoFactory.getSeatDao();
	}

	@Override
	public String save(Seat seat, int permission) {
		if (permission == AdminPermission.PLAN_ADMIN.ordinal()) {
			try {
				seat.setSeatid(seatDao.getNewId());
				logger.info("正在保存: " + seat);
				seatDao.save(seat);
				logger.info("成功保存: " + seat);
				return "success";
			} catch (Exception e) {
				logger.info("失败保存: " + seat);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public String delete(Seat seat, int permission) {
		if (permission == AdminPermission.PLAN_ADMIN.ordinal()) {
			try {
				logger.info("正在删除: " + seat);
				seatDao.delete(seat);
				logger.info("成功删除: " + seat);
				return "success";
			} catch (Exception e) {
				logger.info("失败删除: " + seat);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public String update(Seat seat, int permission) {
		if (permission == AdminPermission.PLAN_ADMIN.ordinal()) {
			try {
				logger.info("正在更新: " + seat);
				seatDao.update(seat);
				logger.info("成功更新: " + seat);
				return "success";
			} catch (Exception e) {
				logger.info("失败更新: " + seat);
				logger.error(e);
				e.printStackTrace();
				return "error";
			}
		} else {
			return "error";
		}
	}

	@Override
	public Seat findById(int id, int permission) {
		Seat seat = null;
		if (permission == AdminPermission.PLAN_ADMIN.ordinal()) {
			try {
				logger.info("正在查询席位信息: id " + id);
				seat = seatDao.findById(id);
				logger.info("成功查询席位信息: id " + id);
			} catch (Exception e) {
				logger.info("失败查询席位信息: id " + id);
				logger.error(e);
				e.printStackTrace();
			}
		}
		return seat;
	}

	@Override
	public List<Seat> findAll(int permission) {
		List<Seat> seatList = new ArrayList<Seat>();
		if (permission == AdminPermission.PLAN_ADMIN.ordinal()) {
			try {
				logger.info("正在查询所有席位信息");
				seatList.addAll(seatDao.findAll());
				logger.info("成功查询所有席位信息");
			} catch (Exception e) {
				logger.info("失败查询所有席位信息");
				logger.error(e);
				e.printStackTrace();
			}
		}
		return seatList;
	}

	@Override
	public Seat getSeat(String from, String to, String trainid, int num, String seatNumber, String day) {
		Seat seat = null;
		try {
			seat = seatDao.getSeat(from, to, trainid, num, seatNumber, day);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return seat;
	}

}
