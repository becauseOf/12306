package com.neusoft.My12306.service.impl.order;

import static org.junit.Assert.fail;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.My12306.bean.TicketBean;
import com.neusoft.My12306.dao.pojo.Seat;
import com.neusoft.My12306.service.factory.ServiceFactory;
import com.neusoft.My12306.service.iservice.order.ITicketService;

public class TicketServiceTest {
	ITicketService ticketService;

	@Before
	public void setUp() throws Exception {
		ticketService = ServiceFactory.getTicketService();
	}

	@Test
	public void testGetTicketBean() {
		List<TicketBean> TicketBeanList = ticketService.getTicketBean("广州", "北京", "2016-09-21");
		for (TicketBean ticketBean : TicketBeanList) {
			System.out.println(ticketBean);
		}
	}

	@Test
	public void testGetTicketByIdcard() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetTicketById() {
		fail("Not yet implemented");
	}

	@Test
	public void testSelectSeat() {
		Seat seat = ticketService.selectSeat("长沙", "北京", "Z202", "硬座", "2016-09-21");
		System.out.println(seat);
	}

	@Test
	public void testSelectedSeat() {
		ticketService.selectedSeat(23);
	}

	@Test
	public void testCancelSeat() {
		ticketService.cancelSeat(23);
	}

	@Test
	public void testLockSeat() {
		ticketService.lockToggle(23, "未售");
	}

}
